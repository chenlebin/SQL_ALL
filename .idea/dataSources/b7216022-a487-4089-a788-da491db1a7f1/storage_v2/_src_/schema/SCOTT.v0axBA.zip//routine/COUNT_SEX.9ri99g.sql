create function count_sex(m_s musicer.sex%type) return number
       is s number(10);
begin
  select count(sex) into s from musicer where sex=m_s;
  return s;
end;
/

