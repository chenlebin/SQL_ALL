create function count_sex2(m_s musicer.sex%type, sum_sex out number);
begin
  select count(sex) into sum_sex from musicer where sex=m_s;
end;
/

