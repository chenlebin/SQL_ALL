create function count_sexx(m_s musicer.sex%type, sum_sex out number)
is s number(10);
begin
  select count(sex) into sum_sex from musicer where sex=m_s;
end;
/

