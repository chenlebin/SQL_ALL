create trigger T1
    after insert
    on PERSON
declare

begin
  dbms_output.put_line
('一个新员工入职');
end;
/

