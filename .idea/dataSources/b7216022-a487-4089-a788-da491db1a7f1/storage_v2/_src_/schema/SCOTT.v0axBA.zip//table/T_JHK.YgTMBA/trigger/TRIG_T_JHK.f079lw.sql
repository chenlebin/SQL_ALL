create trigger TRIG_T_JHK
    before insert
    on T_JHK
    for each row
declare

begin
  select seq_t_jhk.nextval into :new.id from dual;
end;
/

