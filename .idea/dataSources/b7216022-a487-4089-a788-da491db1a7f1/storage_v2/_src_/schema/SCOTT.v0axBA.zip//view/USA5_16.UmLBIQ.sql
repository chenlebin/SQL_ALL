create view USA5_16 as
select 
state,sum(cases) as cases,sum(deaths) as deaths,CONCAT(ROUND(((sum(deaths)/sum(cases))*100),2),'%') as dr from USA_ZONG
WHERE U_DATE="TO_DATE"('2020-05-16', 'yyyy-mm-dd') GROUP BY state ORDER BY cases desc
/

