create TYPE     RewriteMessage AS OBJECT(
                mv_owner        VARCHAR2(30),
                mv_name         VARCHAR2(30),
                sequence        NUMBER(3),      /* sequence no of the msg */
                query_text      VARCHAR2(2000),
                query_block_no  NUMBER(3),      /* block no of the current subquery */
                rewritten_text  VARCHAR2(2000),             /* rewritten query text */
                message         VARCHAR2(512),
                pass            VARCHAR2(3),    /* indicate the no of rewrite passes */
                mv_in_msg       VARCHAR2(30),               /* MV in current message */
                measure_in_msg  VARCHAR2(30),          /* Measure in current message */
                join_back_tbl   VARCHAR2(30),      /* Join back table in current msg */
                join_back_col   VARCHAR2(30),     /* Join back column in current msg */
                original_cost   NUMBER(10),                   /* original query cost */
                rewritten_cost  NUMBER(10),                  /* rewritten query cost */
                flags           NUMBER,
                reserved1       NUMBER,
                reserved2       VARCHAR2(10)
)
/

