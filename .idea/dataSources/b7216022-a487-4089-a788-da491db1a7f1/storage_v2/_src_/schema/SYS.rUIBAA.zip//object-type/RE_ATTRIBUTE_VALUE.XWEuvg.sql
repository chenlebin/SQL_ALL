create TYPE     re$attribute_value
AS OBJECT
(variable_name           varchar2(32),
 attribute_name          varchar2(4000),
 attribute_data          sys.anydata)
/

