create TYPE     re$column_value
AS OBJECT
(table_alias             varchar2(32),
 column_name             varchar2(4000),
 column_data             sys.anydata)
/

