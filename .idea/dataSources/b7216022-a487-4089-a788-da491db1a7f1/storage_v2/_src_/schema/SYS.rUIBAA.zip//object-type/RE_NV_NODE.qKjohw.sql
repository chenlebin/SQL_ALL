create TYPE     re$nv_node
                                                                       AS OBJECT
( nvn_name       varchar2(30),
  nvn_value      sys.anydata)
/

