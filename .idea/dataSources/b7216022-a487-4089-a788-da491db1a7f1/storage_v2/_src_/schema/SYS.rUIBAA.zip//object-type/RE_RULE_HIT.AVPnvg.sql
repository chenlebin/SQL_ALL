create TYPE     re$rule_hit
AS OBJECT
(rule_name               varchar2(65),
 rule_action_context     sys.re$nv_list)
/

