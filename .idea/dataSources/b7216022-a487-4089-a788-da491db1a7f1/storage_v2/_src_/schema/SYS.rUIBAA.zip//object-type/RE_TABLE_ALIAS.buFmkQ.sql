create TYPE     re$table_alias
AS OBJECT
(table_alias             varchar2(32),
 table_name              varchar2(194))
/

