create TYPE     re$table_value
AS OBJECT
(table_alias             varchar2(32),
 table_rowid             varchar2(18))
/

