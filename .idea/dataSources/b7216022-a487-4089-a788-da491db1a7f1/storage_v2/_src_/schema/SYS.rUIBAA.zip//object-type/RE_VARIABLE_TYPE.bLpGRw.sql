create TYPE     re$variable_type
AS OBJECT
(variable_name             varchar2(32),
 variable_type             varchar2(4000),
 variable_value_function   varchar2(228),
 variable_method_function  varchar2(228))
/

