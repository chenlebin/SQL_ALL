create TYPE     re$variable_value
AS OBJECT
(variable_name           varchar2(32),
 variable_data           sys.anydata)
/

