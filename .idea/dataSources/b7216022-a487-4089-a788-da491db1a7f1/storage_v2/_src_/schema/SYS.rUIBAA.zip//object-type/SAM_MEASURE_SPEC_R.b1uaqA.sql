create type SAM_MEASURE_SPEC_R wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
d6 c6
+v4ISy+Wx5ZlAWXppaKv7wiJIlkwgwH/LcvWyo4C7v8ilaSoUg5LU4cpjYOpyJnsVwj5IGsb
O38zX6q87okq85F0Ki+LWCaLomFlcEC0qoWnOWep8BxzU8Sab5H4YDwVETHfgDXB4KzZ3Jsh
6qyK+fQr8lVQCnZySH321N7j1oC/+ViLULaZ6w3y4YXGOWU/0Yg=
/

