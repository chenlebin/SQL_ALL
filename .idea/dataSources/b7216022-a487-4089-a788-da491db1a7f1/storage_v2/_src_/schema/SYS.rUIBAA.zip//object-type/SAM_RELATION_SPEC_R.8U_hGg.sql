create type SAM_RELATION_SPEC_R wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
5a 96
RGal2MBhiu4zfw4vEGmGNl3Gj0Qwg5n0dLhc55/S8CjAgVJ0CNL+bSjLuDJKKAm4dCulv5vA
MsvuCWlQpn+kEHo34DhKNf8cSjVgq9Q57HtnPkTIibCZ4+4f/B5dqxo4fmsLDiYO+qamFv2U
xw==
/

