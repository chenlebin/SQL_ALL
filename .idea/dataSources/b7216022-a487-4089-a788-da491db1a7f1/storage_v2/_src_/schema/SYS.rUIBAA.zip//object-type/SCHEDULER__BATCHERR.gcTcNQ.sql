create TYPE SCHEDULER$_BATCHERR AS OBJECT
(
  array_index           NUMBER,
  object_type           VARCHAR2(30),
  object_name           VARCHAR2(100),
  attr_name             VARCHAR2(30),
  error_code            NUMBER,
  error_message         VARCHAR2(4000),
  additional_info       VARCHAR2(4000)
);
/

