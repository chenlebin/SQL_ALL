create TYPE     scheduler$_chain_link IS OBJECT (
       first_step_name    VARCHAR2(32),
       first_step_type    VARCHAR2(32),
       second_step_name   VARCHAR2(32),
       second_step_type   VARCHAR2(32),
       rule_name          VARCHAR2(32),
       rule_owner         VARCHAR2(32),
       action_type        VARCHAR2(32))
/

