create TYPE     scheduler$_rule  IS OBJECT (
       rule_name         VARCHAR2(65),
       rule_condition    VARCHAR2(4000),
       rule_action       VARCHAR2(4000))
/

