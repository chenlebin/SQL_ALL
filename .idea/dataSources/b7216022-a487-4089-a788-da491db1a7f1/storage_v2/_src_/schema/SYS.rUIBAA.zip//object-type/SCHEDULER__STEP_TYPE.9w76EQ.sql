create TYPE     scheduler$_step_type IS OBJECT (
       step_name    VARCHAR2(32),
       step_type    VARCHAR2(32))
/

