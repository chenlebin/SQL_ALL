create TYPE sqlset_row AS object (
  --
  -- sql tuning set basic attributes
  --
  sql_id                   VARCHAR(13),                      /* unique SQL ID */
  force_matching_signature NUMBER,          /* literals, case, spaces removed */
  sql_text                 CLOB,                    /* unique SQL hache value */
  object_list              sql_objects,    /* objects referenced by this stmt */
  bind_data                RAW(2000),   /* bind data as captured for this SQL */
  parsing_schema_name      VARCHAR2(30),    /* schema where the SQL is parsed */
  module                   VARCHAR2(48),      /* last app. module for the SQL */
  action                   VARCHAR2(32),      /* last app. action for the SQL */
  elapsed_time             NUMBER,     /* elapsed time for this SQL statement */
  cpu_time                 NUMBER,                   /* CPU time for this SQL */
  buffer_gets              NUMBER,                   /* number of buffer gets */
  disk_reads               NUMBER,                   /* number of disk reads  */
  direct_writes            NUMBER,                 /* number of direct writes */
  rows_processed           NUMBER,    /* number of rows processed by this SQL */
  fetches                  NUMBER,                       /* number of fetches */
  executions               NUMBER,            /* total executions of this SQL */
  end_of_fetch_count       NUMBER,    /* exec. count fully up to end of fetch */
  optimizer_cost           NUMBER,             /* Optimizer cost for this SQL */
  optimizer_env            RAW(2000),                /* optimizer environment */
  priority                 NUMBER,           /* user-defined priority (1,2,3) */
  command_type             NUMBER,      /* statement type - like INSERT, etc. */
  first_load_time          VARCHAR2(19),        /* load time of parent cursor */
  stat_period              NUMBER,       /* period of time (seconds) when the */
                           /* statistics of this SQL statement were collected */
  active_stat_period       NUMBER,    /* effecive period of time (in seconds) */
                                 /* during which the SQL statement was active */
  other                    CLOB,  /* other column for user defined attributes */
  plan_hash_value          NUMBER,             /* plan hash value of the plan */
  sql_plan                 sql_plan_table_type,               /* explain plan */
  bind_list                sql_binds, /* list of user specified binds for Sql */
                             /* NOTICE: bind_list and bind_data are exclisive */

  --
  -- define a constructor that has default values for sqlset attributes.
  --
  CONSTRUCTOR FUNCTION sqlset_row(
    sql_id                   VARCHAR2            := NULL,
    force_matching_signature NUMBER              := NULL,
    sql_text                 CLOB                := NULL,
    object_list              sql_objects         := NULL,
    bind_data                RAW                 := NULL,
    parsing_schema_name      VARCHAR2            := NULL,
    module                   VARCHAR2            := NULL,
    action                   VARCHAR2            := NULL,
    elapsed_time             NUMBER              := NULL,
    cpu_time                 NUMBER              := NULL,
    buffer_gets              NUMBER              := NULL,
    disk_reads               NUMBER              := NULL,
    direct_writes            NUMBER              := NULL,
    rows_processed           NUMBER              := NULL,
    fetches                  NUMBER              := NULL,
    executions               NUMBER              := NULL,
    end_of_fetch_count       NUMBER              := NULL,
    optimizer_cost           NUMBER              := NULL,
    optimizer_env            RAW                 := NULL,
    priority                 NUMBER              := NULL,
    command_type             NUMBER              := NULL,
    first_load_time          VARCHAR2            := NULL,
    stat_period              NUMBER              := NULL,
    active_stat_period       NUMBER              := NULL,
    other                    CLOB                := NULL,
    plan_hash_value          NUMBER              := NULL,
    sql_plan                 sql_plan_table_type := NULL,
    bind_list                sql_binds           := NULL)
    RETURN SELF AS RESULT
)
/

