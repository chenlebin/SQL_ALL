create TYPE sql_bind
                                                                       AS object (
  name                VARCHAR2(30),                     /* bind variable name */
  position            NUMBER,            /* position of bind in sql statement */
  dup_position        NUMBER,    /* if any, position of primary bind variable */
  datatype            NUMBER,                    /* datatype id for this bind */
  datatype_string     VARCHAR2(15),/* string representation of above datatype */
  character_sid       NUMBER,              /* character set id if bind is NLS */
  precision           NUMBER,                               /* bind precision */
  scale               NUMBER,                                   /* bind scale */
  max_length          NUMBER,                          /* maximum bind length */
  last_captured       DATE,      /* DATE when this bind variable was captured */
  value_string        VARCHAR2(4000),     /* bind value (text representation) */
  value_anydata       ANYDATA)         /* bind value (anydata representation) */
/

