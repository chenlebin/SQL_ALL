create type sql_plan_allstat_row_type
                                                                       under sql_plan_row_type
(
 executions             NUMBER,
 last_starts            NUMBER,
 starts                 NUMBER,
 last_output_rows       NUMBER,
 output_rows            NUMBER,
 last_cr_buffer_gets    NUMBER,
 cr_buffer_gets         NUMBER,
 last_cu_buffer_gets    NUMBER,
 cu_buffer_gets         NUMBER,
 last_disk_reads        NUMBER,
 disk_reads             NUMBER,
 last_disk_writes       NUMBER,
 disk_writes            NUMBER,
 last_elapsed_time      NUMBER,
 elapsed_time           NUMBER,
 policy                 VARCHAR2(10),
 estimated_optimal_size NUMBER,
 estimated_onepass_size NUMBER,
 last_memory_used       NUMBER,
 last_execution         VARCHAR2(10),
 last_degree            NUMBER,
 total_executions       NUMBER,
 optimal_executions     NUMBER,
 onepass_executions     NUMBER,
 multipasses_executions NUMBER,
 active_time            NUMBER,
 max_tempseg_size       NUMBER,
 last_tempseg_size      NUMBER,

 -- Define a constructor function that converts from the old
 -- sql_plan_stat_row_type to the new sql_plan_allstat_row_type
 CONSTRUCTOR FUNCTION sql_plan_allstat_row_type(
   stat_row   sql_plan_stat_row_type)
 RETURN SELF AS RESULT
)
not final
/

