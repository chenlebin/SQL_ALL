create type sql_plan_stat_row_type
                                                                       under sql_plan_row_type(
 executions             NUMBER,
 starts                 NUMBER,
 output_rows            NUMBER,
 cr_buffer_gets         NUMBER,
 cu_buffer_gets         NUMBER,
 disk_reads             NUMBER,
 disk_writes            NUMBER,
 elapsed_time           NUMBER
)
/

