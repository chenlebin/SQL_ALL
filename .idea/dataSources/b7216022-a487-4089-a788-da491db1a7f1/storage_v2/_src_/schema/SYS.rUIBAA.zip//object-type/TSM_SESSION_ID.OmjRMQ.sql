create TYPE     tsm$session_id
                                                                       AS OBJECT
(
  sid          number,
  serial#      number
)
/

