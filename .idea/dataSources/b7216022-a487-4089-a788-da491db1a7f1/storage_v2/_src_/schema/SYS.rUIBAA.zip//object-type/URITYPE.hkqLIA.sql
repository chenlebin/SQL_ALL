create type     UriType          authid current_user as object
(
  url varchar2(4000),
  -- returns the lob value of the pointed URL
  not instantiable member function getClob RETURN clob,
  -- get the external url (escaped)
  member function getExternalUrl RETURN varchar2 deterministic,
  -- get the un-escaped url
  member function getUrl RETURN varchar2 deterministic,
  -- get the blob value of the output
  not instantiable member function getBlob RETURN blob,
  member function getBlob(csid IN NUMBER) RETURN blob,
  -- new fcns in 9.2
  -- returns the value of this URI as an XMLType
  member function getXML return sys.XMLType,
  member function getContentType RETURN varchar2,
  member function getClob(content OUT varchar2) RETURN clob,
  member function getBlob(content OUT varchar2) RETURN blob,
  member function getXML(content OUT varchar2) RETURN sys.XMLType,
  static function makeBlobFromClob(src_clob IN OUT clob, csid IN NUMBER := 0)
  RETURN blob
) not final not instantiable
/

