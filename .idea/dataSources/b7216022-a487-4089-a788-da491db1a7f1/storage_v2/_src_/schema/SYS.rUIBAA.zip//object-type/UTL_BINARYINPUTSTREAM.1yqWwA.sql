create type utl_BinaryInputStream authid current_user as object
(
  handle raw(12),
  member function available (self in out nocopy Utl_BinaryInputStream)
  return integer,
  -- this function returns the number of bytes available to be read
  member function read (self in out nocopy Utl_BinaryInputStream,
                        numBytes in integer default 1)
  return raw,
  ---- this function reads the number of bytes specified by numBytes
  ---- (default is 1) and returns the bytes as a raw. If there are no remaining
  ---- bytes a value of null is returned.
  member procedure read (self     in  out   nocopy Utl_BinaryInputStream,
   	                 bytes   in out nocopy raw,
                       	 numBytes in out integer),
  ---- this procedure reads the number of bytes specified in numBytes into
  ---- the parameter bytes. Additionally, the actual number of bytes read
  ---- is returned in parameter numBytes. If this parameter
  ---- is set to 0 then there are no more bytes to be read.
  member procedure read (self     in    out  nocopy Utl_BinaryInputStream,
                         bytes   in out nocopy raw,
                         offset   in integer,
                         numBytes  in out integer),
   ---- this procedure reads the number of bytes specified in numBytes into
   ---- the parameter bytes, beginning at the offset specified by parameter
   ---- offset. The actual number of bytes read is returned in parameter
   ---- numBytes. If this value is 0, then there are no additional bytes to
   ---- be read.
   member procedure close (self in out nocopy Utl_BinaryInputStream),
   ---- this function releases all resources held on the node to support
   ---- the stream.
   member function isnull (self in out nocopy Utl_BinaryInputStream)
                                        return boolean
) NOT INSTANTIABLE NOT FINAL;
/

