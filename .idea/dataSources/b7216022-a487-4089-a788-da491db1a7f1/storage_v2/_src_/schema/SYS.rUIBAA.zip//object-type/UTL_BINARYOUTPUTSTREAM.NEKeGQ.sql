create type utl_BinaryOutputStream authid current_user as object
(
  handle raw(12),
  member function write (self in out nocopy utl_BinaryOutputStream,
                         bytes   in out nocopy raw,
                         numBytes in integer default 1)
  return integer,
  ---- this function writes the number of bytes specified by numBytes
  ---- (default is 1) from raw
  ---- into the stream. The actual number of bytes written is returned.
  member procedure write (self  in out nocopy utl_BinaryOutputStream,
                          bytes in out nocopy raw,
               	          numBytes in out integer),
   ---- this procedure writes the number of bytes specified in parameter
   ---- numBytes from parameter bytes to the stream. The actual number of
   ---- bytes written is returned in parameter numBytes.
  member procedure write (self   in out nocopy utl_BinaryOutputStream,
                          bytes  in out nocopy raw,
                          offset in integer,
                          numBytes in out integer),
  ---- this procedure writes the number of bytes specified by numBytes to the
  ---- stream, beginning at the offset specified by parameter offset.
  ---- The actual number of bytes written is returned in parameter numBytes.
  member procedure flush (self in out nocopy utl_BinaryOutputStream),
  ---- this procedure insures that any buffered bytes are copied to the node
  ---- destination.
  member procedure close (self in out nocopy utl_BinaryOutputStream),
   ---- this procedure frees all resources associated with the stream.
  member function isnull (self in out nocopy Utl_BinaryOutputStream)
                                        return boolean
) NOT INSTANTIABLE NOT FINAL;
/

