create type utl_CharacterInputStream authid current_user as object
(
  handle raw(12),
  member function available (self in out nocopy utl_CharacterInputStream)
                             return integer,
   ---- this function returns the number of characters remaining to be read.
  member function read (self in out nocopy utl_CharacterInputStream,
                        numChars in integer default 1,
                        lineFeed in boolean default false)
  return varchar2,
   ---- This function reads the number of characters specified by numChars
   ---- (default value is 1) and returns the characters as a varchar2. If the
   ---- value of lineFeed is true (default value is false) then the reading
   ---- stops if a linefeed character is found.  If there are no remaining
   ----characters a value of null is returned.
  member procedure read (self     in  out nocopy utl_CharacterInputStream,
                         chars    in out nocopy varchar2,
                         numChars in out integer,
                         lineFeed in boolean default false),
   ---- this procedure reads the number of characters specified by parameter
   ---- numChars into the parameter chars. Additionally, the actual number of
   ---- characters read is returned in parameter numChars. If this value is 0,
   ---- then there are no more characters to be read.
   ---- If the value of lineFeed is true (default is false), then reading stops
   ---- if a linefeed character is encountered.
  member procedure read (self   in  out nocopy    utl_CharacterInputStream,
                         chars  in out nocopy varchar2,
                         offset in     integer,
                         numChars in out integer,
                         lineFeed in boolean default false),
   ---- this procedure reads the number of characters specified by parameter
   ---- numChars into the parameter specified by chars, beginning at the offset
   ---- specified by offset. The actual number of characters read is returned
   ---- in parameter numChars. If this value is 0, there are no more characters
   ---- to be read. If the value of lineFeed is true (default is false) then
   ---- reading stops if a lineFeed character is read.
  member procedure close (self in out nocopy utl_CharacterInputStream),
   ---- this procedure releases all resources held by the stream.
  member function isnull (self in out nocopy Utl_CharacterInputStream)
                                        return boolean
) NOT INSTANTIABLE NOT FINAL;
/

