create type utl_CharacterOutputStream authid current_user as object
(
  handle raw(12),
  member function write (self in out nocopy  utl_CharacterOutputStream,
                         chars in out nocopy varchar2,
                         numChars in integer default 1,
                         lineFeed in boolean default false)
  return integer,
  ---- this function writes the number of characters specified by numChars
  ----(default is 1) from parameter chars into the stream and returns the
  ---- actual number of characters written. If the value of lineFeed is
  ---- true (default is false) a lineFeed character is inserted after the
  ---- last character.
  member procedure write (self  in out nocopy utl_CharacterOutputStream,
                          chars in out nocopy varchar2,
                          numChars in out integer,
                          lineFeed in boolean default false),
  ----- this procedure writes the number of characters specified by parameter
  ----- numChars, from parameter chars into the stream. The actual number
  ----- of characters written is returned in parameter numChars. If the value
  ----- of lineFeed is true (default is false) a lineFeed character is
  ----- inserted after the last character.
  member procedure write (self     in out nocopy    utl_CharacterOutputStream,
                  	  chars    in out nocopy    varchar2,
                          offset   in     integer,
                          numChars in out integer,
                          lineFeed in boolean default false),
  ---- this function writes the number of characters specified by parameter
  ---- numChars, from parameter chars, beginning at offset specified by
  ---- parameter offset. The actual number of characters written is returned
  ---- in parameter numChars. If the value of lineFeed is true (default is
  ---- false) a lineFeed character is  inserted after the last character
  member procedure flush (self in out nocopy utl_CharacterOutputStream),
  ---- this procedure copies all characters that may be contained within
  ----buffers to the node value.
  member procedure close (self in out nocopy utl_CharacterOutputStream),
   ---- this procedure releases all resources associated with the stream.
  member function isnull (self in out nocopy Utl_CharacterOutputStream)
                                        return boolean
) NOT INSTANTIABLE NOT FINAL;
/

