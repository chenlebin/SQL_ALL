create type XDBUriType           authid current_user under sys.UriType
(
  spare raw(2000),
  overriding member function getExternalUrl return varchar2 deterministic,
  overriding member function getUrl return varchar2 deterministic,
  -- returns the clob value of the pointed to URL
  overriding member function getClob RETURN clob,
  overriding member function getBlob RETURN blob,
  overriding member function getBlob(csid IN NUMBER) RETURN blob,
  -- returns the value of this URI as an XMLType
  overriding member function getXML return sys.XMLType,
  -- return Info
  overriding member function getContentType RETURN varchar2,
  -- return the XMLType of the resource
  member function getResource RETURN sys.XMLType,
  static function createuri(xdburi in varchar2) return xdburitype,
  constructor function XDBUriType(url in varchar2, spare in raw := null)
    return self as result
)
/

