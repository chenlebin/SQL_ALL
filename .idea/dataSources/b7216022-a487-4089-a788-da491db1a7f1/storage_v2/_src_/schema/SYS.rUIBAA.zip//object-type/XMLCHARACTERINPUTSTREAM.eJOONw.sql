create type XMLCharacterInputStream under utl_CharacterInputStream
(
  constructor function XMLCharacterInputStream (h in raw, n in raw)
  return self as result,

  overriding member function available (self in out nocopy XMLCharacterInputStream)
  return integer,
  ---- this function returns the number of characters remaining to be read.
  overriding member function read (self in out nocopy XMLCharacterInputStream,
                                   numChars in integer default 1,
                                   lineFeed in boolean default false)
   return varchar2,
  ---- this function reads the number of characters specified by numChars
  ---- (default is 1) and returns as a varchar2. If there are no remaining characters
  ---- a value of null is returned. If the value of lineFeed is true
  ---- (default is false) then the reading terminates if a linefeed character is
  ----- encountered.
  overriding member procedure read (self     in out nocopy  XMLCharacterInputStream,
                                    chars    in out nocopy varchar2,
                                    numChars in out integer,
                                    lineFeed in boolean default false),
  ---- this procedure reads the number of characters specified by parameter numChars
  ---- into the parameter chars. Additionally, the actual number of characters read
  ---- is returned in parameter numChars. If this value is 0, then there are no more
  ---- characters to be read. If the value of lineFed is true (default is false),
  ---- then reading is terminated if a linefeed character is found.
  overriding member procedure read (self   in out nocopy XMLCharacterInputStream,
                                    chars  in out nocopy varchar2,
                                    offset in     integer,
                                    numChars in out integer,
                                    lineFeed in boolean default false),
  ---- this procedure reads the number of characters specified by parameter numChars
  ---- into the parameter specified by chars, beginning at the offset specified by
  ---- offset. The actual number of characters read is returned in parameter
  ---- numChars. If this value is 0, there are no more characters to be read.
  ---- If the value of lineFeed is true (default is false), then
  ---- reading is terminated if a lineFeed character is found.
  overriding member procedure close (self in out XMLCharacterInputStream),
   ---- this procedre releases all resources held by the stream.
  overriding member function isnull (self in out nocopy XMLCharacterInputStream)
                                        return boolean
);
/

