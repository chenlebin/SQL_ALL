create type XMLCharacterOutputStream under utl_CharacterOutputStream
(
  constructor function XMLCharacterOutputStream (h in raw, n in raw)
  return self as result,
  overriding member function write (self in out nocopy XMLCharacterOutputStream,
                                    chars   in out nocopy varchar2,
                                    numChars in integer default 1,
                                    lineFeed in boolean default false)
  return integer,
  ---- this function writes the number of characters specified by numChars
  ---- (default is 1) to the stream and returns the actual number of characters
  ---- written. If the value of lineFeed is true (default is false), then a lineFeed
  ---- character is appended after the last character.
  overriding member procedure write (self  in out nocopy XMLCharacterOutputStream,
                                     chars in out nocopy varchar2,
                                     numChars in out integer,
                                     lineFeed in boolean default false),
  ---- this procedure writes the number of characters specified by parameter
  ---- numChars, from parameter chars into the stream. The actual number of
  ---- characters written is returned in parameter numChars. If the value of lineFeed
  ---- is true (default is false) then a lineFeed character is appended after the
  ---- last character.
  overriding member procedure write (self  in out nocopy    XMLCharacterOutputStream,
                                     chars    in  out nocopy   varchar2,
                                     offset   in     integer,
                                     numChars in out integer,
                                     lineFeed in boolean default false),
  ---- this procedure writes the number of characters specified by parameter numChars,
  ---- from parameter chars, beginning at offset specified by parameter offset.
  ---- The actual number of characters written is returned in parameter numChars.
  ---- If the value of lineFeed is true (default is true), then a linefeed character
  ---- is appended after the last character.
  overriding member procedure flush (self in out nocopy XMLCharacterOutputStream),
  ---- this procedure copies all characters that may be contained within buffers
  ---- to the node value.
  overriding member procedure close (self in out nocopy XMLCharacterOutputStream) ,
  ---- this procedure releases all resources associated with the stream.
  overriding member function isnull (self in out nocopy XMLCharacterOutputStream)
                                        return boolean
);
/

