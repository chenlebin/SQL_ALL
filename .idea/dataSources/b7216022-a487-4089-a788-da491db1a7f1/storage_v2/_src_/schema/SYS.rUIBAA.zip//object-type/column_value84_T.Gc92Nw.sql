create TYPE       "column_value84_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","column_name" VARCHAR2(4000 CHAR),"data" "anydata82_T","lob_information" VARCHAR2(4000 CHAR),"lob_offset" NUMBER(38),"lob_operation_size" NUMBER(38),"long_information" VARCHAR2(4000 CHAR))NOT FINAL INSTANTIABLE
/

