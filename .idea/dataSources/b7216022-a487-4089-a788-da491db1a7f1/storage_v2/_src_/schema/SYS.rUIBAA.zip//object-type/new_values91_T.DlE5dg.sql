create TYPE       "new_values91_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","new_value" "old_value90_COLL")FINAL INSTANTIABLE
/

