create TYPE       "old_values89_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","old_value" "old_value90_COLL")FINAL INSTANTIABLE
/

