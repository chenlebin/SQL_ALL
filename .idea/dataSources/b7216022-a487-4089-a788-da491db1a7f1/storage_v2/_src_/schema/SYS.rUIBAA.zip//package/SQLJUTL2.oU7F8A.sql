create package sqljutl2 AUTHID CURRENT_USER as

   -- The following APIs are used for native invocation of
   -- server-side Java code
   FUNCTION evaluate(args LONG RAW) RETURN LONG RAW;
   FUNCTION invoke(handle NUMBER, class VARCHAR2, name VARCHAR2, sig VARCHAR2, args LONG RAW) RETURN LONG RAW;
   FUNCTION invoke(class VARCHAR2, name VARCHAR2, sig VARCHAR2, args LONG RAW) RETURN LONG RAW;
   FUNCTION reflect(class_Or_Package VARCHAR2, only_Declared NUMBER) RETURN LONG;
   FUNCTION reflect2(class_Or_Package VARCHAR2, only_Declared NUMBER) RETURN CLOB;

end sqljutl2;
/

