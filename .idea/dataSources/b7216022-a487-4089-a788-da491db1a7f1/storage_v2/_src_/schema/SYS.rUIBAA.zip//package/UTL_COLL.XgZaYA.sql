create PACKAGE utl_coll wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
b9 d6
1E6p1w9C4063bW1HqiGKlH0mplYwg3nwLZ4VZ3RAkPiOa16Z0f+UqO3oYwTHbJxqCEDiW9GS
+dShW6jPpQi1od906nHnh3KjM4A7S+g5j3Lkl25stKuV2QILZ22DAoW54c0xuJHFsAwF1vEB
lAQLkeaIzzJecUh9NWVM1pRjWIkUafy8xkq4nD4QU609MSguhGU139H59Adq/WBJVt8=
/

