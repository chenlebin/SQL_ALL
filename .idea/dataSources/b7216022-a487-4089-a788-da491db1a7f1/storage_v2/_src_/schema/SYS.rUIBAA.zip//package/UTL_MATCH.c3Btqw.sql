create PACKAGE utl_match IS
   FUNCTION edit_distance(s1 IN VARCHAR2, s2 IN VARCHAR2)
                          RETURN pls_integer;
   PRAGMA interface(c, edit_distance);

   FUNCTION jaro_winkler(s1 IN VARCHAR2, s2 IN VARCHAR2)
                         RETURN binary_double;
   PRAGMA interface(c, jaro_winkler);

   FUNCTION edit_distance_similarity(s1 IN VARCHAR2, s2 IN VARCHAR2)
                                     RETURN pls_integer;
   PRAGMA interface(c, edit_distance_similarity);

   FUNCTION jaro_winkler_similarity(s1 IN VARCHAR2, s2 IN VARCHAR2)
                                    RETURN pls_integer;
   PRAGMA interface(c, jaro_winkler_similarity);

END utl_match;
/

