create PACKAGE utl_ref wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
294 11b
Rfw5toDaaeFxqtjPAi5VmfblysQwgw1p2Z4VfC/SiupWAFx9lcfp4/qjC/bTmw7GbtJdodK1
VRYJid/jylYDft+CR0o4NAGyFc0jSpyGvRoTHV+xxn7Yixas6bi0qP7MIDN38m26yJ4J1StZ
zlNxH5R6nA7WLIcfgYRAKltgmpDE8cPjB2+UgOq8KStQ1e7Tq+YMWtKhZDHsuBwSKb/3BapM
pSVycWVXHiEgx/T5Z1h6OBR1cDZOzo2rYsDiNunI6vIUw+GsuwmfgYrLULecaA==
/

