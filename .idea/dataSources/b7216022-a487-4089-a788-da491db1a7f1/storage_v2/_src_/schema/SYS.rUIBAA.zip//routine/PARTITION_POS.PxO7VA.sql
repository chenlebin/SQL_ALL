create function partition_pos
return binary_integer is
begin
return dbms_standard.partition_pos;
end;
/

