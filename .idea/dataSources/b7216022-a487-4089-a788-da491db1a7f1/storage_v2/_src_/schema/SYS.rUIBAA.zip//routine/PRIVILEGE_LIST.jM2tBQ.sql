create function privilege_list (priv_list out ora_name_list_t)
return binary_integer is
begin
return dbms_standard.privilege_list(priv_list);
end;
/

