create function revokee (user_list out ora_name_list_t)
return binary_integer is
begin
return dbms_standard.revokee(user_list);
end;
/

