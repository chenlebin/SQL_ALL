create function server_error (position binary_integer)
return binary_integer is
begin
return dbms_standard.server_error(position);
end;
/

