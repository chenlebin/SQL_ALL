create function server_error_msg (position in binary_integer)
return varchar2 is
begin
return dbms_standard.server_error_msg(position);
end;
/

