create function server_error_num_params (position in binary_integer)
return binary_integer is
begin
return dbms_standard.server_error_num_params(position);
end;
/

