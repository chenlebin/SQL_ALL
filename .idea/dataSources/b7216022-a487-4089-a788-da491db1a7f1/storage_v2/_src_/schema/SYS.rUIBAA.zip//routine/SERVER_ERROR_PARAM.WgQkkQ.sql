create function server_error_param (position in binary_integer,
                                               param in binary_integer)
return varchar2 is
begin
return dbms_standard.server_error_param(position, param);
end;
/

