create FUNCTION space_error_info
        (error_type          OUT VARCHAR2,
         object_type         OUT VARCHAR2,
         object_owner        OUT VARCHAR2,
         table_space_name    OUT VARCHAR2,
         object_name         OUT VARCHAR2,
         sub_object_name     OUT VARCHAR2) RETURN BOOLEAN IS
BEGIN
  RETURN dbms_resumable.space_error_info(error_type, object_type,
                                         object_owner, table_space_name,
                                         object_name, sub_object_name);
END;
/

