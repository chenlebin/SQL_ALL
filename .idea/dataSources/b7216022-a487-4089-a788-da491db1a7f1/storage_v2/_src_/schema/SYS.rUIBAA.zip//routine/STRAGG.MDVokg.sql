create FUNCTION stragg(input varchar2 )
RETURN varchar2
AGGREGATE USING string_agg_type;
/

