create function sysevent return varchar2 is
begin
  return dbms_standard.sysevent;
end;
/

