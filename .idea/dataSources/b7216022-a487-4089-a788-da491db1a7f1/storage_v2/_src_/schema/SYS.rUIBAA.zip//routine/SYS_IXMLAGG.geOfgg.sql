create function SYS_IXMLAGG(input sys.xmltype) return sys.xmltype
aggregate using AggXMLImp;
/

