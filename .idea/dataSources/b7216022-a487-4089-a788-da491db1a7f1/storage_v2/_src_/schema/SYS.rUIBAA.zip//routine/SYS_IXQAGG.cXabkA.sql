create function SYS_IXQAGG(input sys.xmltype) return sys.xmltype
aggregate using AggXQImp;
/

