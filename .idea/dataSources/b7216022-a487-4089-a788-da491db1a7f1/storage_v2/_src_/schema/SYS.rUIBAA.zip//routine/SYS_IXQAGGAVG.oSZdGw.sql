create function SYS_IXQAGGAVG(input sys.xmltype) return sys.xmltype
aggregate using AggXQAvgImp;
/

