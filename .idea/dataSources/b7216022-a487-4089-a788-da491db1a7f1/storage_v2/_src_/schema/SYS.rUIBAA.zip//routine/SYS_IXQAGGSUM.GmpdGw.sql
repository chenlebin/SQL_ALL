create function SYS_IXQAGGSUM(input sys.xmltype) return sys.xmltype
aggregate using AggXQSumImp;
/

