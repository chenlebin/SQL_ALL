create function SYS_NT_COLLECT(obj IN AnyData)
return sys.AnyDataSet parallel_enable
aggregate using SYS_NT_COLLECT_IMP;
/

