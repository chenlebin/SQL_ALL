create function timestamp_to_scn(query_time IN TIMESTAMP)
return NUMBER
IS EXTERNAL
NAME "ktfexttoscn"
WITH CONTEXT
PARAMETERS(context,
           query_time OCIDATETIME,
           RETURN)
LIBRARY DBMS_TRAN_LIB;
/

