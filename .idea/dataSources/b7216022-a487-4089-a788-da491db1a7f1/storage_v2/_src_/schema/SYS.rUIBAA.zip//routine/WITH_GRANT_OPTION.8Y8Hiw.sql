create function with_grant_option return boolean is
begin
return dbms_standard.with_grant_option;
end;
/

