create function XMLSequenceFromRefCursor(data SYS_REFCURSOR,
                            format IN XMLFormat := NULL)
       return sys.XMLSequenceType authid current_user
pipelined using XMLSeqCur_Imp_t;
/

