create function XMLSequenceFromRefCursor2( data SYS_REFCURSOR )
       return sys.XMLSequenceType authid current_user
pipelined using XMLSeqCur2_Imp_t;
/

