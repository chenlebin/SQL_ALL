create function XMLSequenceFromXMLType(doc in sys.XMLType)
       return sys.XMLSequenceType authid current_user
pipelined using XMLSeq_Imp_t;
/

