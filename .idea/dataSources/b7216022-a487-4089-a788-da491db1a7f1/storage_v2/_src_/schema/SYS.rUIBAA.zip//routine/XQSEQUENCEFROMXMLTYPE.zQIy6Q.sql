create function XQSequenceFromXMLType(doc in sys.XMLType)
       return sys.XMLSequenceType authid current_user
pipelined using XQSeq_Imp_t;
/

