create view ALL_APPLY
            (APPLY_NAME, QUEUE_NAME, QUEUE_OWNER, APPLY_CAPTURED, RULE_SET_NAME, RULE_SET_OWNER, APPLY_USER,
             APPLY_DATABASE_LINK, APPLY_TAG, DDL_HANDLER, PRECOMMIT_HANDLER, MESSAGE_HANDLER, STATUS,
             MAX_APPLIED_MESSAGE_NUMBER, NEGATIVE_RULE_SET_NAME, NEGATIVE_RULE_SET_OWNER, STATUS_CHANGE_TIME,
             ERROR_NUMBER, ERROR_MESSAGE, MESSAGE_DELIVERY_MODE, PURPOSE)
as
select a."APPLY_NAME",a."QUEUE_NAME",a."QUEUE_OWNER",a."APPLY_CAPTURED",a."RULE_SET_NAME",a."RULE_SET_OWNER",a."APPLY_USER",a."APPLY_DATABASE_LINK",a."APPLY_TAG",a."DDL_HANDLER",a."PRECOMMIT_HANDLER",a."MESSAGE_HANDLER",a."STATUS",a."MAX_APPLIED_MESSAGE_NUMBER",a."NEGATIVE_RULE_SET_NAME",a."NEGATIVE_RULE_SET_OWNER",a."STATUS_CHANGE_TIME",a."ERROR_NUMBER",a."ERROR_MESSAGE",a."MESSAGE_DELIVERY_MODE",a."PURPOSE"
  from dba_apply a, all_queues q
 where a.queue_name = q.name
   and a.queue_owner = q.owner
   and ((a.rule_set_owner is null and a.rule_set_name is null) or
        ((a.rule_set_owner, a.rule_set_name) in
          (select r.rule_set_owner, r.rule_set_name
             from all_rule_sets r)))
   and ((a.negative_rule_set_owner is null and
         a.negative_rule_set_name is null) or
        ((a.negative_rule_set_owner, a.negative_rule_set_name) in
          (select r.rule_set_owner, r.rule_set_name
             from all_rule_sets r)))
/

comment on table ALL_APPLY is 'Details about each apply process that dequeues from the queue visible to the current user'
/

comment on column ALL_APPLY.APPLY_NAME is 'Name of the apply process'
/

comment on column ALL_APPLY.QUEUE_NAME is 'Name of the queue the apply process dequeues from'
/

comment on column ALL_APPLY.QUEUE_OWNER is 'Owner of the queue the apply process dequeues from'
/

comment on column ALL_APPLY.APPLY_CAPTURED is 'Yes, if applying captured messages; No, if applying enqueued messages'
/

comment on column ALL_APPLY.RULE_SET_NAME is 'Rule set used by apply process for filtering'
/

comment on column ALL_APPLY.RULE_SET_OWNER is 'Owner of the rule set'
/

comment on column ALL_APPLY.APPLY_USER is 'Current user who is applying the messages'
/

comment on column ALL_APPLY.APPLY_DATABASE_LINK is 'For remote objects, the database link pointing to the remote database'
/

comment on column ALL_APPLY.APPLY_TAG is 'Tag associated with DDL and DML change records that will be applied'
/

comment on column ALL_APPLY.DDL_HANDLER is 'Name of the user specified ddl handler'
/

comment on column ALL_APPLY.PRECOMMIT_HANDLER is 'Name of the user specified precommit handler'
/

comment on column ALL_APPLY.MESSAGE_HANDLER is 'User specified procedure to handle messages other than DDL and DML messages'
/

comment on column ALL_APPLY.STATUS is 'Status of the apply process: DISABLED, ENABLED, ABORTED'
/

comment on column ALL_APPLY.MAX_APPLIED_MESSAGE_NUMBER is 'Maximum value of message that has been applied'
/

comment on column ALL_APPLY.NEGATIVE_RULE_SET_NAME is 'Negative rule set used by apply process for filtering'
/

comment on column ALL_APPLY.NEGATIVE_RULE_SET_OWNER is 'Owner of the negative rule set'
/

comment on column ALL_APPLY.STATUS_CHANGE_TIME is 'The time that STATUS of the apply process was changed'
/

comment on column ALL_APPLY.ERROR_NUMBER is 'Error number if the apply process was aborted'
/

comment on column ALL_APPLY.ERROR_MESSAGE is 'Error message if the apply process was aborted'
/

comment on column ALL_APPLY.PURPOSE is 'Purpose of this apply process '
/

