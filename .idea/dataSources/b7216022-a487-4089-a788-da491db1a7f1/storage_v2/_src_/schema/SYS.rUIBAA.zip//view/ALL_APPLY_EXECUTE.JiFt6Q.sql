create view ALL_APPLY_EXECUTE (RULE_OWNER, RULE_NAME, EXECUTE_EVENT) as
select e."RULE_OWNER",e."RULE_NAME",e."EXECUTE_EVENT"
from dba_apply_execute e, ALL_RULES r
where e.rule_owner = r.rule_owner and e.rule_name = r.rule_name
/

comment on table ALL_APPLY_EXECUTE is 'Details about the apply execute action for all rules visible to the user'
/

comment on column ALL_APPLY_EXECUTE.RULE_OWNER is 'Owner of the rule'
/

comment on column ALL_APPLY_EXECUTE.RULE_NAME is 'Name of the rule'
/

comment on column ALL_APPLY_EXECUTE.EXECUTE_EVENT is 'Whether the event satisfying the rule is executed'
/

