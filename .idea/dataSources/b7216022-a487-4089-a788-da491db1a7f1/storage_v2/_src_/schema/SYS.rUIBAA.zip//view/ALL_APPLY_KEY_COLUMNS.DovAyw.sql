create view ALL_APPLY_KEY_COLUMNS (OBJECT_OWNER, OBJECT_NAME, COLUMN_NAME, APPLY_DATABASE_LINK) as
select k.object_owner, k.object_name, k.column_name, k.apply_database_link
  from all_tab_columns a, dba_apply_key_columns k
 where k.object_owner = a.owner
   and k.object_name = a.table_name
   and k.column_name = a.column_name
/

comment on table ALL_APPLY_KEY_COLUMNS is 'Alternative key columns for a STREAMS table visible to the current user'
/

comment on column ALL_APPLY_KEY_COLUMNS.OBJECT_OWNER is 'Owner of the object'
/

comment on column ALL_APPLY_KEY_COLUMNS.OBJECT_NAME is 'Name of the object'
/

comment on column ALL_APPLY_KEY_COLUMNS.COLUMN_NAME is 'Column name of the object'
/

comment on column ALL_APPLY_KEY_COLUMNS.APPLY_DATABASE_LINK is 'Remote database link to which changes will be aplied'
/

