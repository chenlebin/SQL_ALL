create view ALL_AW_PS (OWNER, AW_NUMBER, AW_NAME, PSNUMBER, GENERATIONS, MAXPAGES) as
SELECT u.name, a.awseq#, a.awname, p.psnumber, count(unique(p.psgen)), max(p.maxpages)
FROM aw$ a, ps$ p, user$ u, sys.obj$ o
WHERE  a.owner#=u.user#
       and o.owner# = a.owner#
       and o.name = 'AW$' || a.awname and o.type#= 2 /* type for table */
       and a.awseq#=p.awseq#
       and (a.owner# in (userenv('SCHEMAID'), 1)   /* public objects */
            or
            o.obj# in ( select obj#  /* directly granted privileges */
                        from sys.objauth$
                        where grantee# in ( select kzsrorol from x$kzsro )
                      )
            or   /* user has system privileges */
              ( exists (select null from v$enabledprivs
                        where priv_number in (-45 /* LOCK ANY TABLE */,
                                              -47 /* SELECT ANY TABLE */,
                                              -48 /* INSERT ANY TABLE */,
                                              -49 /* UPDATE ANY TABLE */,
                                              -50 /* DELETE ANY TABLE */)
                        )
              )
            )
group by a.awseq#, a.awname, u.name, p.psnumber
/

comment on table ALL_AW_PS is 'Pagespaces in Analytic Workspaces accessible to the user'
/

comment on column ALL_AW_PS.OWNER is 'Owner of the Analytic Workspace'
/

comment on column ALL_AW_PS.AW_NAME is 'Name of the Analytic Workspace'
/

comment on column ALL_AW_PS.PSNUMBER is 'Number of the pagespace'
/

comment on column ALL_AW_PS.GENERATIONS is 'Number of active generations in the pagespace'
/

comment on column ALL_AW_PS.MAXPAGES is 'Maximum pages allocated in the pagespace'
/

