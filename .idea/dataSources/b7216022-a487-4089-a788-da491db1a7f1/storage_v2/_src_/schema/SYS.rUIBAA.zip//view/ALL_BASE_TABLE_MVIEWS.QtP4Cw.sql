create view ALL_BASE_TABLE_MVIEWS (OWNER, MASTER, MVIEW_LAST_REFRESH_TIME, MVIEW_ID) as
select s."OWNER",s."MASTER",s."MVIEW_LAST_REFRESH_TIME",s."MVIEW_ID" from dba_base_table_mviews s, all_mview_logs a
where a.log_owner = s.owner
  and a.master = s.master
/

comment on table ALL_BASE_TABLE_MVIEWS is 'All materialized views with log(s) in the database that the user can see'
/

comment on column ALL_BASE_TABLE_MVIEWS.OWNER is 'Owner of the master table which changes are logged'
/

comment on column ALL_BASE_TABLE_MVIEWS.MASTER is 'Name of the master table which changes are logged'
/

comment on column ALL_BASE_TABLE_MVIEWS.MVIEW_LAST_REFRESH_TIME is 'One date per materialized view -- the date the materialized view was last refreshed'
/

comment on column ALL_BASE_TABLE_MVIEWS.MVIEW_ID is 'Unique identifier of the materialized view'
/

