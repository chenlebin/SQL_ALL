create view ALL_EVALUATION_CONTEXTS
            (EVALUATION_CONTEXT_OWNER, EVALUATION_CONTEXT_NAME, EVALUATION_FUNCTION, EVALUATION_CONTEXT_COMMENT) as
SELECT /*+ all_rows */
       u.name, o.name, ec.eval_func, ec.ec_comment
FROM   rule_ec$ ec, obj$ o, user$ u
WHERE  ec.obj# = o.obj# and
       (o.owner# in (USERENV('SCHEMAID'), 1 /* PUBLIC */) or
        o.obj# in (select oa.obj# from sys.objauth$ oa
                   where grantee# in (select kzsrorol from x$kzsro)) or
        exists (select null from v$enabledprivs where priv_number in (
                 -246, /* create any evaluation context */
                 -247, /* alter any evaluation context */
                 -248, /* drop any evaluation context */
                 -249  /* execute any evaluation context */))) and
       o.owner# = u.user#
/

comment on table ALL_EVALUATION_CONTEXTS is 'rule evaluation contexts seen by user'
/

comment on column ALL_EVALUATION_CONTEXTS.EVALUATION_CONTEXT_OWNER is 'Owner of the evaluation context'
/

comment on column ALL_EVALUATION_CONTEXTS.EVALUATION_CONTEXT_NAME is 'Name of the evaluation context'
/

comment on column ALL_EVALUATION_CONTEXTS.EVALUATION_FUNCTION is 'User supplied function to evaluate rules'
/

comment on column ALL_EVALUATION_CONTEXTS.EVALUATION_CONTEXT_COMMENT is 'user description of the evaluation context'
/

