create view ALL_EVALUATION_CONTEXT_VARS
            (EVALUATION_CONTEXT_OWNER, EVALUATION_CONTEXT_NAME, VARIABLE_NAME, VARIABLE_TYPE, VARIABLE_VALUE_FUNCTION,
             VARIABLE_METHOD_FUNCTION)
as
SELECT /*+ all_rows */
       u.name, o.name, ecv.var_name, ecv.var_type, ecv.var_val_func,
       ecv.var_mthd_func
FROM   rec_var$ ecv, obj$ o, user$ u
WHERE  ecv.ec_obj# = o.obj# and
       (o.owner# in (USERENV('SCHEMAID'), 1 /* PUBLIC */) or
        o.obj# in (select oa.obj# from sys.objauth$ oa
                   where grantee# in (select kzsrorol from x$kzsro)) or
        exists (select null from v$enabledprivs where priv_number in (
                 -246, /* create any evaluation context */
                 -247, /* alter any evaluation context */
                 -248, /* drop any evaluation context */
                 -249  /* execute any evaluation context */))) and
       o.owner# = u.user#
/

comment on table ALL_EVALUATION_CONTEXT_VARS is 'variables in all rule evaluation contexts seen by the user'
/

comment on column ALL_EVALUATION_CONTEXT_VARS.EVALUATION_CONTEXT_OWNER is 'Owner of the evaluation context'
/

comment on column ALL_EVALUATION_CONTEXT_VARS.EVALUATION_CONTEXT_NAME is 'Name of the evaluation context'
/

comment on column ALL_EVALUATION_CONTEXT_VARS.VARIABLE_NAME is 'Name of the variable'
/

comment on column ALL_EVALUATION_CONTEXT_VARS.VARIABLE_VALUE_FUNCTION is 'Function to provide variable value'
/

comment on column ALL_EVALUATION_CONTEXT_VARS.VARIABLE_METHOD_FUNCTION is 'Function to provide variable method return value'
/

