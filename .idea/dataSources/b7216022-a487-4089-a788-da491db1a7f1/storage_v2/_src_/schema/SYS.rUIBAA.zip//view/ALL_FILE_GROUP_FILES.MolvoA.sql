create view ALL_FILE_GROUP_FILES
            (FILE_GROUP_OWNER, FILE_GROUP_NAME, VERSION_NAME, VERSION, FILE_NAME, FILE_DIRECTORY, FILE_TYPE, FILE_SIZE,
             FILE_BLOCK_SIZE, COMMENTS)
as
select file_group_owner, file_group_name, version_name,
     version_id, file_name, file_directory, file_type, file_size,
     file_blocksize, comments
from "_ALL_FILE_GROUP_FILES"
/

comment on table ALL_FILE_GROUP_FILES is 'Details about file group files'
/

comment on column ALL_FILE_GROUP_FILES.FILE_GROUP_OWNER is 'Owner of the file group'
/

comment on column ALL_FILE_GROUP_FILES.FILE_GROUP_NAME is 'Name of the file group'
/

comment on column ALL_FILE_GROUP_FILES.VERSION_NAME is 'Name of the version'
/

comment on column ALL_FILE_GROUP_FILES.VERSION is 'Internal version number'
/

comment on column ALL_FILE_GROUP_FILES.FILE_NAME is 'Name of the file'
/

comment on column ALL_FILE_GROUP_FILES.FILE_DIRECTORY is 'Directory object for the file'
/

comment on column ALL_FILE_GROUP_FILES.FILE_TYPE is 'File type'
/

comment on column ALL_FILE_GROUP_FILES.FILE_SIZE is 'File size'
/

comment on column ALL_FILE_GROUP_FILES.FILE_BLOCK_SIZE is 'File block size'
/

comment on column ALL_FILE_GROUP_FILES.COMMENTS is 'User specified comment'
/

