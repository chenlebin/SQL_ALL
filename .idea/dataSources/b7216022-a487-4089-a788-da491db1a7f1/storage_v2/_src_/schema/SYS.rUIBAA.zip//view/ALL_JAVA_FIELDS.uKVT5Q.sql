create view ALL_JAVA_FIELDS
            (OWNER, NAME, FIELD_INDEX, FIELD_NAME, ACCESSIBILITY, IS_STATIC, IS_FINAL, IS_VOLATILE, IS_TRANSIENT,
             ARRAY_DEPTH, BASE_TYPE, FIELD_CLASS)
as
select /*+ ordered use_nl(o m) */ u.name, nvl(j.longdbcs, o.name), m.fix, m.fnm,
       decode(BITAND(m.fac, 7), 1, 'PUBLIC',
                                2, 'PRIVATE',
                                4, 'PROTECTED',
                                NULL),
       decode(BITAND(m.fac, 8), 8, 'YES',
                                0, 'NO'),
       decode(BITAND(m.fac, 16), 16, 'YES',
                                 0, 'NO'),
       decode(BITAND(m.fac, 64), 64, 'YES',
                                 0, 'NO'),
       decode(BITAND(m.fac, 128), 128, 'YES',
                                  0, 'NO'),
       m.fad,
       decode(m.fbt, 10, 'int',
                     11, 'long',
                     6, 'float',
                     7, 'double',
                     4, 'boolean',
                     8, 'byte',
                     5, 'char',
                     9, 'short',
                     2, 'class',
                     NULL),
       m.fln
from sys.javasnm$ j, sys.obj$ o, sys.x$joxmfd m, sys.user$ u
where o.obj# = m.obn
  and o.type# = 29
  and o.owner# = u.user#
  and j.short(+) = o.name
  and
  (
    o.owner# in (userenv('SCHEMAID'), 1 /* PUBLIC */)
    or
    (
      (
        (
          o.obj# in (select obj# from sys.objauth$
                     where grantee# in (select kzsrorol from x$kzsro)
                       and privilege#  = 12 /* EXECUTE */)
        )
        or
        exists
        (
          select null from sys.sysauth$
          where grantee# in (select kzsrorol from x$kzsro)
          and
          (
            (
              /* procedure */
              (
                privilege# = -144 /* EXECUTE ANY PROCEDURE */
                or
                privilege# = -141 /* CREATE ANY PROCEDURE */
              )
            )
          )
        )
      )
    )
  )
/

comment on table ALL_JAVA_FIELDS is 'field information of stored java class accessible to user'
/

comment on column ALL_JAVA_FIELDS.OWNER is 'owner of the stored java class'
/

comment on column ALL_JAVA_FIELDS.NAME is 'name of the java class'
/

comment on column ALL_JAVA_FIELDS.FIELD_INDEX is 'the index of the field'
/

comment on column ALL_JAVA_FIELDS.FIELD_NAME is 'the name of the field at FIELD_INDEX'
/

comment on column ALL_JAVA_FIELDS.ACCESSIBILITY is 'the accessiblity of the field, public/private/protected/null(i.e. package)'
/

comment on column ALL_JAVA_FIELDS.IS_STATIC is 'is the field a static field?'
/

comment on column ALL_JAVA_FIELDS.IS_FINAL is 'is the field a final field?'
/

comment on column ALL_JAVA_FIELDS.IS_VOLATILE is 'is the field volotile?'
/

comment on column ALL_JAVA_FIELDS.IS_TRANSIENT is 'is the field transient?'
/

comment on column ALL_JAVA_FIELDS.ARRAY_DEPTH is 'array depth of the type of the field'
/

comment on column ALL_JAVA_FIELDS.BASE_TYPE is 'base type of the type of the field'
/

comment on column ALL_JAVA_FIELDS.FIELD_CLASS is 'if base_type is class, this gives the actual class name of the base object'
/

