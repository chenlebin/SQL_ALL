create view ALL_JAVA_THROWS (OWNER, NAME, METHOD_INDEX, METHOD_NAME, EXCEPTION_INDEX, EXCEPTION_CLASS) as
select /*+ ordered use_nl(o mmd) */ u.name, nvl(j.longdbcs, o.name), mmd.mix, mmd.mnm, mex.xix, mex.xln
from sys.javasnm$ j, sys.obj$ o, sys.x$joxmex mex, sys.x$joxmmd mmd, sys.user$ u
where o.obj# = mmd.obn
  and o.type# = 29
  and o.owner# = u.user#
  and j.short(+) = o.name
  and mmd.mix = mex.mix
  and mmd.obn = mex.obn
  and
  (
    o.owner# in (userenv('SCHEMAID'), 1 /* PUBLIC */)
    or
    (
      (
        (
          o.obj# in (select obj# from sys.objauth$
                     where grantee# in (select kzsrorol from x$kzsro)
                       and privilege#  = 12 /* EXECUTE */)
        )
        or
        exists
        (
          select null from sys.sysauth$
          where grantee# in (select kzsrorol from x$kzsro)
          and
          (
            (
              /* procedure */
              (
                privilege# = -144 /* EXECUTE ANY PROCEDURE */
                or
                privilege# = -141 /* CREATE ANY PROCEDURE */
              )
            )
          )
        )
      )
    )
  )
/

comment on table ALL_JAVA_THROWS is 'list of exceptions thrown from a method of a class accessible to user'
/

comment on column ALL_JAVA_THROWS.OWNER is 'owner of the stored java class'
/

comment on column ALL_JAVA_THROWS.NAME is 'name of the java class'
/

comment on column ALL_JAVA_THROWS.METHOD_INDEX is 'the index of throwing method of the exception'
/

comment on column ALL_JAVA_THROWS.METHOD_NAME is 'the name of throwing method of the exception'
/

comment on column ALL_JAVA_THROWS.EXCEPTION_INDEX is 'the index of the exception'
/

comment on column ALL_JAVA_THROWS.EXCEPTION_CLASS is 'the class of the exception'
/

