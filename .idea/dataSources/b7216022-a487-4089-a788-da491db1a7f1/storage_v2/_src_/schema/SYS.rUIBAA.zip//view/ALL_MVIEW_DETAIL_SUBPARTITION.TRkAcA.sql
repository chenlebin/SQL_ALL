create view ALL_MVIEW_DETAIL_SUBPARTITION
            (OWNER, MVIEW_NAME, DETAILOBJ_OWNER, DETAILOBJ_NAME, DETAIL_PARTITION_NAME, DETAIL_SUBPARTITION_NAME,
             DETAIL_SUBPARTITION_POSITION, FRESHNESS)
as
select m."OWNER",m."MVIEW_NAME",m."DETAILOBJ_OWNER",m."DETAILOBJ_NAME",m."DETAIL_PARTITION_NAME",m."DETAIL_SUBPARTITION_NAME",m."DETAIL_SUBPARTITION_POSITION",m."FRESHNESS" from dba_mview_detail_subpartition m, sys.obj$ o, sys.user$ u
where o.owner#     = u.user#
  and m.mview_name = o.name
  and u.name       = m.owner
  and o.type#      = 2                     /* table */
  and ( u.user# in (userenv('SCHEMAID'), 1)
        or
        o.obj# in ( select obj#
                    from sys.objauth$
                    where grantee# in ( select kzsrorol
                                        from x$kzsro
                                      )
                  )
        or /* user has system privileges */
        exists ( select null from v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */)
               )
      )
/

comment on table ALL_MVIEW_DETAIL_SUBPARTITION is 'Freshness information of all PCT materialized views in the database'
/

comment on column ALL_MVIEW_DETAIL_SUBPARTITION.OWNER is 'Owner of the materialized view'
/

comment on column ALL_MVIEW_DETAIL_SUBPARTITION.MVIEW_NAME is 'Name of the materialized view'
/

comment on column ALL_MVIEW_DETAIL_SUBPARTITION.DETAILOBJ_NAME is 'Name of the detail object'
/

comment on column ALL_MVIEW_DETAIL_SUBPARTITION.DETAIL_PARTITION_NAME is 'Name of the detail object partition'
/

comment on column ALL_MVIEW_DETAIL_SUBPARTITION.DETAIL_SUBPARTITION_NAME is 'Name of the detail object subpartition'
/

comment on column ALL_MVIEW_DETAIL_SUBPARTITION.DETAIL_SUBPARTITION_POSITION is 'Position of the detail object subpartition'
/

comment on column ALL_MVIEW_DETAIL_SUBPARTITION.FRESHNESS is 'Freshness of the detail object partition'
/

