create view ALL_OPARGUMENTS (OWNER, OPERATOR_NAME, BINDING#, POSITION, ARGUMENT_TYPE) as
select  c.name, b.name, a.bind#, a.position, a.type
  from  sys.oparg$ a, sys.obj$ b, sys.user$ c
  where a.obj# = b.obj# and b.owner# = c.user#
  and  (b.owner# = userenv ('SCHEMAID')
        or
        b.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
           or exists (select null from v$enabledprivs
                  where priv_number in (-200 /* CREATE OPERATOR */,
                                        -201 /* CREATE ANY OPERATOR */,
                                        -202 /* ALTER ANY OPERATOR */,
                                        -203 /* DROP ANY OPERATOR */,
                                        -204 /* EXECUTE OPERATOR */)
                 )
      )
/

comment on table ALL_OPARGUMENTS is 'All arguments of the operators available to the user'
/

comment on column ALL_OPARGUMENTS.OWNER is 'Owner of the operator'
/

comment on column ALL_OPARGUMENTS.OPERATOR_NAME is 'Name of the operator'
/

comment on column ALL_OPARGUMENTS.BINDING# is 'Binding# of the operator'
/

comment on column ALL_OPARGUMENTS.POSITION is 'Position of the operator argument'
/

comment on column ALL_OPARGUMENTS.ARGUMENT_TYPE is 'Datatype of the operator argument'
/

