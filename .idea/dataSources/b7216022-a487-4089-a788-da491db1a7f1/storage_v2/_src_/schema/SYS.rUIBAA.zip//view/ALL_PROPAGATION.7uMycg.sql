create view ALL_PROPAGATION
            (PROPAGATION_NAME, SOURCE_QUEUE_OWNER, SOURCE_QUEUE_NAME, DESTINATION_QUEUE_OWNER, DESTINATION_QUEUE_NAME,
             DESTINATION_DBLINK, RULE_SET_OWNER, RULE_SET_NAME, NEGATIVE_RULE_SET_OWNER, NEGATIVE_RULE_SET_NAME,
             QUEUE_TO_QUEUE, STATUS, ERROR_MESSAGE, ERROR_DATE, ORIGINAL_PROPAGATION_NAME, ORIGINAL_SOURCE_QUEUE_OWNER,
             ORIGINAL_SOURCE_QUEUE_NAME, ACKED_SCN, AUTO_MERGE_THRESHOLD)
as
SELECT p."PROPAGATION_NAME",p."SOURCE_QUEUE_OWNER",p."SOURCE_QUEUE_NAME",p."DESTINATION_QUEUE_OWNER",p."DESTINATION_QUEUE_NAME",p."DESTINATION_DBLINK",p."RULE_SET_OWNER",p."RULE_SET_NAME",p."NEGATIVE_RULE_SET_OWNER",p."NEGATIVE_RULE_SET_NAME",p."QUEUE_TO_QUEUE",p."STATUS",p."ERROR_MESSAGE",p."ERROR_DATE",p."ORIGINAL_PROPAGATION_NAME",p."ORIGINAL_SOURCE_QUEUE_OWNER",p."ORIGINAL_SOURCE_QUEUE_NAME",p."ACKED_SCN",p."AUTO_MERGE_THRESHOLD"
FROM   dba_propagation p, all_queues q
WHERE p.source_queue_owner = q.owner
   AND p.source_queue_name = q.name
   AND ((p.rule_set_owner IS NULL and p.rule_set_name IS NULL) OR
        ((p.rule_set_owner, p.rule_set_name) IN
          (SELECT r.rule_set_owner, r.rule_set_name
             FROM all_rule_sets r)))
   AND ((p.negative_rule_set_owner IS NULL AND
         p.negative_rule_set_name IS NULL) OR
        ((p.negative_rule_set_owner, p.negative_rule_set_name) IN
          (SELECT r.rule_set_owner, r.rule_set_name
             FROM all_rule_sets r)))
/

comment on table ALL_PROPAGATION is 'Streams propagation seen by the user'
/

comment on column ALL_PROPAGATION.PROPAGATION_NAME is 'name of the Streams propagation'
/

comment on column ALL_PROPAGATION.SOURCE_QUEUE_OWNER is 'owner of the propgation source queue'
/

comment on column ALL_PROPAGATION.SOURCE_QUEUE_NAME is 'name of the propagation source queue'
/

comment on column ALL_PROPAGATION.DESTINATION_QUEUE_OWNER is 'owner of the propagation destination queue'
/

comment on column ALL_PROPAGATION.DESTINATION_QUEUE_NAME is 'name of the propagation destination queue'
/

comment on column ALL_PROPAGATION.DESTINATION_DBLINK is 'database link to access the propagation destination queue'
/

comment on column ALL_PROPAGATION.RULE_SET_OWNER is 'propagation rule set owner'
/

comment on column ALL_PROPAGATION.RULE_SET_NAME is 'propagation rule set name'
/

comment on column ALL_PROPAGATION.NEGATIVE_RULE_SET_OWNER is 'propagation negative rule set owner'
/

comment on column ALL_PROPAGATION.NEGATIVE_RULE_SET_NAME is 'propagation negative rule set name'
/

comment on column ALL_PROPAGATION.STATUS is 'Status of the propagation: DISABLED, ENABLED, ABORTED'
/

comment on column ALL_PROPAGATION.ERROR_MESSAGE is 'Error message last encountered by propagation'
/

comment on column ALL_PROPAGATION.ERROR_DATE is 'The time that propagation last encountered an error'
/

