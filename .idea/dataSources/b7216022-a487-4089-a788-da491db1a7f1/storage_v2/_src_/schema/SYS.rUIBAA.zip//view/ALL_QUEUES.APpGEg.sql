create view ALL_QUEUES
            (OWNER, NAME, QUEUE_TABLE, QID, QUEUE_TYPE, MAX_RETRIES, RETRY_DELAY, ENQUEUE_ENABLED, DEQUEUE_ENABLED,
             RETENTION, USER_COMMENT, NETWORK_NAME)
as
select u.name OWNER, q.name NAME, t.name QUEUE_TABLE, q.eventid QID,
       decode(q.usage, 1, 'EXCEPTION_QUEUE', 2, 'NON_PERSISTENT_QUEUE',
              'NORMAL_QUEUE') QUEUE_TYPE,
       q.max_retries MAX_RETRIES, q.retry_delay RETRY_DELAY,
       decode(bitand(q.enable_flag, 1), 1 , '  YES  ', '  NO  ')ENQUEUE_ENABLED,
       decode(bitand(q.enable_flag, 2), 2 , '  YES  ', '  NO  ')DEQUEUE_ENABLED,
       decode(q.ret_time, -1, ' FOREVER', q.ret_time) RETENTION,
       substr(q.queue_comment, 1, 50) USER_COMMENT,
       s.network_name NETWORK_NAME
from system.aq$_queues q, system.aq$_queue_tables t, sys.user$ u, sys.obj$ ro,
dba_services s
where u.name  = t.schema
and   q.table_objno = t.objno
and   ro.owner# = u.user#
and   ro.obj# = q.eventid
and  (ro.owner# = userenv('SCHEMAID')
      or ro.obj# in
           (select oa.obj#
            from sys.objauth$ oa
            where grantee# in (select kzsrorol from x$kzsro))
      or exists (select null from v$enabledprivs
                 where priv_number in (-218 /* MANAGE ANY QUEUE */,
                                       -219 /* ENQUEUE ANY QUEUE */,
                                       -220 /* DEQUEUE ANY QUEUE */))
      or ro.obj# in
           (select q.eventid from system.aq$_queues q,
                                  system.aq$_queue_tables t
              where q.table_objno = t.objno
              and bitand(t.flags, 8) = 0
              and exists (select null from sys.objauth$ oa, sys.obj$ o
                          where oa.obj# = o.obj#
                          and (o.name = 'DBMS_AQ' or o.name = 'DBMS_AQADM')
                          and o.owner# = 0
                          and o.type# = 9
                          and oa.grantee# = userenv('SCHEMAID')))
     )
and   q.service_name = s.name (+)
/

comment on table ALL_QUEUES is 'All queues accessible to the user'
/

comment on column ALL_QUEUES.OWNER is 'Owner of the queue'
/

comment on column ALL_QUEUES.NAME is 'Name of the queue'
/

comment on column ALL_QUEUES.QUEUE_TABLE is 'Name of the table the queue data resides in'
/

comment on column ALL_QUEUES.QID is 'Object number of the queue'
/

comment on column ALL_QUEUES.QUEUE_TYPE is 'Type of the queue'
/

comment on column ALL_QUEUES.MAX_RETRIES is 'Maximum number of retries allowed when dequeuing from the queue'
/

comment on column ALL_QUEUES.RETRY_DELAY is 'Time interval between retries'
/

comment on column ALL_QUEUES.ENQUEUE_ENABLED is 'Queue is enabled for enqueue'
/

comment on column ALL_QUEUES.DEQUEUE_ENABLED is 'Queue is enabled for dequeue'
/

comment on column ALL_QUEUES.RETENTION is 'Time interval processed messages retained in the queue'
/

comment on column ALL_QUEUES.USER_COMMENT is 'User specified comment'
/

comment on column ALL_QUEUES.NETWORK_NAME is 'Network name of queue service'
/

