create view ALL_REGISTERED_SNAPSHOTS
            (OWNER, NAME, SNAPSHOT_SITE, CAN_USE_LOG, UPDATABLE, REFRESH_METHOD, SNAPSHOT_ID, VERSION, QUERY_TXT) as
select  "OWNER","NAME","SNAPSHOT_SITE","CAN_USE_LOG","UPDATABLE","REFRESH_METHOD","SNAPSHOT_ID","VERSION","QUERY_TXT" from dba_registered_snapshots s
where exists (select a.snapshot_id from  all_snapshot_logs a
                             where  s.snapshot_id = a.snapshot_id)
or  userenv('SCHEMAID') = 1
or  exists (select null from v$enabledprivs
            where priv_number  in (-45 /* LOCK ANY TABLE */,
                                   -47 /* SELECT ANY TABLE */,
                                   -48 /* INSERT ANY TABLE  */,
                                   -49 /* UPDATE ANY TABLE */,
                                   -50 /* DELETE ANY TABLE */)
            )
/

comment on table ALL_REGISTERED_SNAPSHOTS is 'Remote snapshots of local tables that the user can see'
/

comment on column ALL_REGISTERED_SNAPSHOTS.OWNER is 'Owner of the snapshot'
/

comment on column ALL_REGISTERED_SNAPSHOTS.NAME is 'The name of the snapshot'
/

comment on column ALL_REGISTERED_SNAPSHOTS.SNAPSHOT_SITE is 'Global name of the snapshot site'
/

comment on column ALL_REGISTERED_SNAPSHOTS.CAN_USE_LOG is 'If NO, this snapshot is complex and cannot fast refresh'
/

comment on column ALL_REGISTERED_SNAPSHOTS.UPDATABLE is 'If NO, the snapshot is read only'
/

comment on column ALL_REGISTERED_SNAPSHOTS.REFRESH_METHOD is 'Whether the snapshot uses rowid or primary key or object id for fast refresh'
/

comment on column ALL_REGISTERED_SNAPSHOTS.SNAPSHOT_ID is 'Identifier for the snapshot used by the master for fast refresh'
/

comment on column ALL_REGISTERED_SNAPSHOTS.VERSION is 'Version of snapshot'
/

comment on column ALL_REGISTERED_SNAPSHOTS.QUERY_TXT is 'Query defining the snapshot'
/

