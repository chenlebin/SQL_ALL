create view ALL_REGISTRY_BANNERS (BANNER) as
SELECT banner FROM registry$
WHERE status = 1
/

