create view ALL_REPAUDIT_COLUMN
            (SNAME, ONAME, COLUMN_NAME, BASE_SNAME, BASE_ONAME, BASE_CONFLICT_TYPE, BASE_REFERENCE_NAME, ATTRIBUTE) as
select
    sname,
    oname,
    column_name,
    base_sname,
    base_oname,
    decode(base_conflict_type_id,
           1, 'UPDATE',
           2, 'UNIQUENESS',
           3, 'DELETE',
           'UNDEFINED'),
    base_reference_name,
    attribute
from  system.repcat$_audit_column,
     sys.user$ u, sys.obj$ o
where sname = u.name
  and oname = o.name
  and o.owner# = u.user#
  and o.type# = 2 /* tables */
  and (o.owner# = userenv('SCHEMAID')
        or
       o.obj# in ( select obj#
                   from objauth$
                   where grantee# in ( select kzsrorol
                                       from x$kzsro
                                     )
                  )
        or
  exists (select null from v$enabledprivs
          where priv_number in (-45 /* LOCK ANY TABLE */,
           -47 /* SELECT ANY TABLE */,
           -48 /* INSERT ANY TABLE */,
           -49 /* UPDATE ANY TABLE */,
           -50 /* DELETE ANY TABLE */)
                 )
       )
/

comment on table ALL_REPAUDIT_COLUMN is 'Information about columns in all shadow tables for replicated tables which are accessible to the user'
/

comment on column ALL_REPAUDIT_COLUMN.SNAME is 'Owner of the shadow table'
/

comment on column ALL_REPAUDIT_COLUMN.ONAME is 'Name of the shadow table'
/

comment on column ALL_REPAUDIT_COLUMN.COLUMN_NAME is 'Name of the column in the shadow table'
/

comment on column ALL_REPAUDIT_COLUMN.BASE_SNAME is 'Owner of replicated table'
/

comment on column ALL_REPAUDIT_COLUMN.BASE_ONAME is 'Name of the replicated table'
/

comment on column ALL_REPAUDIT_COLUMN.BASE_CONFLICT_TYPE is 'Type of conflict'
/

comment on column ALL_REPAUDIT_COLUMN.BASE_REFERENCE_NAME is 'Table name, unique constraint name, or column group name'
/

comment on column ALL_REPAUDIT_COLUMN.ATTRIBUTE is 'Description of the attribute'
/

