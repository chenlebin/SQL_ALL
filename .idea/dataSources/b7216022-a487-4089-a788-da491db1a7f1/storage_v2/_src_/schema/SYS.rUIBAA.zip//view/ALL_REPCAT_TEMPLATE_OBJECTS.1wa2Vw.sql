create view ALL_REPCAT_TEMPLATE_OBJECTS
            (REFRESH_TEMPLATE_NAME, OBJECT_NAME, OBJECT_TYPE, DDL_NUM, DDL_TEXT, MASTER_ROLLBACK_SEGMENT,
             DERIVED_FROM_SNAME, DERIVED_FROM_ONAME, FLAVOR_ID)
as
select rt.refresh_template_name,
t.object_name, ot.object_type_name object_type,
t.ddl_num, t.ddl_text,t.master_rollback_seg,
t.derived_from_sname,t.derived_from_oname,t.flavor_id
from system.repcat$_refresh_templates rt,
  system.repcat$_template_objects t,
  system.repcat$_object_types ot,
  system.repcat$_template_types tt
where t.refresh_template_id = rt.refresh_template_id
and  ot.object_type_id = t.object_type
and rt.template_type_id = tt.template_type_id
and bitand(rawtohex(tt.flags),1) = 1
and rt.refresh_template_id in
  (select rt.refresh_template_id
  from system.repcat$_refresh_templates
  where public_template = 'Y'
  union
  select rt.refresh_template_id
  from system.repcat$_refresh_templates rt,
  system.repcat$_user_authorizations at,
  sys.all_users au
  where at.refresh_template_id = rt.refresh_template_id
  and au.user_id = at.user_id
  and nvl(rt.public_template,'N') = 'N'
  and au.user_id = userenv('SCHEMAID')
  union
  select rt.refresh_template_id
  from system.repcat$_refresh_templates rt
  where nvl(rt.public_template,'N') = 'N'
  and exists
    (select 1 from v$enabledprivs
     where priv_number in (-174 /* alter any snapshot */))
  union
  select rt.refresh_template_id
  from system.repcat$_refresh_templates rt, sys.user$ u
  where  nvl(rt.public_template,'N') = 'N'
  and rt.owner =  u.name
  and u.user#  = userenv('SCHEMAID'))
/

comment on column ALL_REPCAT_TEMPLATE_OBJECTS.REFRESH_TEMPLATE_NAME is 'Name of the refresh group template.'
/

comment on column ALL_REPCAT_TEMPLATE_OBJECTS.OBJECT_NAME is 'Name of the database object.'
/

comment on column ALL_REPCAT_TEMPLATE_OBJECTS.OBJECT_TYPE is 'Type of database object.'
/

comment on column ALL_REPCAT_TEMPLATE_OBJECTS.DDL_NUM is 'Order of DDLs for creating the object.'
/

comment on column ALL_REPCAT_TEMPLATE_OBJECTS.DDL_TEXT is 'DDL string for creating the object or WHERE clause for snapshot query.'
/

comment on column ALL_REPCAT_TEMPLATE_OBJECTS.MASTER_ROLLBACK_SEGMENT is 'Rollback segment for use during snapshot refreshes.'
/

comment on column ALL_REPCAT_TEMPLATE_OBJECTS.DERIVED_FROM_SNAME is 'Schema name of schema containing object this was derived from.'
/

comment on column ALL_REPCAT_TEMPLATE_OBJECTS.DERIVED_FROM_ONAME is 'Object name of object this object was derived from.'
/

comment on column ALL_REPCAT_TEMPLATE_OBJECTS.FLAVOR_ID is 'Foreign key to the REPCAT$_FLAVORS table.'
/

