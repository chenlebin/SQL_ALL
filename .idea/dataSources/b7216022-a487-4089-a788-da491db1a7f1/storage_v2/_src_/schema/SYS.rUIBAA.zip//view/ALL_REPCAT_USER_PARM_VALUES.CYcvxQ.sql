create view ALL_REPCAT_USER_PARM_VALUES
            (REFRESH_TEMPLATE_NAME, OWNER, REFRESH_GROUP_NAME, TEMPLATE_COMMENT, PUBLIC_TEMPLATE, PARAMETER_NAME,
             DEFAULT_PARM_VALUE, PROMPT_STRING, PARM_VALUE, USER_NAME)
as
select rt.refresh_template_name,rt.owner,
rt.refresh_group_name,rt.template_comment,
nvl(rt.public_template,'N'),tp.parameter_name,
tp.default_parm_value, tp.prompt_string, sp.parm_value,
u.username
from system.repcat$_refresh_templates rt,
  system.repcat$_template_parms tp,
  system.repcat$_user_parm_values sp,
  dba_users  u,
  system.repcat$_template_types tt
where tp.refresh_template_id = rt.refresh_template_id
and tp.template_parameter_id = sp.template_parameter_id
and rt.template_type_id = tt.template_type_id
and bitand(rawtohex(tt.flags),1) = 1
and sp.user_id = u.user_id
and rt.refresh_template_id in
  (select rt.refresh_template_id
  from system.repcat$_refresh_templates
  where public_template = 'Y'
  union
  select rt.refresh_template_id
  from system.repcat$_refresh_templates rt,
  system.repcat$_user_authorizations at,
  sys.all_users au
  where at.refresh_template_id = rt.refresh_template_id
  and au.user_id = at.user_id
  and nvl(rt.public_template,'N') = 'N'
  and au.user_id = userenv('SCHEMAID')
  union
  select rt.refresh_template_id
  from system.repcat$_refresh_templates rt
  where nvl(rt.public_template,'N') = 'N'
  and exists
    (select 1 from v$enabledprivs
     where priv_number in (-174 /* alter any snapshot */))
  union
  select rt.refresh_template_id
  from system.repcat$_refresh_templates rt, sys.user$ u
  where  nvl(rt.public_template,'N') = 'N'
  and rt.owner =  u.name
  and u.user#  = userenv('SCHEMAID'))
/

comment on column ALL_REPCAT_USER_PARM_VALUES.REFRESH_TEMPLATE_NAME is 'Name of the refresh group template.'
/

comment on column ALL_REPCAT_USER_PARM_VALUES.OWNER is 'Owner of the refresh group template.'
/

comment on column ALL_REPCAT_USER_PARM_VALUES.REFRESH_GROUP_NAME is 'Name of the refresh group to create during instantiation.'
/

comment on column ALL_REPCAT_USER_PARM_VALUES.TEMPLATE_COMMENT is 'Optional comment field for the refresh group template.'
/

comment on column ALL_REPCAT_USER_PARM_VALUES.PUBLIC_TEMPLATE is 'Flag specifying public template or private template.'
/

comment on column ALL_REPCAT_USER_PARM_VALUES.PARAMETER_NAME is 'name of the parameter.'
/

comment on column ALL_REPCAT_USER_PARM_VALUES.DEFAULT_PARM_VALUE is 'Default value for the parameter.'
/

comment on column ALL_REPCAT_USER_PARM_VALUES.PROMPT_STRING is 'String for use in prompting for parameter values.'
/

comment on column ALL_REPCAT_USER_PARM_VALUES.PARM_VALUE is 'Value of the parameter for this user.'
/

comment on column ALL_REPCAT_USER_PARM_VALUES.USER_NAME is 'Database user name.'
/

