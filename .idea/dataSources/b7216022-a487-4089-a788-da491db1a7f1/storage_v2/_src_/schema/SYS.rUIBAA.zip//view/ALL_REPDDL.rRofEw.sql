create view ALL_REPDDL (LOG_ID, SOURCE, ROLE, MASTER, LINE, TEXT, DDL_NUM) as
select r.log_id, r.source, r.role, r.master, r.line, r.text, r.ddl_num
from system.repcat$_ddl r, all_repcatlog u
where r.log_id = u.id
  and r.source = u.source
/

comment on table ALL_REPDDL is 'Arguments that do not fit in a single repcat log record'
/

comment on column ALL_REPDDL.LOG_ID is 'Identifying number of the repcat log record'
/

comment on column ALL_REPDDL.SOURCE is 'Name of the database at which the request originated'
/

comment on column ALL_REPDDL.ROLE is 'Is this database the masterdef for the request'
/

comment on column ALL_REPDDL.MASTER is 'Name of the database that processes this request'
/

comment on column ALL_REPDDL.LINE is 'Ordering of records within a single request'
/

comment on column ALL_REPDDL.TEXT is 'Portion of an argument'
/

comment on column ALL_REPDDL.DDL_NUM is 'Order of ddls to execute'
/

