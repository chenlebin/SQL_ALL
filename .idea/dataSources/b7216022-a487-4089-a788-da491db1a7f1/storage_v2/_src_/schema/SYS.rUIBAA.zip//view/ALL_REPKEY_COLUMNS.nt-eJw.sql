create view ALL_REPKEY_COLUMNS (SNAME, ONAME, COL) as
select r.sname, r.oname, r.col
from sys.dba_repkey_columns r, all_repobject ro
where r.sname = ro.sname
  and r.oname = ro.oname
  and ro.type IN ('TABLE', 'SNAPSHOT')
/

comment on table ALL_REPKEY_COLUMNS is 'Primary columns for a table using column-level replication'
/

comment on column ALL_REPKEY_COLUMNS.SNAME is 'Schema containing table'
/

comment on column ALL_REPKEY_COLUMNS.ONAME is 'Name of the table'
/

comment on column ALL_REPKEY_COLUMNS.COL is 'Column in the table'
/

