create view ALL_REPPARAMETER_COLUMN
            (SNAME, ONAME, CONFLICT_TYPE, REFERENCE_NAME, SEQUENCE_NO, METHOD_NAME, FUNCTION_NAME, PRIORITY_GROUP,
             PARAMETER_TABLE_NAME, PARAMETER_COLUMN_NAME, PARAMETER_SEQUENCE_NO)
as
select
    p.sname,
    p.oname,
    decode(p.conflict_type_id,
           1, 'UPDATE',
           2, 'UNIQUENESS',
           3, 'DELETE',
           'UNDEFINED'),
    p.reference_name,
    p.sequence_no,
    r.method_name,
    r.function_name,
    r.priority_group,
    p.parameter_table_name,
    decode(method_name, 'USER FUNCTION', NVL(rc.top, rc.lcname),
                        'USER FLAVOR FUNCTION', NVL(rc.top, rc.lcname),
           rc.lcname),
    p.parameter_sequence_no
from  system.repcat$_parameter_column p,
      system.repcat$_resolution r,
      system.repcat$_repcolumn rc,
      all_tab_columns tc
where p.sname = r.sname
and   p.oname = r.oname
and   p.conflict_type_id = r.conflict_type_id
and   p.reference_name = r.reference_name
and   p.sequence_no = r.sequence_no
and   p.oname = p.parameter_table_name
and   p.attribute_sequence_no = 1
and   p.sname = rc.sname
and   p.oname = rc.oname
and   p.column_pos = rc.pos
and   p.sname = tc.owner
and   p.oname = tc.table_name
and   ((rc.top is null and rc.lcname = tc.column_name) or
       (rc.top is not null and rc.top = tc.column_name))
union
  select p.sname, p.oname, p.conflict_type, p.reference_name, p.sequence_no,
         p.method_name, p.function_name, p.priority_group,
         p.parameter_table_name, p.parameter_column_name,
         p.parameter_sequence_no
from  "_ALL_REPL_NESTED_TABLE_NAMES" nt, dba_repparameter_column p
where p.sname = nt.owner
  and p.parameter_table_name = nt.table_name
  and p.oname = p.parameter_table_name
/

comment on table ALL_REPPARAMETER_COLUMN is 'All columns used for resolving conflicts in replicated tables which are accessible to the user'
/

comment on column ALL_REPPARAMETER_COLUMN.SNAME is 'Owner of replicated object'
/

comment on column ALL_REPPARAMETER_COLUMN.ONAME is 'Name of the replicated object'
/

comment on column ALL_REPPARAMETER_COLUMN.CONFLICT_TYPE is 'Type of conflict'
/

comment on column ALL_REPPARAMETER_COLUMN.REFERENCE_NAME is 'Table name, unique constraint name, or column group name'
/

comment on column ALL_REPPARAMETER_COLUMN.SEQUENCE_NO is 'Ordering on resolution'
/

comment on column ALL_REPPARAMETER_COLUMN.PARAMETER_TABLE_NAME is 'Name of the table to which the parameter column belongs'
/

comment on column ALL_REPPARAMETER_COLUMN.PARAMETER_COLUMN_NAME is 'Name of the parameter column used for resolving the conflict'
/

comment on column ALL_REPPARAMETER_COLUMN.PARAMETER_SEQUENCE_NO is 'Ordering on parameter column'
/

