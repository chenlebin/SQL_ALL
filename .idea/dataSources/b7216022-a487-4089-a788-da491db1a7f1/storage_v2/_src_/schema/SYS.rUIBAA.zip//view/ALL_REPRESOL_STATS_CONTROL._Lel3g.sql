create view ALL_REPRESOL_STATS_CONTROL
            (SNAME, ONAME, CREATED, STATUS, STATUS_UPDATE_DATE, PURGED_DATE, LAST_PURGE_START_DATE,
             LAST_PURGE_END_DATE) as
select
    c.sname,
    c.oname,
    c.created,
    decode(c.status,
           1, 'ACTIVE',
           2, 'CANCELLED',
           'UNDEFINED'),
    c.status_update_date,
    c.purged_date,
    c.last_purge_start_date,
    c.last_purge_end_date
from  system.repcat$_resol_stats_control c,
      sys.user$ u, sys.obj$ o
where c.sname = u.name
  and c.oname = o.name
  and o.owner# = u.user#
  and o.type# = 2 /* tables */
  and (o.owner# = userenv('SCHEMAID')
        or
       o.obj# in ( select obj#
                   from objauth$
                   where grantee# in ( select kzsrorol
                                       from x$kzsro
                                     )
                  )
        or
  exists (select null from v$enabledprivs
          where priv_number in (-45 /* LOCK ANY TABLE */,
           -47 /* SELECT ANY TABLE */,
           -48 /* INSERT ANY TABLE */,
           -49 /* UPDATE ANY TABLE */,
           -50 /* DELETE ANY TABLE */)
                 )
       )
/

comment on table ALL_REPRESOL_STATS_CONTROL is 'Information about statistics collection for conflict resolutions for replicated tables which are accessible to the user'
/

comment on column ALL_REPRESOL_STATS_CONTROL.SNAME is 'Owner of replicated object'
/

comment on column ALL_REPRESOL_STATS_CONTROL.ONAME is 'Name of the replicated object'
/

comment on column ALL_REPRESOL_STATS_CONTROL.CREATED is 'Timestamp for which statistics collection was first started'
/

comment on column ALL_REPRESOL_STATS_CONTROL.STATUS is 'Status of statistics collection: ACTIVE, CANCELLED'
/

comment on column ALL_REPRESOL_STATS_CONTROL.STATUS_UPDATE_DATE is 'Timestamp for which the status was last updated'
/

comment on column ALL_REPRESOL_STATS_CONTROL.PURGED_DATE is 'Timestamp for the last purge of statistics data'
/

comment on column ALL_REPRESOL_STATS_CONTROL.LAST_PURGE_START_DATE is 'The last start date of the statistics purging date range'
/

comment on column ALL_REPRESOL_STATS_CONTROL.LAST_PURGE_END_DATE is 'The last end date of the statistics purging date range'
/

