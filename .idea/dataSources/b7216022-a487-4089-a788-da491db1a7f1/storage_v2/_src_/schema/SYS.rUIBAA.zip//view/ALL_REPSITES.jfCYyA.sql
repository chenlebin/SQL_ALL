create view ALL_REPSITES (GNAME, DBLINK, MASTERDEF, SNAPMASTER, MASTER_COMMENT, MASTER, GROUP_OWNER) as
select r.sname, r.dblink, r.masterdef, r.snapmaster, r.master_comment,
       r.master, r.gowner
from repcat_repschema r
/

comment on table ALL_REPSITES is 'N-way replication information'
/

comment on column ALL_REPSITES.GNAME is 'Name of the replicated object group'
/

comment on column ALL_REPSITES.DBLINK is 'A database site replicating the schema'
/

comment on column ALL_REPSITES.MASTERDEF is 'Is the database the master definition site for the replicated object group'
/

comment on column ALL_REPSITES.SNAPMASTER is 'For a snapshot site, is the database the current refresh master'
/

comment on column ALL_REPSITES.MASTER_COMMENT is 'Description of the database site'
/

comment on column ALL_REPSITES.MASTER is 'Redundant information from all_repcat.master'
/

comment on column ALL_REPSITES.GROUP_OWNER is 'Owner of the replicated object group'
/

