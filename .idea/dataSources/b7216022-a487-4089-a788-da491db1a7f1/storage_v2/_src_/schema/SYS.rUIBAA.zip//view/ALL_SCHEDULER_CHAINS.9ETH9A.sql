create view ALL_SCHEDULER_CHAINS
            (OWNER, CHAIN_NAME, RULE_SET_OWNER, RULE_SET_NAME, NUMBER_OF_RULES, NUMBER_OF_STEPS, ENABLED,
             EVALUATION_INTERVAL, USER_RULE_SET, COMMENTS)
as
SELECT u.name, o.name, c.rule_set_owner, c.rule_set,
  (SELECT count(*) FROM rule_map$ rm, obj$ rmo, user$ rmu
     WHERE rm.rs_obj# = rmo.obj# AND rmo.owner# = rmu.user#
     AND rmu.name = c.rule_set_owner and rmo.name = c.rule_set),
  (SELECT COUNT(*) FROM sys.scheduler$_step cs
     WHERE cs.oid = c.obj#),
  DECODE(BITAND(c.flags,1),0,'FALSE',1,'TRUE'), c.eval_interval,
  DECODE(BITAND(c.flags,2),2,'FALSE',0,'TRUE'),
  c.comments
  FROM obj$ o, user$ u, sys.scheduler$_chain c
  WHERE c.obj# = o.obj# AND u.user# = o.owner# AND
    (o.owner# = userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or /* user has system privileges */
         (exists (select null from v$enabledprivs
                 where priv_number in (-265 /* CREATE ANY JOB */,
                                       -266 /* EXECUTE ANY PROGRAM */ )
                 )
          and o.owner#!=0)
      )
/

comment on table ALL_SCHEDULER_CHAINS is 'All scheduler chains in the database visible to current user'
/

comment on column ALL_SCHEDULER_CHAINS.OWNER is 'Owner of the scheduler chain'
/

comment on column ALL_SCHEDULER_CHAINS.CHAIN_NAME is 'Name of the scheduler chain'
/

comment on column ALL_SCHEDULER_CHAINS.RULE_SET_OWNER is 'Owner of the associated rule set'
/

comment on column ALL_SCHEDULER_CHAINS.RULE_SET_NAME is 'Name of the associated rule set'
/

comment on column ALL_SCHEDULER_CHAINS.NUMBER_OF_RULES is 'Number of rules in this chain'
/

comment on column ALL_SCHEDULER_CHAINS.NUMBER_OF_STEPS is 'Number of defined steps in this chain'
/

comment on column ALL_SCHEDULER_CHAINS.ENABLED is 'Whether the chain is enabled'
/

comment on column ALL_SCHEDULER_CHAINS.EVALUATION_INTERVAL is 'Periodic interval at which to reevaluate rules for this chain'
/

comment on column ALL_SCHEDULER_CHAINS.USER_RULE_SET is 'Whether the chain uses a user-specified rule set'
/

comment on column ALL_SCHEDULER_CHAINS.COMMENTS is 'Comments on the chain'
/

