create view ALL_SCHEDULER_EXTERNAL_DESTS (DESTINATION_NAME, HOSTNAME, PORT, IP_ADDRESS, ENABLED, COMMENTS) as
SELECT "DESTINATION_NAME","HOSTNAME","PORT","IP_ADDRESS","ENABLED","COMMENTS" from dba_scheduler_external_dests
/

comment on table ALL_SCHEDULER_EXTERNAL_DESTS is 'User-visible destination objects in the database pointing to remote agents'
/

comment on column ALL_SCHEDULER_EXTERNAL_DESTS.DESTINATION_NAME is 'Name of this destination object'
/

comment on column ALL_SCHEDULER_EXTERNAL_DESTS.HOSTNAME is 'Name or IP address of host on which agent is located'
/

comment on column ALL_SCHEDULER_EXTERNAL_DESTS.PORT is 'Port that the agent is listening on'
/

comment on column ALL_SCHEDULER_EXTERNAL_DESTS.IP_ADDRESS is 'IP address of host on which agent is located'
/

comment on column ALL_SCHEDULER_EXTERNAL_DESTS.ENABLED is 'Whether this destination object is enabled'
/

comment on column ALL_SCHEDULER_EXTERNAL_DESTS.COMMENTS is 'Optional comment'
/

