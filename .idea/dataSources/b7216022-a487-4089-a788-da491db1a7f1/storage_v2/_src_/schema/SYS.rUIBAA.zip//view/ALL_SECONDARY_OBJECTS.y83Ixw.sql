create view ALL_SECONDARY_OBJECTS
            (INDEX_OWNER, INDEX_NAME, SECONDARY_OBJECT_OWNER, SECONDARY_OBJECT_NAME, SECONDARY_OBJDATA_TYPE) as
select u.name, o.name, u1.name, o1.name, decode(s.spare1, 0, 'FROM INDEXTYPE',
                                                1, 'FROM STATISTICS TYPE')
from   sys.user$ u, sys.obj$ o, sys.user$ u1, sys.obj$ o1, sys.secobj$ s
where  s.obj# = o.obj# and o.owner# = u.user# and
       s.secobj# = o1.obj#  and  o1.owner# = u1.user# and
       ( o.owner# = userenv('SCHEMAID')
         or
         o.obj# in ( select obj#
                    from sys.objauth$
                    where grantee# in ( select kzsrorol
                                        from x$kzsro
                                      )
                   )
         or
         exists (select null from v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */)
                 )
       )
/

comment on table ALL_SECONDARY_OBJECTS is 'All secondary objects for domain indexes'
/

comment on column ALL_SECONDARY_OBJECTS.INDEX_OWNER is 'Name of the domain index owner'
/

comment on column ALL_SECONDARY_OBJECTS.INDEX_NAME is 'Name of the domain index'
/

comment on column ALL_SECONDARY_OBJECTS.SECONDARY_OBJECT_OWNER is 'Owner of the secondary object'
/

comment on column ALL_SECONDARY_OBJECTS.SECONDARY_OBJECT_NAME is 'Name of the secondary object'
/

comment on column ALL_SECONDARY_OBJECTS.SECONDARY_OBJDATA_TYPE is 'Type of the secondary object'
/

