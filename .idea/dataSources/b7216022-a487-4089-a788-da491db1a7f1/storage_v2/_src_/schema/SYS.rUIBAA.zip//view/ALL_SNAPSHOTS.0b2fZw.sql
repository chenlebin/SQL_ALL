create view ALL_SNAPSHOTS
            (OWNER, NAME, TABLE_NAME, MASTER_VIEW, MASTER_OWNER, MASTER, MASTER_LINK, CAN_USE_LOG, UPDATABLE,
             REFRESH_METHOD, LAST_REFRESH, ERROR, FR_OPERATIONS, CR_OPERATIONS, TYPE, NEXT, START_WITH, REFRESH_GROUP,
             UPDATE_TRIG, UPDATE_LOG, QUERY, MASTER_ROLLBACK_SEG, STATUS, REFRESH_MODE, PREBUILT)
as
select s."OWNER",s."NAME",s."TABLE_NAME",s."MASTER_VIEW",s."MASTER_OWNER",s."MASTER",s."MASTER_LINK",s."CAN_USE_LOG",s."UPDATABLE",s."REFRESH_METHOD",s."LAST_REFRESH",s."ERROR",s."FR_OPERATIONS",s."CR_OPERATIONS",s."TYPE",s."NEXT",s."START_WITH",s."REFRESH_GROUP",s."UPDATE_TRIG",s."UPDATE_LOG",s."QUERY",s."MASTER_ROLLBACK_SEG",s."STATUS",s."REFRESH_MODE",s."PREBUILT" from dba_snapshots s, sys.obj$ o, sys.user$ u
where o.owner#     = u.user#
  and s.table_name = o.name
  and u.name       = s.owner
  and o.type#      = 2                     /* table */
  and ( u.user# in (userenv('SCHEMAID'), 1)
        or
        o.obj# in ( select obj#
                    from sys.objauth$
                    where grantee# in ( select kzsrorol
                                        from x$kzsro
                                      )
                  )
       or /* user has system privileges */
         exists (select null from v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */)
                 )
      )
/

comment on table ALL_SNAPSHOTS is 'Snapshots the user can access'
/

comment on column ALL_SNAPSHOTS.OWNER is 'Owner of the snapshot'
/

comment on column ALL_SNAPSHOTS.NAME is 'The view used by users and applications for viewing the snapshot'
/

comment on column ALL_SNAPSHOTS.TABLE_NAME is 'Table the snapshot is stored in -- has an extra column for the master rowid'
/

comment on column ALL_SNAPSHOTS.MASTER_VIEW is 'View of the master table, owned by the snapshot owner, used for refreshes'
/

comment on column ALL_SNAPSHOTS.MASTER_OWNER is 'Owner of the master table'
/

comment on column ALL_SNAPSHOTS.MASTER is 'Name of the master table that this snapshot is a copy of'
/

comment on column ALL_SNAPSHOTS.MASTER_LINK is 'Database link name to the master site'
/

comment on column ALL_SNAPSHOTS.CAN_USE_LOG is 'If NO, this snapshot is complex and will never use a log'
/

comment on column ALL_SNAPSHOTS.UPDATABLE is 'If NO, the snapshot is read only.  Look up REPLICATION'
/

comment on column ALL_SNAPSHOTS.REFRESH_METHOD is 'The values used to drive a fast refresh of the snapshot'
/

comment on column ALL_SNAPSHOTS.LAST_REFRESH is 'SYSDATE from the master site at the time of the last refresh'
/

comment on column ALL_SNAPSHOTS.ERROR is 'The error returned last time an automatic refresh was attempted'
/

comment on column ALL_SNAPSHOTS.TYPE is 'The type of refresh (complete,fast,force) for all automatic refreshes'
/

comment on column ALL_SNAPSHOTS.NEXT is 'The date function used to compute next refresh dates'
/

comment on column ALL_SNAPSHOTS.START_WITH is 'The date function used to compute next refresh dates'
/

comment on column ALL_SNAPSHOTS.REFRESH_GROUP is 'All snapshots in a given refresh group get refreshed in the same transaction'
/

comment on column ALL_SNAPSHOTS.UPDATE_TRIG is 'The name of the trigger which fills the UPDATE_LOG'
/

comment on column ALL_SNAPSHOTS.UPDATE_LOG is 'The table which logs changes made to an updatable snapshots'
/

comment on column ALL_SNAPSHOTS.QUERY is 'The original query that this snapshot is an instantiation of'
/

comment on column ALL_SNAPSHOTS.MASTER_ROLLBACK_SEG is 'Rollback segment to use at the master site'
/

comment on column ALL_SNAPSHOTS.STATUS is 'The status of the contents of the snapshot'
/

comment on column ALL_SNAPSHOTS.REFRESH_MODE is 'This indicates how and when the snapshot will be refreshed'
/

comment on column ALL_SNAPSHOTS.PREBUILT is 'If YES, this snapshot uses a prebuilt table as the base table'
/

