create view ALL_SQLSET (NAME, ID, OWNER, DESCRIPTION, CREATED, LAST_MODIFIED, STATEMENT_COUNT) as
select name, id, owner,
       description, created, last_modified, statement_count
  from WRI$_SQLSET_DEFINITIONS
  where owner = SYS_CONTEXT('USERENV', 'CURRENT_USER') OR
        EXISTS (select 1
                from   V$ENABLEDPRIVS
                where  priv_number in (-273 /*ADMINISTER ANY SQL TUNING SET*/))
/

