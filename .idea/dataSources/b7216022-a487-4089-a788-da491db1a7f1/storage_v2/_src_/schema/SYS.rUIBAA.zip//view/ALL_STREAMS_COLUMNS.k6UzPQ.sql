create view ALL_STREAMS_COLUMNS
            (OWNER, TABLE_NAME, COLUMN_NAME, SYNC_CAPTURE_VERSION, SYNC_CAPTURE_REASON, APPLY_VERSION, APPLY_REASON) as
select s."OWNER",s."TABLE_NAME",s."COLUMN_NAME",s."SYNC_CAPTURE_VERSION",s."SYNC_CAPTURE_REASON",s."APPLY_VERSION",s."APPLY_REASON" from dba_streams_columns s, all_objects a
    where s.owner = a.owner
      and s.table_name = a.object_name
      and a.object_type = 'TABLE'
/

comment on table ALL_STREAMS_COLUMNS is 'Streams unsupported columns'
/

comment on column ALL_STREAMS_COLUMNS.OWNER is 'Owner of the object'
/

comment on column ALL_STREAMS_COLUMNS.TABLE_NAME is 'Name of the object'
/

comment on column ALL_STREAMS_COLUMNS.SYNC_CAPTURE_VERSION is 'Version of sync capture which supports this column'
/

comment on column ALL_STREAMS_COLUMNS.SYNC_CAPTURE_REASON is 'Reason why this column is not supported by sync capture'
/

comment on column ALL_STREAMS_COLUMNS.APPLY_VERSION is 'Version of apply which supports this column'
/

comment on column ALL_STREAMS_COLUMNS.APPLY_REASON is 'Reason why this column is not supported by apply'
/

