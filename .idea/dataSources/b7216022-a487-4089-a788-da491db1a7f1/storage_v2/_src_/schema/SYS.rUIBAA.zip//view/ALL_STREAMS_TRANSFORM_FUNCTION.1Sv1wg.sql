create view ALL_STREAMS_TRANSFORM_FUNCTION (RULE_OWNER, RULE_NAME, VALUE_TYPE, TRANSFORM_FUNCTION_NAME, CUSTOM_TYPE) as
select tf."RULE_OWNER",tf."RULE_NAME",tf."VALUE_TYPE",tf."TRANSFORM_FUNCTION_NAME",tf."CUSTOM_TYPE"
from   DBA_STREAMS_TRANSFORM_FUNCTION tf, ALL_RULES r
where  tf.rule_owner = r.rule_owner
and    tf.rule_name = r.rule_name
/

comment on table ALL_STREAMS_TRANSFORM_FUNCTION is 'Rules-based transform functions used by Streams'
/

comment on column ALL_STREAMS_TRANSFORM_FUNCTION.RULE_OWNER is 'The owner of the rule associated with the transform function'
/

comment on column ALL_STREAMS_TRANSFORM_FUNCTION.RULE_NAME is 'The name of the rule associated with the transform function'
/

comment on column ALL_STREAMS_TRANSFORM_FUNCTION.VALUE_TYPE is 'The type of the transform function name.  This type must be VARCHAR2 for a rule-based transformation to work properly'
/

comment on column ALL_STREAMS_TRANSFORM_FUNCTION.TRANSFORM_FUNCTION_NAME is 'The name of the transform function, or NULL if the VALUE_TYPE is not VARCHAR2'
/

comment on column ALL_STREAMS_TRANSFORM_FUNCTION.CUSTOM_TYPE is 'The type of the transform function'
/

