create view ALL_STREAMS_UNSUPPORTED (OWNER, TABLE_NAME, REASON, AUTO_FILTERED) as
select s."OWNER",s."TABLE_NAME",s."REASON",s."AUTO_FILTERED" from DBA_STREAMS_UNSUPPORTED s, ALL_OBJECTS a
   where s.owner = a.owner
     and s.table_name = a.object_name
     and a.object_type = 'TABLE'
/

comment on table ALL_STREAMS_UNSUPPORTED is 'List of all the tables that are not supported by Streams in this release'
/

comment on column ALL_STREAMS_UNSUPPORTED.OWNER is 'Owner of the object'
/

comment on column ALL_STREAMS_UNSUPPORTED.TABLE_NAME is 'Name of the object'
/

comment on column ALL_STREAMS_UNSUPPORTED.REASON is 'Reason why the object is not supported'
/

comment on column ALL_STREAMS_UNSUPPORTED.AUTO_FILTERED is 'Does Streams automatically filter out this object'
/

