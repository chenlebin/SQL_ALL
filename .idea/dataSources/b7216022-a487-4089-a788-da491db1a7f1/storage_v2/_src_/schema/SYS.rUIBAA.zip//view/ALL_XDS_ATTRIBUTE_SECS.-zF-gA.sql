create view ALL_XDS_ATTRIBUTE_SECS (SCHEMA_NAME, OBJECT_NAME, COLUMN_NAME, DESCRIPTION, PRIVILEGE) as
select SCHEMA_NAME, o.OBJECT_NAME, COLUMN_NAME, DESCRIPTION, PRIVILEGE
  from DBA_XDS_ATTRIBUTE_SECS o, all_objects t
where
SCHEMA_NAME = t.OWNER and o.OBJECT_NAME = t.OBJECT_NAME
/

comment on table ALL_XDS_ATTRIBUTE_SECS is 'All objects with XDS column security and accessible to the user'
/

comment on column ALL_XDS_ATTRIBUTE_SECS.SCHEMA_NAME is 'Owner of the object'
/

comment on column ALL_XDS_ATTRIBUTE_SECS.OBJECT_NAME is 'Name of the object'
/

comment on column ALL_XDS_ATTRIBUTE_SECS.COLUMN_NAME is 'Name of the column'
/

comment on column ALL_XDS_ATTRIBUTE_SECS.DESCRIPTION is 'Description'
/

comment on column ALL_XDS_ATTRIBUTE_SECS.PRIVILEGE is 'Name of the privilege'
/

