create view ALL_XML_INDEXES
            (INDEX_OWNER, INDEX_NAME, TABLE_OWNER, TABLE_NAME, TYPE, INDEX_TYPE, PATH_TABLE_NAME, PARAMETERS, ASYNC,
             STALE, PEND_TABLE_NAME, EX_OR_INCLUDE)
as
select
   u.name         INDEX_OWNER,
   oi.name        INDEX_NAME,
   bu.name        TABLE_OWNER,
   bo.name        TABLE_NAME,
   case when bitand(p.flags, 536870912)=536870912 then 'REPOSITORY'
        when bitand(p.flags, 4096)=4096 then 'BINARY'
        when bitand(p.flags, 8192)=8192 then 'CLOB in OR'
        when bitand(p.flags, 16384)=16384 then 'CLOB'
        else '????' end TYPE,
   case when bitand(p.flags , 268435456 ) != 268435456 then 'STRUCTURED'
        when bitand(p.flags, 268435456 ) = 268435456 and exists (select xt.idxobj# from xdb.xdb$xtab xt where xt.idxobj# = p.idxobj#) then 'STRUCTURED and UNSTRUCTURED'
        else 'UNSTRUCTURED' end INDEX_TYPE,
   case when bitand(p.flags,  268435456 ) != 268435456 then ''
        else     ot.name  end PATH_TABLE_NAME,
   p.parameters   PARAMETERS,
   case when bitand(p.flags, 65011712)=6291456 then 'ON-COMMIT'
        when bitand(p.flags, 65011712)=10485760 then 'MANUAL'
        when bitand(p.flags, 65011712)=18874368 then 'EVERY'
        else 'ALWAYS' end ASYNC,
   case when bitand(p.flags, 2097152)=2097152 then 'TRUE'
        else 'FALSE' end STALE,
   case when bitand(p.flags, 2097152)=2097152 then
        (select op.name from sys.obj$ op
         where  op.obj# = p.pendtabobj#)
        else '' end PEND_TABLE_NAME,
   case when bitand(p.flags, 32)=32 then 'INCLUDE'
        when bitand(p.flags, 128)=128 then 'EXCLUDE'
        else 'FULLY IX' end EX_or_INCLUDE
 from xdb.xdb$dxptab p, sys.obj$ ot, sys.obj$ oi, sys.user$ u,
      sys.user$ bu, sys.obj$ bo, sys.ind$ i
 where oi.owner# = u.user# and
       oi.obj# = p.idxobj# and p.pathtabobj# = ot.obj# and
       i.obj# = oi.obj# and i.bo# = bo.obj# and bo.owner# = bu.user# and
       (u.user# = userenv('SCHEMAID')
        or oi.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or /* user has system privileges */
         exists (select null from v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */)))
/

comment on table ALL_XML_INDEXES is 'Description of the all XMLType indexes that the user has privileges on'
/

comment on column ALL_XML_INDEXES.INDEX_OWNER is 'Username of the owner of the XML index'
/

comment on column ALL_XML_INDEXES.INDEX_NAME is 'Name of the XML index'
/

comment on column ALL_XML_INDEXES.TABLE_OWNER is 'Username of the owner of the indexed object'
/

comment on column ALL_XML_INDEXES.TABLE_NAME is 'Name of the indexed object'
/

comment on column ALL_XML_INDEXES.TYPE is 'Type of indexed column (CLOB, CSX, CLOB_IN_OR, REPOSITORY)'
/

comment on column ALL_XML_INDEXES.INDEX_TYPE is 'Index Type (Structured, Unstructured or both)'
/

comment on column ALL_XML_INDEXES.PATH_TABLE_NAME is 'Name of the PATH TABLE'
/

comment on column ALL_XML_INDEXES.PARAMETERS is 'Structured index groups, path subsetting xpaths and scheduler job information'
/

comment on column ALL_XML_INDEXES.ASYNC is 'Asynchronous index type'
/

comment on column ALL_XML_INDEXES.STALE is 'Stale index type'
/

comment on column ALL_XML_INDEXES.PEND_TABLE_NAME is 'Name of the PENDING TABLE'
/

comment on column ALL_XML_INDEXES.EX_OR_INCLUDE is 'Path Subsetting (Include or Exclude)'
/

