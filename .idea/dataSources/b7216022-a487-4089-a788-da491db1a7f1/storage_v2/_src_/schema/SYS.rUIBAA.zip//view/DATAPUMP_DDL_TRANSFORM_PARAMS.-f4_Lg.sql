create view DATAPUMP_DDL_TRANSFORM_PARAMS (OBJECT_TYPE, PARAM_NAME) as
select  type, param
from    sys.metaxslparam$
where   model='ORACLE' and
        transform='DDL' and
        param!='DUMMY' and
        param not like 'PRS_%' and
        type!='*'
/

