create view DATAPUMP_DIR_OBJS (NAME, PATH, READ, WRITE) as
SELECT o.name, d.os_path, 'TRUE', 'TRUE'
   FROM SYS.OBJ$ o, SYS.DIR$ d
     WHERE o.obj#=d.obj#
       AND (o.owner#=UID
        OR EXISTS (SELECT NULL FROM v$enabledprivs WHERE priv_number IN (-177,-178)))
    UNION ALL
      SELECT o.name, d.os_path,
         DECODE(SUM(DECODE(privilege#,17,1,0)),0, 'FALSE','TRUE'),
         DECODE(SUM(DECODE(privilege#,18,1,0)),0, 'FALSE','TRUE')
      FROM SYS.OBJ$ o, SYS.DIR$ d, SYS.OBJAUTH$ oa
        WHERE o.obj#=d.obj#
        AND oa.obj#=o.obj#
        AND oa.privilege# IN (17,18)
        AND oa.grantee# IN (SELECT kzsrorol FROM x$kzsro)
        AND NOT (o.owner#=UID
           OR EXISTS (SELECT NULL FROM v$enabledprivs WHERE priv_number IN (-177,-178)))
   GROUP BY o.name, d.os_path
/

comment on table DATAPUMP_DIR_OBJS is 'State of Schema Directory Objects'
/

comment on column DATAPUMP_DIR_OBJS.NAME is 'Directory Object Name'
/

comment on column DATAPUMP_DIR_OBJS.PATH is 'Directory object path specification'
/

comment on column DATAPUMP_DIR_OBJS.READ is 'Read Access enabled'
/

comment on column DATAPUMP_DIR_OBJS.WRITE is 'Write access enabled'
/

