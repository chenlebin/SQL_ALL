create view DATAPUMP_PATHMAP (HET_TYPE, OBJECT_PATH) as
select htype,name
 from sys.metapathmap$
/

