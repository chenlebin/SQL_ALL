create view DBA_SCHEDULER_REMOTE_DATABASES (DATABASE_NAME, REGISTERED_AS, DATABASE_LINK) as
SELECT database_name, decode(reg_status, 0, 'SOURCE', 'DESTINATION'),
        database_link
 FROM scheduler$_remote_dbs
/

comment on table DBA_SCHEDULER_REMOTE_DATABASES is 'List of registered remote databases for jobs'
/

comment on column DBA_SCHEDULER_REMOTE_DATABASES.DATABASE_NAME is 'Name of remote database'
/

comment on column DBA_SCHEDULER_REMOTE_DATABASES.REGISTERED_AS is 'Whether database registered as source or destination'
/

comment on column DBA_SCHEDULER_REMOTE_DATABASES.DATABASE_LINK is 'Database link to the remote database'
/

