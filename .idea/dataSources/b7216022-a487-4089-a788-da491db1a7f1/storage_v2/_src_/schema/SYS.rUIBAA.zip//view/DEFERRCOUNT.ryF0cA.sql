create view DEFERRCOUNT (ERRCOUNT, DESTINATION) as
SELECT count(1) errcount, destination
    FROM deferror GROUP BY destination
/

comment on table DEFERRCOUNT is 'Summary information about deferred transactions that caused an error'
/

comment on column DEFERRCOUNT.ERRCOUNT is 'Number of existing transactions that caused an error for given destination'
/

comment on column DEFERRCOUNT.DESTINATION is 'Database link used to address destination'
/

