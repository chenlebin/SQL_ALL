create view EXPTABSUBPARTLOBFRAG (PARENTOBJNO, TSNO, FRAGOBJNO, FRAGNO, TABFRAGOBJNO) as
SELECT
              lf.parentobj#                                         PARENTOBJNO,
              lf.ts#                                                TSNO,
              lf.fragobj#                                           FRAGOBJNO,
              row_number() OVER
                 (partition by lf.parentobj# order by lf.frag#) - 1 FRAGNO,
              lf.tabfragobj#                                        TABFRAGOBJNO
        FROM sys.lobfrag$ lf
/

