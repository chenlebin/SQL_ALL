create view EXU81JAV (OWNERID, UNAME, ID, SHORTNAME, TYPEID, TYPE) as
SELECT  o.owner#, u.name, o.obj#, o.name, o.type#,
                DECODE(o.type#, 28, 'JAVA SOURCE', 29, 'JAVA CLASS',
                       30, 'JAVA RESOURCE')
        FROM    sys.exu81obj o, sys.user$ u
        WHERE   o.owner# = u.user# AND
                o.type# IN (28, 29, 30) AND
                (UID IN (0, o.owner#) OR
                 EXISTS (
                    SELECT  role
                    FROM    sys.session_roles
                    WHERE   role = 'SELECT_CATALOG_ROLE')) AND
                u.name != 'SYS'
/

