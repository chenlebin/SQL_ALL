create view EXU81OPRU (NAME, OBJID, OWNER, OWNERID, OLEVEL, SQLVER) as
SELECT  "NAME","OBJID","OWNER","OWNERID","OLEVEL","SQLVER"
        FROM    sys.exu81opr
        WHERE   ownerid = UID
/

