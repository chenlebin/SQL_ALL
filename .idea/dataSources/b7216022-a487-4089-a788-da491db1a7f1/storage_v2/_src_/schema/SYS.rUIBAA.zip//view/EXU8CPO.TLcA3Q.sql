create view EXU8CPO (PARAMETER, VALUE) as
SELECT  parameter, DECODE(value, 'TRUE', 1, 'FALSE', 0, 2)
        FROM    sys.v$option
        WHERE   parameter IN ('procedural', 'replication')
/

