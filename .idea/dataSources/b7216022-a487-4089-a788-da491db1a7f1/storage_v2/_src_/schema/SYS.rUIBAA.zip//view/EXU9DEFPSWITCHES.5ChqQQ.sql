create view EXU9DEFPSWITCHES (COMPFLGS, NLSLENSEM) as
SELECT  a.value, b.value
        FROM    sys.v$parameter a, sys.v$parameter b
        WHERE   a.name = 'plsql_compiler_flags' AND
                b.name = 'nls_length_semantics'
/

