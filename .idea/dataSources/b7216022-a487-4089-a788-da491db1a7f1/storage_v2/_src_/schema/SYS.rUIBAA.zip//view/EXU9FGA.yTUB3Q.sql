create view EXU9FGA (OBJOWN, OBJNAM, POLICY, POLTXT, POLCOL, POLOWN, POLPKG, POLFUN, ENABLED) as
SELECT  u.name, o.name, f.pname,
                replace(f.ptxt,'''',''''''),
                f.pcol, f.pfschma, f.ppname,
                f.pfname, f.enable_flag
        FROM    sys.user$ u, sys.obj$ o, sys.fga$ f
        WHERE   u.user# = o.owner# AND
                f.obj# = o.obj# AND
                (UID IN (o.owner#, 0) OR
                 EXISTS (
                    SELECT  role
                    FROM    sys.session_roles
                    WHERE   role = 'SELECT_CATALOG_ROLE'))
/

