create view GV_$ACTIVE_INSTANCES (INST_ID, INST_NUMBER, INST_NAME) as
select "INST_ID","INST_NUMBER","INST_NAME" from gv$active_instances
/

