create view GV_$LOCK_ACTIVITY (INST_ID, FROM_VAL, TO_VAL, ACTION_VAL, COUNTER) as
select "INST_ID","FROM_VAL","TO_VAL","ACTION_VAL","COUNTER" from gv$lock_activity
/

