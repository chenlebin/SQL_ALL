create view GV_$QUEUEING_MTH (INST_ID, NAME) as
select "INST_ID","NAME" from gv$queueing_mth
/

