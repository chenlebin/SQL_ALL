create view GV_$RSRC_PLAN (INST_ID, ID, NAME, IS_TOP_PLAN, CPU_MANAGED) as
select "INST_ID","ID","NAME","IS_TOP_PLAN","CPU_MANAGED" from gv$rsrc_plan
/

