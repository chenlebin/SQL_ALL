create view HS_PARALLEL_HISTOGRAM_DATA
            (DBLINK, REMOTE_TABLE_NAME, REMOTE_SCHEMA_NAME, LOW_VALUE, HIGH_VALUE, BUCKET_NUM) as
select dblink, remote_table_name, remote_schema_name, low_value,
  high_value, bucket_num
from hs$_parallel_histogram_data
/

