create view KU_NOEXP_VIEW (OBJ_TYPE, SCHEMA, NAME) as
SELECT  decode(n.obj_type, 2, 'TABLE', 6, 'SEQUENCE', 'ERROR'),
                n.owner, n.name
        FROM    sys.noexp$ n
      UNION
        SELECT  k.obj_type, k.schema, k.name
        FROM    sys.ku_noexp_tab k
/

