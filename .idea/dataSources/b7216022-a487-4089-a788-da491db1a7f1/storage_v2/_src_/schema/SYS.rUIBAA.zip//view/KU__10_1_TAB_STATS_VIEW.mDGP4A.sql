create view KU$_10_1_TAB_STATS_VIEW (VERS_MAJOR, VERS_MINOR, OBJ_NUM, BASE_OBJ, TAB_INFO, PTAB_INFO_LIST) as
select  '1', '0', o.obj#,
          -- if this is a nested table, get parent table, otherwise get table.
         decode(bitand(t.property , 8192), 8192,
           (select value(oo) from ku$_schemaobj_view oo
            where  oo.obj_num = dbms_metadata_util.get_anc(o.obj#)),
           (select value(sov) from ku$_schemaobj_view sov
            where sov.obj_num = o.obj#)),
          value(tosv),
          cast(multiset(select value(psv)
                        from   sys.ku$_10_1_ptab_stats_view psv
                        where  psv.bobj_num = o.obj#)
                        as ku$_10_1_ptab_stats_list_t)
  from    sys.obj$ o, sys.tab$ t, ku$_10_1_tab_only_stats_view tosv
  where   tosv.obj_num = o.obj# and
          o.obj# = t.obj# and
          o.type# = 2 and
          EXISTS ( SELECT obj# from hist_head$ hh
                   WHERE  hh.obj#=o.obj#)
      and (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o.owner#, 0) OR
              EXISTS ( SELECT * FROM sys.session_roles
                       WHERE role='SELECT_CATALOG_ROLE' ))
/

