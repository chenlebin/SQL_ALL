create view KU$_10_2_TABLE_DATA_VIEW
            (VERS_MAJOR, VERS_MINOR, OBJ_NUM, DATAOBJ_NUM, NAME, PART_NAME, PARTTYPE, PROPERTY, TRIGFLAG, XMLTYPE_FMTS,
             XMLSCHEMACOLS, XML_OUTOFLINE, LONGCOL, NFT_VARRAY, NONSCOPED_REF, TSTZ_COLS, SCHEMA_OBJ, TS_NAME,
             BLOCKSIZE, BYTES_ALLOC, BASE_OBJ, DOMIDX_OBJ, ANC_OBJ, UNLOAD_METHOD, ET_PARALLEL, FGAC, REFPAR_LEVEL)
as
select t.* from ku$_htable_data_view t
  where refpar_level = 0
  UNION ALL
  select t.* from ku$_htpart_data_view t
  where refpar_level = 0
  UNION ALL
  select t.* from ku$_htspart_data_view t
  where refpar_level = 0
  UNION ALL
  select t.* from ku$_ntable_data_view t
  where refpar_level = 0
  UNION ALL
  select * from ku$_eqntable_data_view
  UNION ALL
  select t.* from ku$_iotable_data_view t
  where refpar_level = 0
  UNION ALL
  select t.* from ku$_iotpart_data_view t
  where refpar_level = 0
/

