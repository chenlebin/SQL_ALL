create view KU$_11_1_OBJGRANT_VIEW
            (VERS_MAJOR, VERS_MINOR, OBJ_NUM, BASE_OBJ, LONG_NAME, GRANTOR, GRANTEE, PRIVNAME, SEQUENCE, WGO,
             COLNAME) as
select '1','2',
         g.obj#, value(o),
         (select j.longdbcs from sys.javasnm$ j where j.short = o.name),
         u1.name, u2.name, p.name, g.sequence#,
         NVL(g.option$,0),
         (select c.name from sys.col$ c where g.obj#=c.obj# and g.col#=c.col#
          and bitand(c.property, 1) = 0)        -- exclude ADT attribute column
  from sys.ku$_schemaobj_view o, sys.objauth$ g, sys.user$ u1, sys.user$ u2,
       sys.table_privilege_map p
  where g.obj#=o.obj_num and
        g.grantor#=u1.user# and
        g.grantee#=u2.user# and
        g.privilege#=p.privilege and
        (SYS_CONTEXT('USERENV','CURRENT_USERID')
                IN (g.grantor#, g.grantee#, o.owner_num, 0) OR
                g.grantee#=1 OR
                EXISTS ( SELECT * FROM sys.session_roles
                        WHERE role='SELECT_CATALOG_ROLE' ))
/

