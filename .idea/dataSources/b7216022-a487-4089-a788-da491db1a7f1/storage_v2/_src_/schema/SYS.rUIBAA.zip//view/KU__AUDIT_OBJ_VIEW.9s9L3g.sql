create view KU$_AUDIT_OBJ_VIEW (VERS_MAJOR, VERS_MINOR, OBJ_NUM, BASE_OBJ, AUDIT_VAL, AUDIT_LIST) as
select value(ku$) from sys.ku$_audit_obj_base_view ku$
  where trim('-' from ku$.audit_val) IS NOT NULL
  and  (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (ku$.base_obj.owner_num, 0)
        OR    EXISTS ( SELECT * FROM sys.session_roles
                       WHERE role='SELECT_CATALOG_ROLE' ))
/

