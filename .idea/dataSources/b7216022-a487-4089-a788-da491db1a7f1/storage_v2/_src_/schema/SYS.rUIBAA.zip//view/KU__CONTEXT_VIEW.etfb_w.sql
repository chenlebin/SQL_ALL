create view KU$_CONTEXT_VIEW (VERS_MAJOR, VERS_MINOR, OBJ_NUM, SCHEMA_OBJ, SCHEMA_NAME, PACKAGE_NAME, FLAGS) as
select '1','0',
         c.obj#, value(o),
         c.schema, c.package, c.flags
  from   sys.ku$_schemaobj_view o, sys.context$ c
  where  o.obj_num = c.obj# AND
         (SYS_CONTEXT('USERENV','CURRENT_USERID') = 0 OR
                EXISTS ( SELECT * FROM sys.session_roles
                        WHERE role='SELECT_CATALOG_ROLE' ))
/

