create view KU$_DEPTABLE_OBJNUM_VIEW (OBJ_NUM, SCHEMA_OBJ, BASE_OBJ) as
select * from ku$_hdeptable_objnum_view
  UNION ALL
  select * from ku$_ndeptable_objnum_view
/

