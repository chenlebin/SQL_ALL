create view KU$_EXP_PKG_BODY_VIEW
            (VERS_MAJOR, VERS_MINOR, BASE_OBJ_NUM, OBJ_NUM, TYPE_NUM, SCHEMA_OBJ, SOURCE_LINES, COMPILER_INFO) as
select '1','1',
       (select o1.obj# from sys.ku$_edition_obj_view o1 where o1.type#=9
               and o1.name=o2.name and o1.owner#=o2.owner#
               and o1.linkname is NULL),
       o2.obj#,o2.type#,
       (select value(o) from sys.ku$_edition_schemaobj_view o where o.obj_num=o2.obj#),
       sys.dbms_metadata_util.get_source_lines(o2.name,o2.obj#,o2.type#),
       (select value(c) from sys.ku$_switch_compiler_view c
                 where c.obj_num = o2.obj#)
  from sys.ku$_edition_obj_view o2
  where o2.type#=11
         AND (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o2.owner#, 0) OR
              EXISTS ( SELECT * FROM sys.session_roles
                       WHERE role='SELECT_CATALOG_ROLE' ))
/

