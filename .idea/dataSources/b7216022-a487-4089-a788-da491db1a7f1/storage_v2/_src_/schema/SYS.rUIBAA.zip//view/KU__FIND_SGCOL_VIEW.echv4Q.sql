create view KU$_FIND_SGCOL_VIEW (OWNER_NAME, TABLE_NAME, COL_NAME, COL_DEFAULT) as
select  u.name, o.name, c.name, c.default$
  from    sys.col$ c, sys.obj$ o, user$ u
  where   c.obj# = o.obj# and o.owner# = u.user# and default$ IS NOT NULL and
          (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o.owner#, 0) OR
              EXISTS ( SELECT * FROM sys.session_roles
                       WHERE role='SELECT_CATALOG_ROLE' ))
/

