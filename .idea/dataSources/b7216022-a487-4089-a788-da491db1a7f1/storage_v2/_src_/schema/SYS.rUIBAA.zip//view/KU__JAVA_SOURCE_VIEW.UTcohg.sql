create view KU$_JAVA_SOURCE_VIEW
            (VERS_MAJOR, VERS_MINOR, OBJ_NUM, SCHEMA_OBJ, LONG_NAME, SOURCE_LINES, JAVA_RESOURCE) as
select '1','0',
         o.obj_num, value(o),
         nvl((select j.longdbcs from sys.javasnm$ j where j.short = o.name),
             o.name),
         cast(multiset(select s.joxftobn, s.joxftlno,
                              NULL,NULL,NULL,NULL,NULL, s.joxftsrc
                from  x$joxfs s
                       where s.joxftobn = o.obj_num order by s.joxftlno
                       ) as ku$_source_list_t
             ),
         sys.dbms_metadata.get_java_metadata (o.name,
                                                   o.owner_name, o.type_num)
  from sys.ku$_schemaobj_view o
  where o.type_num = 28 and
            (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o.owner_num, 0)
             OR EXISTS ( SELECT * FROM sys.session_roles
                WHERE role='SELECT_CATALOG_ROLE' ))
/

