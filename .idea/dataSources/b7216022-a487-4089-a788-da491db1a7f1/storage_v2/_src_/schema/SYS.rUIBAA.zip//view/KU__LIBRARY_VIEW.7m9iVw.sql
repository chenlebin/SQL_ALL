create view KU$_LIBRARY_VIEW (VERS_MAJOR, VERS_MINOR, OBJ_NUM, SCHEMA_OBJ, FILESPEC, LIB_AUDIT, PROPERTY) as
select '1','0',
         lb.obj#, value(o),
         lb.filespec,
         replace(lb.audit$,chr(0),'-'),
         lb.property
  from sys.ku$_edition_schemaobj_view o, sys.library$ lb
  where o.type_num=22 AND
        lb.obj# = o.obj_num AND
         (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o.owner_num, 0) OR
                EXISTS ( SELECT * FROM sys.session_roles
                        WHERE role='SELECT_CATALOG_ROLE' ))
/

