create view KU$_MVLPROP_VIEW (OBJ_NUM, NAME, SCHEMA, FLAGS, PROPERTY) as
select o.obj#, m.master, m.mowner, o.flags, t.property
 from obj$ o, tab$ t, user$ u, mlog$ m
 where o.owner# = u.user#
 and   o.obj#   = t.obj#
 and   m.mowner = u.name
 and   m.log = o.name
 and  (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o.owner#,0) OR
                EXISTS ( SELECT * FROM sys.session_roles
                        WHERE role='SELECT_CATALOG_ROLE' ))
/

