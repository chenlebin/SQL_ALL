create view KU$_MVPROP_VIEW (OBJ_NUM, NAME, SCHEMA, FLAGS, PROPERTY) as
select o.obj#, o.name, u.name, o.flags, t.property
 from obj$ o, tab$ t, user$ u, snap$ s
 where o.owner# = u.user#
 and   o.obj#   = t.obj#
 and   s.sowner = u.name
 and   s.tname  = o.name
 and  (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o.owner#,0) OR
                EXISTS ( SELECT * FROM sys.session_roles
                        WHERE role='SELECT_CATALOG_ROLE' ))
/

