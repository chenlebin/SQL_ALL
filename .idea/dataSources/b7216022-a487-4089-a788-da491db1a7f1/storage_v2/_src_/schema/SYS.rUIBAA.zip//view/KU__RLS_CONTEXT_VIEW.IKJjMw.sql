create view KU$_RLS_CONTEXT_VIEW (VERS_MAJOR, VERS_MINOR, BASE_OBJ, OBJ_NUM, NAME, ATTR) as
select '1','0',
          value(sov),
          rc.obj# ,rc.ns ,rc.attr
  from    ku$_schemaobj_view sov, sys.rls_ctx$ rc
  where   rc.obj# = sov.obj_num
      and (SYS_CONTEXT('USERENV','CURRENT_USERID') = 0 OR
              EXISTS ( SELECT * FROM sys.session_roles
                       WHERE role='SELECT_CATALOG_ROLE' ))
/

