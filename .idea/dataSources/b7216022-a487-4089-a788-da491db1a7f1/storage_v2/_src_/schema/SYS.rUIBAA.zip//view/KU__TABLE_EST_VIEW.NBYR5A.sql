create view KU$_TABLE_EST_VIEW (COLS, ROWCNT, AVGRLN, OBJECT_SCHEMA, OBJECT_NAME) as
SELECT  NVL(t.cols,0), NVL(t.rowcnt, 0), NVL(t.avgrln, 0), u.name,
                o.name
        FROM    SYS.OBJ$ O, SYS.TAB$ T, SYS.USER$ U
        WHERE   t.obj# = o.obj# AND
                o.owner# = u.user# AND
                (UID IN (0, o.owner#) OR
                 EXISTS (
                    SELECT  role
                    FROM    sys.session_roles
                    WHERE   role = 'SELECT_CATALOG_ROLE'))
/

