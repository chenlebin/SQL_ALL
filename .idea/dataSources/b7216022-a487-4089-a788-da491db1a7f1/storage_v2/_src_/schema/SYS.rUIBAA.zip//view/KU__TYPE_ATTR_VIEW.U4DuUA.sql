create view KU$_TYPE_ATTR_VIEW
            (TOID, VERSION_NUM, NAME, ATTRIBUTE_NUM, ATTR_VERS_NUM, ATTR_TOID, SYNOBJ_NUM, PROPERTIES, CHARSETID,
             CHARSETFORM, LENGTH, PRECISION_NUM, SCALE, EXTERNNAME, XFLAGS, SPARE1, SPARE2, SPARE3, SPARE4, SPARE5,
             SETTER, GETTER, TYPEMD)
as
select
  a.toid,
  a.version#,
  a.name,
  a.attribute#,
  a.attr_version#,
  a.attr_toid,
  a.synobj#,
  a.properties,
  a.charsetid,
  a.charsetform,
  a.length,
  a.precision#,
  a.scale,
  a.externname,
  a.xflags,
  a.spare1,
  a.spare2,
  a.spare3,
  a.spare4,
  a.spare5,
  a.setter,
  a.getter,
  (select value(st) from ku$_simple_type_view st
   where a.attr_toid = st.toid
         and st.version = (SELECT MAX(ST2.VERSION)
                           FROM ku$_simple_type_View st2
                           WHERE ST2.TOID = a.attr_toid))
from  sys.attribute$ a
/

