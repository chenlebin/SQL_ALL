create view KU$_XMLSCHEMA_VIEW
            (VERS_MAJOR, VERS_MINOR, OWNER_NUM, OWNER_NAME, URL, SCHEMAOID, LOCAL, SCHEMA_LEVEL, SCHEMA_VAL,
             STRIPPED_VAL) as
select '1','0',
        u.user#, u.name, x.schema_url, x.schema_id,
        (case when x.local='YES' then 1 else 0 end
         + case when x.binary='YES' then 2 else 0 end),
        xdb.dbms_xdbutil_int.XMLSchemaDependencyLevel(x.schema_id,
                                                      u.name),
        x.schema.getClobVal(),
        xdb.dbms_xdbutil_int.XMLSchemaStripUsername(XMLTYPE(
                                                     x.schema.getClobVal()),
                                                    u.name)    -- stripped
    from sys.user$ u, sys.dba_xml_schemas x
    where x.owner=u.name and
          (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (u.user#, 0) OR
                EXISTS ( SELECT * FROM session_roles
                        WHERE role='SELECT_CATALOG_ROLE' ))
/

