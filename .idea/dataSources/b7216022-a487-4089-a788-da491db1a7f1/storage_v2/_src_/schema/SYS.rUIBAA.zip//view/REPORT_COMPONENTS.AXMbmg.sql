create view REPORT_COMPONENTS
            (COMPONENT_ID, COMPONENT_NAME, COMPONENT_DESCRIPTION, REPORT_ID, REPORT_NAME, REPORT_DESCRIPTION,
             SCHEMA_FILENAME, SCHEMA_DATA)
as
SELECT c.id component_id, c.name component_name,
            c.description component_description,
            r.id report_id, r.name report_name,
            r.description report_description,
            f.name schema_filename,
            f.data schema_data
     FROM   wri$_rept_components c,
            wri$_rept_reports r,
            wri$_rept_files f
     WHERE  c.id = r.component_id AND
            r.schema_id = f.id (+)
/

