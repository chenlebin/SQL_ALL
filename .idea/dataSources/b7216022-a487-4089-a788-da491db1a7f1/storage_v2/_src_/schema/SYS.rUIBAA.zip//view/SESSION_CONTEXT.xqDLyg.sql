create view SESSION_CONTEXT (NAMESPACE, ATTRIBUTE, VALUE) as
select namespace, attribute, value from v_$context
/

comment on table SESSION_CONTEXT is 'Description of all context attributes set under the current session'
/

comment on column SESSION_CONTEXT.NAMESPACE is 'Namespace of the attribute'
/

comment on column SESSION_CONTEXT.ATTRIBUTE is 'Name of the attribute'
/

comment on column SESSION_CONTEXT.VALUE is 'Value of the attribute'
/

