create view TABLE_PRIVILEGES
            (GRANTEE, OWNER, TABLE_NAME, GRANTOR, SELECT_PRIV, INSERT_PRIV, DELETE_PRIV, UPDATE_PRIV, REFERENCES_PRIV,
             ALTER_PRIV, INDEX_PRIV, CREATED)
as
select ue.name, u.name, o.name, ur.name,
    decode(substr(lpad(sum(power(10, privilege#*2) +
      decode(mod(option$,2), 1, power(10, privilege#*2 + 1), 0)), 26, '0'), 7, 2),
      '00', 'N', '01', 'Y', '11', 'G', 'N'),
     decode(substr(lpad(sum(decode(col#, null, power(10, privilege#*2) +
       decode(mod(option$,2), 1, power(10, privilege#*2 + 1), 0), 0)), 26, '0'),
              13, 2), '01', 'A', '11', 'G',
          decode(sum(decode(col#,
                            null, 0,
                            decode(privilege#, 6, 1, 0))), 0, 'N', 'S')),
    decode(substr(lpad(sum(power(10, privilege#*2) +
      decode(mod(option$,2), 1, power(10, privilege#*2 + 1), 0)), 26, '0'), 19, 2),
      '00', 'N', '01', 'Y', '11', 'G', 'N'),
    decode(substr(lpad(sum(decode(col#, null, power(10, privilege#*2) +
      decode(mod(option$,2), 1, power(10, privilege#*2 + 1), 0), 0)), 26, '0'),
             5, 2),'01', 'A', '11', 'G',
          decode(sum(decode(col#,
                            null, 0,
                            decode(privilege#, 10, 1, 0))), 0, 'N', 'S')),
    decode(substr(lpad(sum(decode(col#, null, power(10, privilege#*2) +
      decode(mod(option$,2), 1, power(10, privilege#*2 + 1), 0), 0)), 26, '0'),
             3, 2), '01', 'A', '11', 'G',
          decode(sum(decode(col#,
                            null, 0,
                            decode(privilege#, 11, 1, 0))), 0, 'N', 'S')),
   decode(substr(lpad(sum(power(10, privilege#*2) +
      decode(mod(option$,2), 1, power(10, privilege#*2 + 1), 0)), 26, '0'), 25, 2),
      '00', 'N', '01', 'Y', '11', 'G', 'N'),
    decode(substr(lpad(sum(power(10, privilege#*2) +
      decode(mod(option$,2), 1, power(10, privilege#*2 + 1), 0)), 26, '0'), 15, 2),
      '00', 'N', '01', 'Y', '11', 'G', 'N'), min(null)
from sys.objauth$ oa, sys."_CURRENT_EDITION_OBJ" o, sys.user$ ue, sys.user$ ur, sys.user$ u
where oa.obj# = o.obj#
  and oa.grantor# = ur.user#
  and oa.grantee# = ue.user#
  and u.user# = o.owner#
  and (oa.grantor# = userenv('SCHEMAID') or
       oa.grantee# in (select kzsrorol from x$kzsro) or
       o.owner# = userenv('SCHEMAID'))
  group by u.name, o.name, ur.name, ue.name
/

comment on table TABLE_PRIVILEGES is 'Grants on objects for which the user is the grantor, grantee, owner,
 or an enabled role or PUBLIC is the grantee'
/

comment on column TABLE_PRIVILEGES.GRANTEE is 'Name of the user to whom access was granted'
/

comment on column TABLE_PRIVILEGES.OWNER is 'Owner of the object'
/

comment on column TABLE_PRIVILEGES.TABLE_NAME is 'Name of the object'
/

comment on column TABLE_PRIVILEGES.GRANTOR is 'Name of the user who performed the grant'
/

comment on column TABLE_PRIVILEGES.SELECT_PRIV is 'Permission to SELECT from the object?'
/

comment on column TABLE_PRIVILEGES.INSERT_PRIV is 'Permission to INSERT into the object?'
/

comment on column TABLE_PRIVILEGES.DELETE_PRIV is 'Permission to DELETE from the object?'
/

comment on column TABLE_PRIVILEGES.UPDATE_PRIV is 'Permission to UPDATE the object?'
/

comment on column TABLE_PRIVILEGES.REFERENCES_PRIV is 'Permission to make REFERENCES to the object?'
/

comment on column TABLE_PRIVILEGES.ALTER_PRIV is 'Permission to ALTER the object?'
/

comment on column TABLE_PRIVILEGES.INDEX_PRIV is 'Permission to create/drop an INDEX on the object?'
/

comment on column TABLE_PRIVILEGES.CREATED is 'Timestamp for the grant'
/

