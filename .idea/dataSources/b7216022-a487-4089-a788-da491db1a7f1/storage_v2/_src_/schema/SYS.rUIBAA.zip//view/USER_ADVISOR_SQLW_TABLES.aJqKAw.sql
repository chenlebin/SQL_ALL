create view USER_ADVISOR_SQLW_TABLES (WORKLOAD_ID, WORKLOAD_NAME, SQL_ID, TABLE_OWNER, TABLE_NAME) as
select b.workload_id as workload_id,
             c.name as workload_name,
             b.sql_id as sql_id,
             b.table_owner  as table_owner,
             b.table_name as table_name
      from wri$_adv_sqlw_tables b, wri$_adv_tasks c
      where c.id = b.workload_id
        and c.owner# = userenv('SCHEMAID')
        and bitand(c.property,2) = 0
        and c.advisor_id = 6
/

