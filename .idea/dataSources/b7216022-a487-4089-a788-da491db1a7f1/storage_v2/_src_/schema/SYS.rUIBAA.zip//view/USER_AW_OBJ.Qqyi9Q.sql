create view USER_AW_OBJ (AW_NUMBER, AW_NAME, OBJ_ID, OBJ_NAME, OBJ_TYPE, PART_NAME) as
SELECT a.awseq#, a.awname, o.oid, o.objname, o.objtype, o.partname
FROM aw$ a, aw_obj$ o,
     (select max(rowid) keep (dense_rank last order by gen#) rid
      from aw_obj$ group by awseq#, oid)
WHERE   a.owner#=USERENV('SCHEMAID') and a.awseq#=o.awseq#
        and o.rowid = rid and o.objtype IS NOT NULL
/

comment on table USER_AW_OBJ is 'Objects in Analytic Workspaces owned by the user'
/

comment on column USER_AW_OBJ.AW_NUMBER is 'Number of the Analytic Workspace'
/

comment on column USER_AW_OBJ.AW_NAME is 'Name of the Analytic Workspace'
/

comment on column USER_AW_OBJ.OBJ_ID is 'Object ID in the Analytic Workspace'
/

comment on column USER_AW_OBJ.OBJ_NAME is 'Object name in the Analytic Workspace'
/

comment on column USER_AW_OBJ.OBJ_TYPE is 'Type of the object in the Analytic Workspace'
/

comment on column USER_AW_OBJ.PART_NAME is 'Partition of the object in the Analytic Workspace'
/

