create view USER_AW_PS (AW_NUMBER, AW_NAME, PSNUMBER, GENERATIONS, MAXPAGES) as
SELECT a.awseq#, a.awname, p.psnumber, count(unique(p.psgen)), max(p.maxpages)
FROM aw$ a, ps$ p
WHERE   a.owner#=USERENV('SCHEMAID') and a.awseq#=p.awseq#
group by a.awseq#, a.awname, p.psnumber
/

comment on table USER_AW_PS is 'Pagespaces in Analytic Workspaces owned by the user'
/

comment on column USER_AW_PS.AW_NAME is 'Name of the Analytic Workspace'
/

comment on column USER_AW_PS.PSNUMBER is 'Number of the pagespace'
/

comment on column USER_AW_PS.GENERATIONS is 'Number of active generations in the pagespace'
/

comment on column USER_AW_PS.MAXPAGES is 'Maximum pages allocated in the pagespace'
/

