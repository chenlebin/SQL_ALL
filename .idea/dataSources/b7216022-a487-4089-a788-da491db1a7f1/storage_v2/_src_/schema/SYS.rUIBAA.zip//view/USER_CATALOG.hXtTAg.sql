create view USER_CATALOG (TABLE_NAME, TABLE_TYPE) as
select o.name,
       decode(o.type#, 0, 'NEXT OBJECT', 1, 'INDEX', 2, 'TABLE', 3, 'CLUSTER',
                      4, 'VIEW', 5, 'SYNONYM', 6, 'SEQUENCE', 'UNDEFINED')
from sys."_CURRENT_EDITION_OBJ" o
where o.owner# = userenv('SCHEMAID')
  and ((o.type# in (4, 5, 6))
       or
       (o.type# = 2     /* tables, excluding iot - overflow and nested tables */
        and
        not exists (select null
                      from sys.tab$ t
                     where t.obj# = o.obj#
                       and (bitand(t.property, 512) = 512 or
                            bitand(t.property, 8192) = 8192))))
  and o.linkname is null
/

comment on table USER_CATALOG is 'Tables, Views, Synonyms and Sequences owned by the user'
/

comment on column USER_CATALOG.TABLE_NAME is 'Name of the object'
/

comment on column USER_CATALOG.TABLE_TYPE is 'Type of the object'
/

