create view USER_COL_PENDING_STATS
            (TABLE_NAME, PARTITION_NAME, SUBPARTITION_NAME, COLUMN_NAME, NUM_DISTINCT, LOW_VALUE, HIGH_VALUE, DENSITY,
             NUM_NULLS, AVG_COL_LEN, SAMPLE_SIZE, LAST_ANALYZED)
as
select o.name, null, null, c.name, h.distcnt, h.lowval, h.hival,
         h.density, h.null_cnt, h.avgcln, h.sample_size, h.TIMESTAMP#
  from   sys.obj$ o, sys.col$ c,
         sys.wri$_optstat_histhead_history h
  where  h.obj# = c.obj#
    and  h.intcol# = c.intcol#
    and  h.obj# = o.obj#
    and  o.type# = 2
    and  h.savtime > systimestamp
    and  o.owner# = userenv('SCHEMAID')
  union all
  -- partitions
  select o.name, o.subname, null, c.name, h.distcnt, h.lowval, h.hival,
         h.density, h.null_cnt, h.avgcln, h.sample_size, h.TIMESTAMP#
  from   sys.user$ u, sys.obj$ o, sys.col$ c, sys.tabpart$ t,
         sys.wri$_optstat_histhead_history h
  where  t.bo# = c.obj#
    and  t.obj# = o.obj#
    and  h.intcol# = c.intcol#
    and  h.obj# = o.obj#
    and  o.type# = 19
    and  o.owner# = u.user#
    and  h.savtime > systimestamp
    and  o.owner# = userenv('SCHEMAID')
  union all
  select o.name, o.subname, null, c.name, h.distcnt, h.lowval, h.hival,
         h.density, h.null_cnt, h.avgcln, h.sample_size, h.TIMESTAMP#
  from   sys.user$ u, sys.obj$ o, sys.col$ c, sys.tabcompart$ t,
         sys.wri$_optstat_histhead_history h
  where  t.bo# = c.obj#
    and  t.obj# = o.obj#
    and  h.intcol# = c.intcol#
    and  h.obj# = o.obj#
    and  o.type# = 19
    and  o.owner# = u.user#
    and  h.savtime > systimestamp
    and  o.owner# = userenv('SCHEMAID')
  union all
  -- sub partitions
  select op.name, op.subname, os.subname, c.name, h.distcnt,
         h.lowval, h.hival, h.density, h.null_cnt, h.avgcln, h.sample_size,
         h.timestamp#
  from  sys.obj$ os, sys.tabsubpart$ tsp, sys.tabcompart$ tcp,
        sys.col$ c, sys.obj$ op,
        sys.wri$_optstat_histhead_history h
  where os.obj# = tsp.obj#
    and h.obj#  = tsp.obj#
    and h.intcol#= c.intcol#
    and tsp.pobj#= tcp.obj#
    and tcp.bo#  = c.obj#
    and tcp.obj# = op.obj#
    and os.type# = 34
    and h.savtime > systimestamp
    and os.owner# = userenv('SCHEMAID')
/

comment on table USER_COL_PENDING_STATS is 'Pending statistics of tables, partitions, and subpartitions'
/

comment on column USER_COL_PENDING_STATS.TABLE_NAME is 'Table name'
/

comment on column USER_COL_PENDING_STATS.PARTITION_NAME is 'Partition name'
/

comment on column USER_COL_PENDING_STATS.SUBPARTITION_NAME is 'Subpartition name'
/

comment on column USER_COL_PENDING_STATS.COLUMN_NAME is 'Column name'
/

comment on column USER_COL_PENDING_STATS.NUM_DISTINCT is 'The number of distinct values in the column'
/

comment on column USER_COL_PENDING_STATS.LOW_VALUE is 'The low value in the column'
/

comment on column USER_COL_PENDING_STATS.HIGH_VALUE is 'The high value in the column'
/

comment on column USER_COL_PENDING_STATS.DENSITY is 'The density of the column'
/

comment on column USER_COL_PENDING_STATS.NUM_NULLS is 'The number rows with value in the column'
/

comment on column USER_COL_PENDING_STATS.AVG_COL_LEN is 'The average length of the column in bytes'
/

comment on column USER_COL_PENDING_STATS.SAMPLE_SIZE is 'The sample size used in analyzing this column'
/

comment on column USER_COL_PENDING_STATS.LAST_ANALYZED is 'The date of the most recent time this column was analyzed'
/

