create view USER_COL_PRIVS_RECD (OWNER, TABLE_NAME, COLUMN_NAME, GRANTOR, PRIVILEGE, GRANTABLE) as
select u.name, o.name, c.name, ur.name, tpm.name,
       decode(mod(oa.option$,2), 1, 'YES', 'NO')
from sys.objauth$ oa, sys."_CURRENT_EDITION_OBJ" o, sys.user$ u, sys.user$ ur,
     sys.col$ c, table_privilege_map tpm
where oa.obj# = o.obj#
  and oa.grantor# = ur.user#
  and u.user# = o.owner#
  and oa.obj# = c.obj#
  and oa.col# = c.col#
  and bitand(c.property, 32) = 0 /* not hidden column */
  and oa.col# is not null
  and oa.privilege# = tpm.privilege
  and oa.grantee# = userenv('SCHEMAID')
/

comment on table USER_COL_PRIVS_RECD is 'Grants on columns for which the user is the grantee'
/

comment on column USER_COL_PRIVS_RECD.OWNER is 'Username of the owner of the object'
/

comment on column USER_COL_PRIVS_RECD.TABLE_NAME is 'Name of the object'
/

comment on column USER_COL_PRIVS_RECD.COLUMN_NAME is 'Name of the column'
/

comment on column USER_COL_PRIVS_RECD.GRANTOR is 'Name of the user who performed the grant'
/

comment on column USER_COL_PRIVS_RECD.PRIVILEGE is 'Column Privilege'
/

comment on column USER_COL_PRIVS_RECD.GRANTABLE is 'Privilege is grantable'
/

