create view USER_COMPARISON
            (COMPARISON_NAME, COMPARISON_MODE, SCHEMA_NAME, OBJECT_NAME, OBJECT_TYPE, REMOTE_SCHEMA_NAME,
             REMOTE_OBJECT_NAME, REMOTE_OBJECT_TYPE, DBLINK_NAME, SCAN_MODE, SCAN_PERCENT, CYCLIC_INDEX_VALUE,
             NULL_VALUE, LOCAL_CONVERGE_TAG, REMOTE_CONVERGE_TAG, MAX_NUM_BUCKETS, MIN_ROWS_IN_BUCKET, LAST_UPDATE_TIME)
as
SELECT comparison_name, comparison_mode,
   schema_name, object_name, object_type,
   remote_schema_name, remote_object_name, remote_object_type, dblink_name,
   scan_mode, scan_percent,
   cyclic_index_value, null_value, local_converge_tag, remote_converge_tag,
   max_num_buckets, min_rows_in_bucket, last_update_time
FROM dba_comparison
WHERE owner = SYS_CONTEXT('USERENV','CURRENT_USER')
/

comment on table USER_COMPARISON is 'Details about the user''s comparison objects'
/

comment on column USER_COMPARISON.COMPARISON_NAME is 'Name of comparison'
/

comment on column USER_COMPARISON.COMPARISON_MODE is 'Mode of comparison: TABLE'
/

comment on column USER_COMPARISON.SCHEMA_NAME is 'Schema name of local object'
/

comment on column USER_COMPARISON.OBJECT_NAME is 'Name of local object'
/

comment on column USER_COMPARISON.OBJECT_TYPE is 'Type of local object'
/

comment on column USER_COMPARISON.REMOTE_SCHEMA_NAME is 'Schema name of remote object'
/

comment on column USER_COMPARISON.REMOTE_OBJECT_NAME is 'Name of remote object'
/

comment on column USER_COMPARISON.REMOTE_OBJECT_TYPE is 'Type of remote object'
/

comment on column USER_COMPARISON.DBLINK_NAME is 'Database link name to remote database'
/

comment on column USER_COMPARISON.SCAN_MODE is 'Scan mode of comparison: FULL'
/

comment on column USER_COMPARISON.SCAN_PERCENT is 'Scan percent of comparison: Applicable to Random and Cyclic modes'
/

comment on column USER_COMPARISON.CYCLIC_INDEX_VALUE is 'Last index column value used in a cyclic scan'
/

comment on column USER_COMPARISON.NULL_VALUE is 'Value to use for null column values'
/

comment on column USER_COMPARISON.LOCAL_CONVERGE_TAG is 'The local streams tag used while performing converge dmls'
/

comment on column USER_COMPARISON.REMOTE_CONVERGE_TAG is 'The remote streams tag used while performing converge dmls'
/

comment on column USER_COMPARISON.MAX_NUM_BUCKETS is 'Suggested number of buckets in a scan'
/

comment on column USER_COMPARISON.MIN_ROWS_IN_BUCKET is 'Suggested number of rows in a bucket'
/

comment on column USER_COMPARISON.LAST_UPDATE_TIME is 'The time that this row was updated'
/

