create view USER_COMPARISON_COLUMNS (COMPARISON_NAME, COLUMN_POSITION, COLUMN_NAME, INDEX_COLUMN) as
SELECT comparison_name, column_position, column_name, index_column
FROM dba_comparison_columns
WHERE owner = SYS_CONTEXT('USERENV','CURRENT_USER')
/

comment on table USER_COMPARISON_COLUMNS is 'Details about the comparison object''s columns'
/

comment on column USER_COMPARISON_COLUMNS.COMPARISON_NAME is 'Name of comparison'
/

comment on column USER_COMPARISON_COLUMNS.COLUMN_POSITION is 'Column position'
/

comment on column USER_COMPARISON_COLUMNS.COLUMN_NAME is 'Name of column'
/

