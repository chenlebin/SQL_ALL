create view USER_CUBES
            (CUBE_NAME, AW_NAME, CONSISTENT_SOLVE_SPEC, DESCRIPTION, SPARSE_TYPE, PRECOMPUTE_CONDITION,
             PRECOMPUTE_PERCENT, PRECOMPUTE_PERCENT_TOP, PARTITION_DIMENSION_NAME, PARTITION_HIERARCHY_NAME,
             PARTITION_LEVEL_NAME)
as
SELECT
  o.name CUBE_NAME,
  a.awname AW_NAME,
  syn.syntax_clob CONSISTENT_SOLVE_SPEC,
  d.description_value DESCRIPTION,
  io.option_value SPARSE_TYPE,
  syn2.syntax_clob PRECOMPUTE_CONDITION,
  io2.option_num_value PRECOMPUTE_PERCENT,
  io3.option_num_value PRECOMPUTE_PERCENT_TOP,
  od.name PARTITION_DIMENSION_NAME,
  h.hierarchy_name PARTITION_HIERARCHY_NAME,
  dl.level_name PARTITION_LEVEL_NAME
FROM
  olap_cubes$ c,
  aw$ a,
  obj$ o,
  olap_syntax$ syn,
  olap_syntax$ syn2,
  (select d.* from olap_descriptions$ d, nls_session_parameters n where
	n.parameter = 'NLS_LANGUAGE'
	and d.description_type = 'Description'
	and d.owning_object_type = 1 --CUBE
	and (d.language = n.value
             or d.language like n.value || '\_%' escape '\')) d,
  olap_impl_options$ io,
  olap_impl_options$ io2,
  olap_impl_options$ io3,
  olap_impl_options$ io4,
  olap_hier_levels$ hl,
  olap_dim_levels$ dl,
  olap_hierarchies$ h,
  obj$ od
WHERE
  o.obj#=c.obj#
  AND o.owner#=USERENV('SCHEMAID')
  AND c.awseq#=a.awseq#(+)
  AND c.obj#=d.owning_object_id(+)
  AND syn.owner_id(+)=c.obj#
  AND syn.owner_type(+)=1
  AND syn.ref_role(+)=16 -- consistent solve spec
  AND syn2.owner_id(+)=c.obj#
  AND syn2.owner_type(+)=1
  AND syn2.ref_role(+)=20 -- precompute condition
  AND io.owning_objectid(+)=c.obj#
  AND io.object_type(+)=1
  AND io.option_type(+)=7 -- sparse type
  AND io2.owning_objectid(+)=c.obj#
  AND io2.object_type(+)=1
  AND io2.option_type(+)=24 -- precompute percent
  AND io3.owning_objectid(+)=c.obj#
  AND io3.object_type(+)=1
  AND io3.option_type(+)=25 -- precompute percent top
  AND io4.owning_objectid(+)=c.obj#
  AND io4.object_type(+)=1
  AND io4.option_type(+)=9 -- partition level
  AND io4.option_num_value=hl.hierarchy_level_id(+)
  AND hl.hierarchy_id=h.hierarchy_id(+)
  AND hl.dim_level_id=dl.level_id(+)
  AND h.dim_obj#=od.obj#(+)
/

comment on table USER_CUBES is 'OLAP Cubes owned by the user in the database'
/

comment on column USER_CUBES.CUBE_NAME is 'Name of the OLAP Cube'
/

comment on column USER_CUBES.AW_NAME is 'Name of the Analytic Workspace which owns the OLAP Cube'
/

comment on column USER_CUBES.CONSISTENT_SOLVE_SPEC is 'The Consistent Solve Specification for the OLAP Cube'
/

comment on column USER_CUBES.DESCRIPTION is 'Long Description of the OLAP Cube'
/

comment on column USER_CUBES.SPARSE_TYPE is 'Text value indicating type of sparsity for the OLAP Cube'
/

comment on column USER_CUBES.PRECOMPUTE_CONDITION is 'Condition syntax representing precompute condition of the OLAP Cube'
/

comment on column USER_CUBES.PRECOMPUTE_PERCENT is 'Precompute percent of the OLAP Cube'
/

comment on column USER_CUBES.PRECOMPUTE_PERCENT_TOP is 'Top precompute percent of the OLAP Cube'
/

comment on column USER_CUBES.PARTITION_DIMENSION_NAME is 'Name of the Cube Dimension for which there is a partition on the OLAP Cube'
/

comment on column USER_CUBES.PARTITION_HIERARCHY_NAME is 'Name of the Hierarchy for which there is a partition on the OLAP Cube'
/

comment on column USER_CUBES.PARTITION_LEVEL_NAME is 'Name of the HierarchyLevel for which there is a partition on the OLAP Cube'
/

