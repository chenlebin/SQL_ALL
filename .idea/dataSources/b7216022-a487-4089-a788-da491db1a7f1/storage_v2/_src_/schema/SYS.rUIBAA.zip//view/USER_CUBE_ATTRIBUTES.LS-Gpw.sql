create view USER_CUBE_ATTRIBUTES
            (DIMENSION_NAME, ATTRIBUTE_NAME, TARGET_DIMENSION_NAME, ATTRIBUTE_ROLE, DESCRIPTION, DATA_TYPE, DATA_LENGTH,
             DATA_PRECISION, DATA_SCALE)
as
SELECT
  o.name DIMENSION_NAME,
  a.attribute_name ATTRIBUTE_NAME,
  tdo.name TARGET_DIMENSION_NAME,
  (CASE a.attribute_role_mask
     WHEN 1 THEN 'SHORT_DESCRIPTION'
     WHEN 2 THEN 'LONG_DESCRIPTION'
     WHEN 3 THEN 'DESCRIPTION'
     WHEN 4 THEN 'TIME_SPAN'
     WHEN 8 THEN 'END_DATE'
     WHEN 16 THEN 'START_DATE'
     ELSE null END) ATTRIBUTE_ROLE,
  d.description_value DESCRIPTION,
  DECODE(a.type#, 1, decode(a.charsetform, 2, 'NVARCHAR2', 'VARCHAR2'),
                  2, decode(a.scale, null,
                            decode(a.precision#, null, 'NUMBER', 'FLOAT'),
                            'NUMBER'),
                  8, 'LONG',
                  9, decode(a.charsetform, 2, 'NCHAR VARYING', 'VARCHAR'),
                  12, 'DATE',
                  23, 'RAW', 24, 'LONG RAW',
                  69, 'ROWID',
                  96, decode(a.charsetform, 2, 'NCHAR', 'CHAR'),
                  100, 'BINARY_FLOAT',
                  101, 'BINARY_DOUBLE',
                  105, 'MLSLABEL',
                  106, 'MLSLABEL',
                  112, decode(a.charsetform, 2, 'NCLOB', 'CLOB'),
                  113, 'BLOB', 114, 'BFILE', 115, 'CFILE',
                  178, 'TIME(' ||a.scale|| ')',
                  179, 'TIME(' ||a.scale|| ')' || ' WITH TIME ZONE',
                  180, 'TIMESTAMP(' ||a.scale|| ')',
                  181, 'TIMESTAMP(' ||a.scale|| ')' || ' WITH TIME ZONE',
                  231, 'TIMESTAMP(' ||a.scale|| ')' || ' WITH LOCAL TIME ZONE',
                  182, 'INTERVAL YEAR(' ||a.precision#||') TO MONTH',
                  183, 'INTERVAL DAY(' ||a.precision#||') TO SECOND(' ||
                        a.scale || ')',
                  208, 'UROWID',
                  'UNDEFINED') DATA_TYPE,
  a.length DATA_LENGTH,
  a.precision# DATA_PRECISION,
  a.scale DATA_SCALE
FROM
  olap_attributes$ a,
  obj$ o,
  obj$ tdo,
  (select d.* from olap_descriptions$ d, nls_session_parameters n where
	n.parameter = 'NLS_LANGUAGE'
	and d.description_type = 'Description'
	and d.owning_object_type = 15 --ATTRIBUTE
	and (d.language = n.value
             or d.language like n.value || '\_%' escape '\')) d,
  olap_syntax$ s
WHERE
  o.obj#=a.dim_obj#
  AND o.owner#=USERENV('SCHEMAID')
  AND a.target_dim#=tdo.obj#(+)
  AND a.attribute_id=s.owner_id(+)
  AND s.owner_type(+) = 15 --ATTRIBUTE
  AND s.ref_role(+) = 2 --ATTRIBUTE_ROLE
  AND a.attribute_id = d.owning_object_id(+)
/

comment on table USER_CUBE_ATTRIBUTES is 'OLAP Attributes owned by the user in the database'
/

comment on column USER_CUBE_ATTRIBUTES.DIMENSION_NAME is 'Name of owning Cube Dimension of the OLAP Attribute'
/

comment on column USER_CUBE_ATTRIBUTES.TARGET_DIMENSION_NAME is 'Name of Target Dimension of the OLAP Attribute'
/

comment on column USER_CUBE_ATTRIBUTES.ATTRIBUTE_ROLE is 'Special role this attribute plays (e.g. ShortDescription), or null if none'
/

comment on column USER_CUBE_ATTRIBUTES.DESCRIPTION is 'Long Description of the OLAP Attribute'
/

comment on column USER_CUBE_ATTRIBUTES.DATA_TYPE is 'Data Type of the OLAP Attribute'
/

comment on column USER_CUBE_ATTRIBUTES.DATA_LENGTH is 'Data Length of the OLAP Attribute'
/

comment on column USER_CUBE_ATTRIBUTES.DATA_PRECISION is 'Data Precision of the OLAP Attribute'
/

comment on column USER_CUBE_ATTRIBUTES.DATA_SCALE is 'Data Scale of the OLAP Attribute'
/

