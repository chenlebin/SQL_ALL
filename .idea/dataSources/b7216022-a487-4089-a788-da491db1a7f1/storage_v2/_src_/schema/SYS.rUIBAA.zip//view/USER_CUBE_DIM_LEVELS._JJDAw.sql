create view USER_CUBE_DIM_LEVELS (DIMENSION_NAME, LEVEL_NAME, DESCRIPTION) as
SELECT
  o.name DIMENSION_NAME,
  dl.level_name LEVEL_NAME,
  d.description_value DESCRIPTION
FROM
  obj$ o,
  olap_dim_levels$ dl,
  (select d.* from olap_descriptions$ d, nls_session_parameters n where
	n.parameter = 'NLS_LANGUAGE'
	and d.description_type = 'Description'
	and d.owning_object_type = 12 --DIM_LEVEL
	and (d.language = n.value
             or d.language like n.value || '\_%' escape '\')) d
WHERE
  o.obj#=dl.dim_obj# AND o.owner#=USERENV('SCHEMAID')
  AND d.owning_object_id(+)=dl.level_id
/

comment on table USER_CUBE_DIM_LEVELS is 'OLAP Dimension Levels owned by the user in the database'
/

comment on column USER_CUBE_DIM_LEVELS.DIMENSION_NAME is 'Name of the dimension which owns the OLAP Dimension Level'
/

comment on column USER_CUBE_DIM_LEVELS.LEVEL_NAME is 'Name of the OLAP Dimension Level'
/

comment on column USER_CUBE_DIM_LEVELS.DESCRIPTION is 'Long Description of the OLAP Dimension Level'
/

