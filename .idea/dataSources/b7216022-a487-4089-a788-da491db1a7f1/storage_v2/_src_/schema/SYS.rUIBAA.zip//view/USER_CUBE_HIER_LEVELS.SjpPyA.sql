create view USER_CUBE_HIER_LEVELS (DIMENSION_NAME, HIERARCHY_NAME, LEVEL_NAME, ORDER_NUM, DESCRIPTION) as
SELECT
  o.name DIMENSION_NAME,
  h.hierarchy_name HIERARCHY_NAME,
  dl.level_name LEVEL_NAME,
  hl.order_num ORDER_NUM,
  d.description_value DESCRIPTION
FROM
  olap_hier_levels$ hl,
  obj$ o,
  olap_hierarchies$ h,
  olap_dim_levels$ dl,
  (select d.* from olap_descriptions$ d, nls_session_parameters n where
	n.parameter = 'NLS_LANGUAGE'
	and d.description_type = 'Description'
	and d.owning_object_type = 14 --HIER_LEVEL
	and (d.language = n.value
             or d.language like n.value || '\_%' escape '\')) d
WHERE
  hl.hierarchy_id=h.hierarchy_id AND o.owner#=USERENV('SCHEMAID')
  AND dl.level_id=hl.dim_level_id AND o.obj#=dl.dim_obj#
  AND d.owning_object_id(+)=hl.hierarchy_level_id
/

comment on table USER_CUBE_HIER_LEVELS is 'OLAP Hierarchy Levels owned by the user in the database'
/

comment on column USER_CUBE_HIER_LEVELS.DIMENSION_NAME is 'Name of the owning Dimension of the OLAP Hierarchy Level'
/

comment on column USER_CUBE_HIER_LEVELS.HIERARCHY_NAME is 'Name of the owning Hierarchy of the OLAP Hierarchy Level'
/

comment on column USER_CUBE_HIER_LEVELS.LEVEL_NAME is 'Name of the OLAP Dimension Level'
/

comment on column USER_CUBE_HIER_LEVELS.ORDER_NUM is 'Order number of the OLAP Hierarchy Level within the hierarchy'
/

comment on column USER_CUBE_HIER_LEVELS.DESCRIPTION is 'Long Description of the OLAP Hierarchy Level'
/

