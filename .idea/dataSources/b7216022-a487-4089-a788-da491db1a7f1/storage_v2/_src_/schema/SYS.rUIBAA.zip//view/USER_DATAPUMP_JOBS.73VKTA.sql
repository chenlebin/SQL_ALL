create view USER_DATAPUMP_JOBS (JOB_NAME, OPERATION, JOB_MODE, STATE, DEGREE, ATTACHED_SESSIONS, DATAPUMP_SESSIONS) as
SELECT  j.job_name, j.operation, j.job_mode, j.state, j.workers,
                NVL((SELECT    COUNT(*)
                     FROM      SYS.GV$DATAPUMP_SESSION s
                     WHERE     j.job_id = s.job_id AND
                               s.type = 'DBMS_DATAPUMP'
                     GROUP BY  s.job_id), 0),
                NVL((SELECT    COUNT(*)
                     FROM      SYS.GV$DATAPUMP_SESSION s
                     WHERE     j.job_id = s.job_id
                     GROUP BY  s.job_id), 0)
        FROM    SYS.GV$DATAPUMP_JOB j
        WHERE   j.msg_ctrl_queue IS NOT NULL AND
                j.owner_name = SYS_CONTEXT('USERENV', 'CURRENT_USER')
      UNION ALL                               /* Not Running - Master Tables */
        SELECT o.name,
               SUBSTR (c.comment$, 24, 30), SUBSTR (c.comment$, 55, 30),
               'NOT RUNNING', 0, 0, 0
        FROM sys.obj$ o, sys.user$ u, sys.com$ c
        WHERE SUBSTR (c.comment$, 1, 22) = 'Data Pump Master Table' AND
              RTRIM (SUBSTR (c.comment$, 24, 30)) IN
                ('EXPORT','IMPORT','SQL_FILE') AND
              RTRIM (SUBSTR (c.comment$, 55, 30)) IN
                ('FULL','SCHEMA','TABLE','TABLESPACE','TRANSPORTABLE') AND
              o.obj# = c.obj# AND
              o.type# = 2 AND
              u.user# = o.owner# AND
              u.name = SYS_CONTEXT('USERENV', 'CURRENT_USER') AND
              NOT EXISTS (SELECT 1
                          FROM   SYS.GV$DATAPUMP_JOB
                          WHERE  owner_name = u.name AND
                                 job_name = o.name)
/

comment on table USER_DATAPUMP_JOBS is 'Datapump jobs for current user'
/

comment on column USER_DATAPUMP_JOBS.JOB_NAME is 'Job name'
/

comment on column USER_DATAPUMP_JOBS.OPERATION is 'Type of operation being performed'
/

comment on column USER_DATAPUMP_JOBS.JOB_MODE is 'Mode of operation being performed'
/

comment on column USER_DATAPUMP_JOBS.STATE is 'Current job state'
/

comment on column USER_DATAPUMP_JOBS.DEGREE is 'Number of worker processes performing the operation'
/

comment on column USER_DATAPUMP_JOBS.ATTACHED_SESSIONS is 'Number of sessions attached to the job'
/

comment on column USER_DATAPUMP_JOBS.DATAPUMP_SESSIONS is 'Number of Datapump sessions participating in the job'
/

