create view USER_DIM_CHILD_OF
            (OWNER, DIMENSION_NAME, HIERARCHY_NAME, POSITION, CHILD_LEVEL_NAME, JOIN_KEY_ID, PARENT_LEVEL_NAME) as
select d."OWNER",d."DIMENSION_NAME",d."HIERARCHY_NAME",d."POSITION",d."CHILD_LEVEL_NAME",d."JOIN_KEY_ID",d."PARENT_LEVEL_NAME" FROM dba_dim_child_of d, sys.user$ u
where u.user# = userenv('SCHEMAID')
  and d.owner = u.name
/

comment on table USER_DIM_CHILD_OF is 'Representaion of a 1:n hierarchical relationship between a pair of levels in
 a dimension'
/

comment on column USER_DIM_CHILD_OF.OWNER is 'Owner of the dimension'
/

comment on column USER_DIM_CHILD_OF.DIMENSION_NAME is 'Name of the dimension'
/

comment on column USER_DIM_CHILD_OF.HIERARCHY_NAME is 'Name of the hierarchy'
/

comment on column USER_DIM_CHILD_OF.POSITION is 'Hierarchical position within this hierarchy, position 1 being
 the most detailed'
/

comment on column USER_DIM_CHILD_OF.CHILD_LEVEL_NAME is 'Name of the child-side level of this 1:n relationship'
/

comment on column USER_DIM_CHILD_OF.JOIN_KEY_ID is 'Keys that join child to the parent'
/

comment on column USER_DIM_CHILD_OF.PARENT_LEVEL_NAME is 'Name of the parent-side level of this 1:n relationship'
/

