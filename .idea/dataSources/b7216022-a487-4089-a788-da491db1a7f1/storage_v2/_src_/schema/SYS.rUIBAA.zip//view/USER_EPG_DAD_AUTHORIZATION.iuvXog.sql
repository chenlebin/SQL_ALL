create view USER_EPG_DAD_AUTHORIZATION (DAD_NAME) as
select ea.dadname
from epg$_auth ea
where ea.user# = userenv('SCHEMAID')
/

comment on table USER_EPG_DAD_AUTHORIZATION is 'DADs authorized to use the user''s privileges'
/

comment on column USER_EPG_DAD_AUTHORIZATION.DAD_NAME is 'Name of DAD'
/

