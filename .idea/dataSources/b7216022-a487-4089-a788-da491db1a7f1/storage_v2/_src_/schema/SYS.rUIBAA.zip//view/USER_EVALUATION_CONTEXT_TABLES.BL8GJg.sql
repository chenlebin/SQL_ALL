create view USER_EVALUATION_CONTEXT_TABLES (EVALUATION_CONTEXT_NAME, TABLE_ALIAS, TABLE_NAME) as
SELECT o.name, ect.tab_alias, ect.tab_name
FROM   rec_tab$ ect, obj$ o
WHERE  ect.ec_obj# = o.obj# and o.owner# = USERENV('SCHEMAID')
/

comment on table USER_EVALUATION_CONTEXT_TABLES is 'tables in user rule evaluation contexts'
/

comment on column USER_EVALUATION_CONTEXT_TABLES.EVALUATION_CONTEXT_NAME is 'Name of the evaluation context'
/

comment on column USER_EVALUATION_CONTEXT_TABLES.TABLE_ALIAS is 'Alias of the table'
/

comment on column USER_EVALUATION_CONTEXT_TABLES.TABLE_NAME is 'Name of the table'
/

