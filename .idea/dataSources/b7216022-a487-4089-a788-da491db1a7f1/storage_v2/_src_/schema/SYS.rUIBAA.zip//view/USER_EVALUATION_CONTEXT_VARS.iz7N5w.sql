create view USER_EVALUATION_CONTEXT_VARS
            (EVALUATION_CONTEXT_NAME, VARIABLE_NAME, VARIABLE_TYPE, VARIABLE_VALUE_FUNCTION,
             VARIABLE_METHOD_FUNCTION) as
SELECT o.name, ecv.var_name, ecv.var_type, ecv.var_val_func, ecv.var_mthd_func
FROM   rec_var$ ecv, obj$ o
WHERE  ecv.ec_obj# = o.obj# and o.owner# = USERENV('SCHEMAID')
/

comment on table USER_EVALUATION_CONTEXT_VARS is 'variables in user rule evaluation contexts'
/

comment on column USER_EVALUATION_CONTEXT_VARS.EVALUATION_CONTEXT_NAME is 'Name of the evaluation context'
/

comment on column USER_EVALUATION_CONTEXT_VARS.VARIABLE_NAME is 'Name of the variable'
/

comment on column USER_EVALUATION_CONTEXT_VARS.VARIABLE_VALUE_FUNCTION is 'Function to provide variable value'
/

comment on column USER_EVALUATION_CONTEXT_VARS.VARIABLE_METHOD_FUNCTION is 'Function to provide variable method return value'
/

