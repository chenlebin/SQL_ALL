create view USER_FILE_GROUPS
            (FILE_GROUP_NAME, KEEP_FILES, MIN_VERSIONS, MAX_VERSIONS, RETENTION_DAYS, CREATED, COMMENTS,
             DEFAULT_DIRECTORY) as
select file_group_name, keep_files, min_versions,
       max_versions, retention_days, created, comments,
       default_directory
from "_USER_FILE_GROUPS"
/

comment on table USER_FILE_GROUPS is 'Details about file groups'
/

comment on column USER_FILE_GROUPS.FILE_GROUP_NAME is 'Name of the file group'
/

comment on column USER_FILE_GROUPS.KEEP_FILES is 'Should on-disk files be purged when removed?'
/

comment on column USER_FILE_GROUPS.MIN_VERSIONS is 'Minimum number of versions to keep'
/

comment on column USER_FILE_GROUPS.MAX_VERSIONS is 'Maximum number of versions to keep'
/

comment on column USER_FILE_GROUPS.RETENTION_DAYS is 'Keep versions at least this number of days'
/

comment on column USER_FILE_GROUPS.CREATED is 'When the file group was created'
/

comment on column USER_FILE_GROUPS.COMMENTS is 'User specified comment'
/

comment on column USER_FILE_GROUPS.DEFAULT_DIRECTORY is 'Default directory object'
/

