create view USER_FILE_GROUP_EXPORT_INFO
            (FILE_GROUP_NAME, VERSION_NAME, VERSION, EXPORT_VERSION, PLATFORM_NAME, EXPORT_TIME, EXPORT_SCN,
             SOURCE_GLOBAL_NAME) as
select g.file_group_name, v.version_name, v.version_id,
       i.export_version, i.export_platform, i.export_time, i.export_scn,
       i.source_db_name
from "_USER_FILE_GROUPS" g, sys.fgr$_file_group_export_info i,
     sys.fgr$_file_group_versions v
where i.version_guid = v.version_guid and v.file_group_id = g.file_group_id
/

comment on table USER_FILE_GROUP_EXPORT_INFO is 'Details about export information of file group versions'
/

comment on column USER_FILE_GROUP_EXPORT_INFO.FILE_GROUP_NAME is 'Name of the file group'
/

comment on column USER_FILE_GROUP_EXPORT_INFO.VERSION_NAME is 'Name of the version'
/

comment on column USER_FILE_GROUP_EXPORT_INFO.VERSION is 'Internal version number'
/

comment on column USER_FILE_GROUP_EXPORT_INFO.EXPORT_VERSION is 'Compatibility level of export dump'
/

comment on column USER_FILE_GROUP_EXPORT_INFO.PLATFORM_NAME is 'Platform export was done on'
/

comment on column USER_FILE_GROUP_EXPORT_INFO.EXPORT_TIME is 'Export job start time'
/

comment on column USER_FILE_GROUP_EXPORT_INFO.EXPORT_SCN is 'Export job scn'
/

comment on column USER_FILE_GROUP_EXPORT_INFO.SOURCE_GLOBAL_NAME is 'Global name of the exporting database'
/

