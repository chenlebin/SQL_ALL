create view USER_FILE_GROUP_VERSIONS
            (FILE_GROUP_NAME, VERSION_NAME, VERSION, CREATOR, CREATED, COMMENTS, DEFAULT_DIRECTORY) as
select g.file_group_name, v.version_name, v.version_id,
       v.creator, v.creation_time, v.user_comment, v.default_dir_obj
from "_USER_FILE_GROUPS" g, sys.fgr$_file_group_versions v
where g.file_group_id = v.file_group_id
/

comment on table USER_FILE_GROUP_VERSIONS is 'Details about file group versions'
/

comment on column USER_FILE_GROUP_VERSIONS.FILE_GROUP_NAME is 'Name of the file group'
/

comment on column USER_FILE_GROUP_VERSIONS.VERSION_NAME is 'Name of the version'
/

comment on column USER_FILE_GROUP_VERSIONS.VERSION is 'Internal version number'
/

comment on column USER_FILE_GROUP_VERSIONS.CREATOR is 'Creator of the version'
/

comment on column USER_FILE_GROUP_VERSIONS.CREATED is 'When the version was created'
/

comment on column USER_FILE_GROUP_VERSIONS.COMMENTS is 'User specified comment'
/

comment on column USER_FILE_GROUP_VERSIONS.DEFAULT_DIRECTORY is 'Default directory object'
/

