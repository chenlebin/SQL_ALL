create view USER_INTERNAL_TRIGGERS (TABLE_NAME, INTERNAL_TRIGGER_TYPE) as
select o.name, 'DEFERRED RPC QUEUE'
from sys.tab$ t, sys.obj$ o
where o.owner# = userenv('SCHEMAID')
      and t.obj# = o.obj#
      and bitand(t.trigflag,1) = 1
union
select o.name, 'MVIEW LOG'
from sys.tab$ t, sys.obj$ o
where o.owner# = userenv('SCHEMAID')
      and t.obj# = o.obj#
      and bitand(t.trigflag,2) = 2
union
select o.name, 'UPDATABLE MVIEW LOG'
from sys.tab$ t, sys.obj$ o
where o.owner# = userenv('SCHEMAID')
       and t.obj# = o.obj#
       and bitand(t.trigflag,4) = 4
union
select o.name, 'CONTEXT'
from sys.tab$ t, sys.obj$ o
where o.owner# = userenv('SCHEMAID')
      and t.obj# = o.obj#
      and bitand(t.trigflag,8) = 8
/

comment on table USER_INTERNAL_TRIGGERS is 'Description of the internal triggers on the user''s own tables'
/

comment on column USER_INTERNAL_TRIGGERS.TABLE_NAME is 'Name of the table'
/

comment on column USER_INTERNAL_TRIGGERS.INTERNAL_TRIGGER_TYPE is 'Type of internal trigger'
/

