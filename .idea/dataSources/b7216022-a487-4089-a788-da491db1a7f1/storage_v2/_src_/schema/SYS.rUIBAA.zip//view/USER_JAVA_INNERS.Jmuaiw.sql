create view USER_JAVA_INNERS
            (NAME, INNER_INDEX, SIMPLE_NAME, FULL_NAME, ACCESSIBILITY, IS_STATIC, IS_FINAL, IS_ABSTRACT,
             IS_INTERFACE) as
select /*+ ordered use_nl(o m) */
       nvl(j.longdbcs, o.name), m.nix, m.nsm, m.nln,
       decode(BITAND(m.oac, 7), 1, 'PUBLIC',
                                2, 'PRIVATE',
                                4, 'PROTECTED',
                                NULL),
       decode(BITAND(m.acc, 8), 8, 'YES',
                                0, 'NO'),
       decode(BITAND(m.acc, 16), 16, 'YES',
                                 0, 'NO'),
       decode(BITAND(m.acc, 1024), 1024, 'YES',
                                   0, 'NO'),
       decode(BITAND(m.acc, 512), 512, 'YES',
                                  0, 'NO')
from sys.javasnm$ j, sys.obj$ o, sys.x$joxmic m
where o.obj# = m.obn
  and o.type# = 29
  and o.owner# = userenv('SCHEMAID')
  and j.short(+) = o.name
/

comment on table USER_JAVA_INNERS is 'list of inner classes refered by the stored java class owned by user'
/

comment on column USER_JAVA_INNERS.NAME is 'name of the stored java class'
/

comment on column USER_JAVA_INNERS.INNER_INDEX is 'index of the refered inner class'
/

comment on column USER_JAVA_INNERS.SIMPLE_NAME is 'simple name of the refered inner class'
/

comment on column USER_JAVA_INNERS.FULL_NAME is 'full name of the refered inner class'
/

comment on column USER_JAVA_INNERS.IS_STATIC is 'is the refered inner class declared static in the sorce file'
/

comment on column USER_JAVA_INNERS.IS_FINAL is 'is the refered inner class declared final in the sorce file'
/

comment on column USER_JAVA_INNERS.IS_ABSTRACT is 'is the refered inner class declared abstract in the sorce file'
/

comment on column USER_JAVA_INNERS.IS_INTERFACE is 'is the refered inner class declared interface in the sorce file'
/

