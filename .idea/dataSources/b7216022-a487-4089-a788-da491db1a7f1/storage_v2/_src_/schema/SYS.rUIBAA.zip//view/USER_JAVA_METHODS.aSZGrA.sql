create view USER_JAVA_METHODS
            (NAME, METHOD_INDEX, METHOD_NAME, ACCESSIBILITY, IS_STATIC, IS_FINAL, IS_SYNCHRONIZED, IS_NATIVE,
             IS_ABSTRACT, IS_STRICT, ARGUMENTS, THROWS, ARRAY_DEPTH, BASE_TYPE, RETURN_CLASS, IS_COMPILED)
as
select /*+ ordered use_nl(o m) */
       nvl(j.longdbcs, o.name), m.mix, m.mnm,
       decode(BITAND(m.mac, 7), 1, 'PUBLIC',
                                2, 'PRIVATE',
                                4, 'PROTECTED',
                                NULL),
       decode(BITAND(m.mac, 8), 8, 'YES',
                                0, 'NO'),
       decode(BITAND(m.mac, 16), 16, 'YES',
                                 0, 'NO'),
       decode(BITAND(m.mac, 32), 32, 'YES',
                                 0, 'NO'),
       decode(BITAND(m.mac, 256), 256, 'YES',
                                  0, 'NO'),
       decode(BITAND(m.mac, 1024), 1024, 'YES',
                                   0, 'NO'),
       decode(BITAND(m.mac, 2048), 2048, 'YES',
                                   0, 'NO'),
       m.agc, m.exc, m.rad,
       decode(m.rbt, 10, 'int',
                     11, 'long',
                     6,  'float',
                     7,  'double',
                     4,  'boolean',
                     8,  'byte',
                     5,  'char',
                     9,  'short',
                     2,  'class',
                     12, 'void',
                     NULL),
       m.rln,
       nvl((select 'YES' from sys.java$mc$ j where
               j.method#=m.mmt and
               j.obj#=m.obn and
               rownum=1), 'NO')
from sys.javasnm$ j, sys.obj$ o, sys.x$joxmmd m
where o.obj# = m.obn
  and o.type# = 29
  and o.owner# = userenv('SCHEMAID')
  and j.short(+) = o.name
/

comment on table USER_JAVA_METHODS is 'method information of stored java class owned by the user'
/

comment on column USER_JAVA_METHODS.NAME is 'name of the java class'
/

comment on column USER_JAVA_METHODS.METHOD_INDEX is 'the index of the method'
/

comment on column USER_JAVA_METHODS.METHOD_NAME is 'the name of the field at METHOD_INDEX'
/

comment on column USER_JAVA_METHODS.ACCESSIBILITY is 'the accessiblity of the method, public/private/protected/null(i.e. package)'
/

comment on column USER_JAVA_METHODS.IS_STATIC is 'is the method a static method?'
/

comment on column USER_JAVA_METHODS.IS_FINAL is 'is the method a final method?'
/

comment on column USER_JAVA_METHODS.IS_SYNCHRONIZED is 'is the method a synchronized method?'
/

comment on column USER_JAVA_METHODS.IS_NATIVE is 'is the method a native method?'
/

comment on column USER_JAVA_METHODS.IS_ABSTRACT is 'is the method an abstract method?'
/

comment on column USER_JAVA_METHODS.IS_STRICT is 'is the method a strict method?'
/

comment on column USER_JAVA_METHODS.ARGUMENTS is 'number of arguments of the method'
/

comment on column USER_JAVA_METHODS.THROWS is 'number of exceptions thrown by the method'
/

comment on column USER_JAVA_METHODS.ARRAY_DEPTH is 'array depth of the return type of the method'
/

comment on column USER_JAVA_METHODS.BASE_TYPE is 'base type of the return type of the field'
/

comment on column USER_JAVA_METHODS.RETURN_CLASS is 'if base_type is class, this gives the actual class name of the return value'
/

