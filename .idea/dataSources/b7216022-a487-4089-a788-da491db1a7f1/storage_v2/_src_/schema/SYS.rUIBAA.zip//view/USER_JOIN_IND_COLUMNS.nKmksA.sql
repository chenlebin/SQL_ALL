create view USER_JOIN_IND_COLUMNS
            (INDEX_NAME, INNER_TABLE_OWNER, INNER_TABLE_NAME, INNER_TABLE_COLUMN, OUTER_TABLE_OWNER, OUTER_TABLE_NAME,
             OUTER_TABLE_COLUMN)
as
select
  oi.name,
  uti.name, oti.name, ci.name,
  uto.name, oto.name, co.name
from
  sys.user$ uti, sys.user$ uto,
  sys.obj$ oi, sys.obj$ oti, sys.obj$ oto,
  sys.col$ ci, sys.col$ co,
  sys.jijoin$ ji
where ji.obj# = oi.obj#
  and ji.tab1obj# = oti.obj#
  and oti.owner# = uti.user#
  and ci.obj# = oti.obj#
  and ji.tab1col# = ci.intcol#
  and ji.tab2obj# = oto.obj#
  and oto.owner# = uto.user#
  and co.obj# = oto.obj#
  and ji.tab2col# = co.intcol#
  and oi.owner# = userenv('SCHEMAID')
/

comment on table USER_JOIN_IND_COLUMNS is 'Join Index columns comprising the join conditions'
/

comment on column USER_JOIN_IND_COLUMNS.INDEX_NAME is 'Index name'
/

comment on column USER_JOIN_IND_COLUMNS.INNER_TABLE_OWNER is 'Table owner of inner table (table closer to the fact table)'
/

comment on column USER_JOIN_IND_COLUMNS.INNER_TABLE_NAME is 'Table name of inner table (table closer to the fact table)'
/

comment on column USER_JOIN_IND_COLUMNS.INNER_TABLE_COLUMN is 'Column name of inner table (table closer to the fact table)'
/

comment on column USER_JOIN_IND_COLUMNS.OUTER_TABLE_OWNER is 'Table owner of outer table (table closer to the fact table)'
/

comment on column USER_JOIN_IND_COLUMNS.OUTER_TABLE_NAME is 'Table name of outer table (table closer to the fact table)'
/

comment on column USER_JOIN_IND_COLUMNS.OUTER_TABLE_COLUMN is 'Column name of outer table (table closer to the fact table)'
/

