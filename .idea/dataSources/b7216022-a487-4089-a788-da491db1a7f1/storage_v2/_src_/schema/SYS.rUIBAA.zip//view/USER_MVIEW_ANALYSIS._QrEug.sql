create view USER_MVIEW_ANALYSIS
            (OWNER, MVIEW_NAME, MVIEW_TABLE_OWNER, CONTAINER_NAME, LAST_REFRESH_SCN, LAST_REFRESH_DATE, REFRESH_METHOD,
             SUMMARY, FULLREFRESHTIM, INCREFRESHTIM, CONTAINS_VIEWS, UNUSABLE, RESTRICTED_SYNTAX, INC_REFRESHABLE,
             KNOWN_STALE, INVALID, REWRITE_ENABLED, QUERY_LEN, QUERY, REVISION)
as
select u.name, o.name, u.name, s.containernam,
       s.lastrefreshscn, s.lastrefreshdate,
       decode (s.refreshmode, 0, 'NEVER', 1, 'FORCE', 2, 'FAST', 3,'COMPLETE'),
       decode(bitand(s.pflags, 25165824), 25165824, 'N', 'Y'),
       s.fullrefreshtim, s.increfreshtim,
       decode(bitand(s.pflags, 48), 0, 'N', 'Y'),
       decode(bitand(s.mflags, 64), 0, 'N', 'Y'), /* QSMQSUM_UNUSABLE */
       decode(bitand(s.pflags, 1294319), 0, 'Y', 'N'),
       decode(bitand((select n.flag2 from sys.snap$ n
                      where n.vname=s.containernam and n.sowner=u.name), 67108864),
                     67108864,  /* primary CUBE mv? */
                     decode(bitand((select n2.flag from sys.snap$ n2
                            where n2.parent_sowner=u.name and n2.parent_vname=s.containernam), 256),
                            256, 'N', 'Y'), /* Its child mv's properties determin INC_REFRESHABLE */
                     decode(bitand(s.pflags, 236879743), 0, 'Y', 'N')),
       decode(bitand(s.mflags, 1), 0, 'N', 'Y'), /* QSMQSUM_KNOWNSTL */
       decode(o.status, 5, 'Y', 'N'),
       decode(bitand(s.mflags, 4), 0, 'Y', 'N'), /* QSMQSUM_DISABLED */
       s.sumtextlen,s.sumtext,
       s.metaversion/* Metadata revision number */
from sys.user$ u, sys.sum$ s, sys.obj$ o
where o.owner# = u.user#
  and o.obj# = s.obj#
  and o.owner# = userenv('SCHEMAID')
  and bitand(s.xpflags, 8388608) = 0 /* NOT REWRITE EQUIVALENCE SUMMARY */
/

comment on table USER_MVIEW_ANALYSIS is 'Description of the materialized views created by the user'
/

comment on column USER_MVIEW_ANALYSIS.OWNER is 'Owner of the materialized view'
/

comment on column USER_MVIEW_ANALYSIS.MVIEW_NAME is 'Name of the materialized view'
/

comment on column USER_MVIEW_ANALYSIS.MVIEW_TABLE_OWNER is 'Owner of the container table'
/

comment on column USER_MVIEW_ANALYSIS.CONTAINER_NAME is 'Name of the container table for this materialized view'
/

comment on column USER_MVIEW_ANALYSIS.LAST_REFRESH_SCN is 'The SCN of the last transaction to refresh the materialized view'
/

comment on column USER_MVIEW_ANALYSIS.LAST_REFRESH_DATE is 'The date of the last refresh of the materialized view'
/

comment on column USER_MVIEW_ANALYSIS.REFRESH_METHOD is 'User declared method of refresh for the materialized view'
/

comment on column USER_MVIEW_ANALYSIS.FULLREFRESHTIM is 'The time that it took to fully refresh the materialized view'
/

comment on column USER_MVIEW_ANALYSIS.INCREFRESHTIM is 'The time that it took to incrementally refresh the materialized view'
/

comment on column USER_MVIEW_ANALYSIS.CONTAINS_VIEWS is 'This materialized view contains views in the FROM clause'
/

comment on column USER_MVIEW_ANALYSIS.UNUSABLE is 'This materialized view is unusable, the build was deferred'
/

comment on column USER_MVIEW_ANALYSIS.RESTRICTED_SYNTAX is 'This materialized view contains restrictive syntax'
/

comment on column USER_MVIEW_ANALYSIS.INC_REFRESHABLE is 'This materialized view is not restricted from being incrementally refreshed'
/

comment on column USER_MVIEW_ANALYSIS.KNOWN_STALE is 'This materialized view is directly stale'
/

comment on column USER_MVIEW_ANALYSIS.INVALID is 'Invalidity of the materialized view, Y = INVALID, N = VALID'
/

comment on column USER_MVIEW_ANALYSIS.REWRITE_ENABLED is 'This materialized view is enabled for query rewrite'
/

comment on column USER_MVIEW_ANALYSIS.QUERY_LEN is 'The length (in bytes) of the query field'
/

comment on column USER_MVIEW_ANALYSIS.QUERY is 'SELECT expression of the materialized view definition'
/

comment on column USER_MVIEW_ANALYSIS.REVISION is 'Reserved for internal use'
/

