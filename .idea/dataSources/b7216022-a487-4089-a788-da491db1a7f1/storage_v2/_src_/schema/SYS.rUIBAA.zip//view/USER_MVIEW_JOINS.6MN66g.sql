create view USER_MVIEW_JOINS
            (OWNER, MVIEW_NAME, DETAILOBJ1_OWNER, DETAILOBJ1_RELATION, DETAILOBJ1_COLUMN, OPERATOR, OPERATOR_TYPE,
             DETAILOBJ2_OWNER, DETAILOBJ2_RELATION, DETAILOBJ2_COLUMN)
as
select u.name, o.name,
       u1.name, o1.name, c1.name, '=',
       decode(sj.flags, 0, 'I', 1, 'L', 2, 'R'),
       u2.name, o2.name, c2.name
from sys.sumjoin$ sj, sys.obj$ o, sys.user$ u,
     sys.obj$ o1, sys.user$ u1, sys.col$ c1,
     sys.obj$ o2, sys.user$ u2, sys.col$ c2,
     sys.sum$ s
where sj.sumobj# = o.obj#
  AND o.owner# = u.user#
  AND sj.tab1obj# = o1.obj#
  AND o1.owner# = u1.user#
  AND sj.tab1obj# = c1.obj#
  AND sj.tab1col# = c1.intcol#
  AND sj.tab2obj# = o2.obj#
  AND o2.owner# = u2.user#
  AND sj.tab2obj# = c2.obj#
  AND sj.tab2col# = c2.intcol#
  AND o.owner# = userenv('SCHEMAID')
  AND s.obj# = sj.sumobj#
  AND bitand(s.xpflags, 8388608) = 0 /* NOT REWRITE EQUIVALENCE SUMMARY */
/

comment on table USER_MVIEW_JOINS is 'Description of a join between two columns in the
WHERE clause of a materialized view created by the user'
/

comment on column USER_MVIEW_JOINS.OWNER is 'Owner of the materialized view'
/

comment on column USER_MVIEW_JOINS.MVIEW_NAME is 'Name of the materialized view'
/

comment on column USER_MVIEW_JOINS.DETAILOBJ1_OWNER is 'Owner of the 1st detail object'
/

comment on column USER_MVIEW_JOINS.DETAILOBJ1_RELATION is 'Name of the 1st detail object'
/

comment on column USER_MVIEW_JOINS.DETAILOBJ1_COLUMN is 'Name of the 1st detail object column'
/

comment on column USER_MVIEW_JOINS.OPERATOR is 'Name of the join operator. Currently only = is defined'
/

comment on column USER_MVIEW_JOINS.DETAILOBJ2_OWNER is 'Owner of the 2nd detail object'
/

comment on column USER_MVIEW_JOINS.DETAILOBJ2_RELATION is 'Name of the 2nd detail object'
/

comment on column USER_MVIEW_JOINS.DETAILOBJ2_COLUMN is 'Name of the 2nd detail object column'
/

