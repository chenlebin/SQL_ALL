create view USER_MVIEW_LOGS
            (LOG_OWNER, MASTER, LOG_TABLE, LOG_TRIGGER, ROWIDS, PRIMARY_KEY, OBJECT_ID, FILTER_COLUMNS, SEQUENCE,
             INCLUDE_NEW_VALUES, PURGE_ASYNCHRONOUS, PURGE_DEFERRED, PURGE_START, PURGE_INTERVAL, LAST_PURGE_DATE,
             LAST_PURGE_STATUS, NUM_ROWS_PURGED, COMMIT_SCN_BASED)
as
select s."LOG_OWNER",s."MASTER",s."LOG_TABLE",s."LOG_TRIGGER",s."ROWIDS",s."PRIMARY_KEY",s."OBJECT_ID",s."FILTER_COLUMNS",s."SEQUENCE",s."INCLUDE_NEW_VALUES",s."PURGE_ASYNCHRONOUS",s."PURGE_DEFERRED",s."PURGE_START",s."PURGE_INTERVAL",s."LAST_PURGE_DATE",s."LAST_PURGE_STATUS",s."NUM_ROWS_PURGED",s."COMMIT_SCN_BASED" from dba_mview_logs s, sys.user$ u
where s.log_owner = u.name
  and u.user# = userenv('SCHEMAID')
/

comment on table USER_MVIEW_LOGS is 'All materialized view logs owned by the user'
/

comment on column USER_MVIEW_LOGS.LOG_OWNER is 'Owner of the materialized view log'
/

comment on column USER_MVIEW_LOGS.MASTER is 'Name of the master table which changes are logged'
/

comment on column USER_MVIEW_LOGS.LOG_TABLE is 'Log table; with rowids and timestamps of rows which changed in the
master'
/

comment on column USER_MVIEW_LOGS.LOG_TRIGGER is 'Trigger on master table; fills the materialized view log'
/

comment on column USER_MVIEW_LOGS.ROWIDS is 'If YES, the materialized view log records rowid information'
/

comment on column USER_MVIEW_LOGS.PRIMARY_KEY is 'If YES, the materialized view log records primary key information'
/

comment on column USER_MVIEW_LOGS.OBJECT_ID is 'If YES, the materialized view log records object id information'
/

comment on column USER_MVIEW_LOGS.FILTER_COLUMNS is 'If YES, the materialized view log records filter column information'
/

comment on column USER_MVIEW_LOGS.SEQUENCE is 'If YES, the materialized view log records sequence information'
/

comment on column USER_MVIEW_LOGS.INCLUDE_NEW_VALUES is 'If YES, the materialized view log records old and new values (else only old values)'
/

comment on column USER_MVIEW_LOGS.PURGE_ASYNCHRONOUS is 'If YES, the materialized view log is purged asynchronously'
/

comment on column USER_MVIEW_LOGS.PURGE_DEFERRED is 'If YES, the materialized view log is purged in a deferred manner'
/

comment on column USER_MVIEW_LOGS.PURGE_START is 'For deferred purge, the purge start date'
/

comment on column USER_MVIEW_LOGS.PURGE_INTERVAL is 'For deferred purge, the purge interval'
/

comment on column USER_MVIEW_LOGS.LAST_PURGE_DATE is 'Date of the last purge'
/

comment on column USER_MVIEW_LOGS.LAST_PURGE_STATUS is 'Status of the last purge: error code or 0 for success'
/

comment on column USER_MVIEW_LOGS.NUM_ROWS_PURGED is 'Number of rows purged in the last purge'
/

comment on column USER_MVIEW_LOGS.COMMIT_SCN_BASED is 'If YES, the materialized view log is commit SCN-based'
/

