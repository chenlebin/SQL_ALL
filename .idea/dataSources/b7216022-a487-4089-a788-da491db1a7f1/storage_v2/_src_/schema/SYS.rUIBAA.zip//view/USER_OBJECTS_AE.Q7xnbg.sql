create view USER_OBJECTS_AE
            (OBJECT_NAME, SUBOBJECT_NAME, OBJECT_ID, DATA_OBJECT_ID, OBJECT_TYPE, CREATED, LAST_DDL_TIME, TIMESTAMP,
             STATUS, TEMPORARY, GENERATED, SECONDARY, NAMESPACE, EDITION_NAME)
as
select o.name, o.subname, o.obj#, o.dataobj#,
       decode(o.type#, 0, 'NEXT OBJECT', 1, 'INDEX', 2, 'TABLE', 3, 'CLUSTER',
                      4, 'VIEW', 5, 'SYNONYM', 6, 'SEQUENCE',
                      7, 'PROCEDURE', 8, 'FUNCTION', 9, 'PACKAGE', 10, 'NON-EXISTENT',
                      11, 'PACKAGE BODY', 12, 'TRIGGER',
                      13, 'TYPE', 14, 'TYPE BODY',
                      19, 'TABLE PARTITION', 20, 'INDEX PARTITION', 21, 'LOB',
                      22, 'LIBRARY', 23, 'DIRECTORY',  24, 'QUEUE',
                      28, 'JAVA SOURCE', 29, 'JAVA CLASS', 30, 'JAVA RESOURCE',
                      32, 'INDEXTYPE', 33, 'OPERATOR',
                      34, 'TABLE SUBPARTITION', 35, 'INDEX SUBPARTITION',
                      40, 'LOB PARTITION', 41, 'LOB SUBPARTITION',
                      42, NVL((SELECT 'REWRITE EQUIVALENCE'
                               FROM sum$ s
                               WHERE s.obj#=o.obj#
                                     and bitand(s.xpflags, 8388608) = 8388608),
                              'MATERIALIZED VIEW'),
                      43, 'DIMENSION',
                      44, 'CONTEXT', 46, 'RULE SET', 47, 'RESOURCE PLAN',
                      48, 'CONSUMER GROUP',
                      51, 'SUBSCRIPTION', 52, 'LOCATION',
                      55, 'XML SCHEMA', 56, 'JAVA DATA',
                      57, 'EDITION', 59, 'RULE',
                      60, 'CAPTURE', 61, 'APPLY',
                      62, 'EVALUATION CONTEXT',
                      66, 'JOB', 67, 'PROGRAM', 68, 'JOB CLASS', 69, 'WINDOW',
                      72, 'WINDOW GROUP', 74, 'SCHEDULE', 79, 'CHAIN',
                      81, 'FILE GROUP', 82, 'MINING MODEL',  87, 'ASSEMBLY',
                      90, 'CREDENTIAL', 92, 'CUBE DIMENSION', 93, 'CUBE',
                      94, 'MEASURE FOLDER', 95, 'CUBE BUILD PROCESS',
                      'UNDEFINED'),
       o.ctime, o.mtime,
       to_char(o.stime, 'YYYY-MM-DD:HH24:MI:SS'),
       decode(o.status, 0, 'N/A', 1, 'VALID', 'INVALID'),
       decode(bitand(o.flags, 2), 0, 'N', 2, 'Y', 'N'),
       decode(bitand(o.flags, 4), 0, 'N', 4, 'Y', 'N'),
       decode(bitand(o.flags, 16), 0, 'N', 16, 'Y', 'N'),
       o.namespace,
       o.defining_edition
from sys."_ACTUAL_EDITION_OBJ" o
where o.owner# = userenv('SCHEMAID')
  and o.linkname is null
  and (o.type# != 1  /* INDEX - handled below */
       or
       (o.type# = 1 and 1 = (select 1
                             from sys.ind$ i
                            where i.obj# = o.obj#
                              and i.type# in (1, 2, 3, 4, 6, 7, 9))))
  and o.name != '_NEXT_OBJECT'
  and o.name != '_default_auditing_options_'
  and bitand(o.flags, 128) = 0
union all
select l.name, NULL, to_number(null), to_number(null),
       'DATABASE LINK',
       l.ctime, to_date(null), NULL, 'VALID', 'N', 'N', 'N', NULL, NULL
from sys.link$ l
where l.owner# = userenv('SCHEMAID')
/

comment on table USER_OBJECTS_AE is 'Objects owned by the user'
/

comment on column USER_OBJECTS_AE.OBJECT_NAME is 'Name of the object'
/

comment on column USER_OBJECTS_AE.SUBOBJECT_NAME is 'Name of the sub-object (for example, partititon)'
/

comment on column USER_OBJECTS_AE.OBJECT_ID is 'Object number of the object'
/

comment on column USER_OBJECTS_AE.DATA_OBJECT_ID is 'Object number of the segment which contains the object'
/

comment on column USER_OBJECTS_AE.OBJECT_TYPE is 'Type of the object'
/

comment on column USER_OBJECTS_AE.CREATED is 'Timestamp for the creation of the object'
/

comment on column USER_OBJECTS_AE.LAST_DDL_TIME is 'Timestamp for the last DDL change (including GRANT and REVOKE) to the object'
/

comment on column USER_OBJECTS_AE.TIMESTAMP is 'Timestamp for the specification of the object'
/

comment on column USER_OBJECTS_AE.STATUS is 'Status of the object'
/

comment on column USER_OBJECTS_AE.TEMPORARY is 'Can the current session only see data that it place in this object itself?'
/

comment on column USER_OBJECTS_AE.GENERATED is 'Was the name of this object system generated?'
/

comment on column USER_OBJECTS_AE.SECONDARY is 'Is this a secondary object created as part of icreate for domain indexes?'
/

comment on column USER_OBJECTS_AE.NAMESPACE is 'Namespace for the object'
/

comment on column USER_OBJECTS_AE.EDITION_NAME is 'Name of the edition in which the object is actual'
/

