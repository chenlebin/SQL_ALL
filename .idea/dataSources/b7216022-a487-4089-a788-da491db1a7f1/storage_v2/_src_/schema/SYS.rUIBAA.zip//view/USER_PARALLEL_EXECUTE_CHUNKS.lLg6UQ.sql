create view USER_PARALLEL_EXECUTE_CHUNKS
            (CHUNK_ID, TASK_NAME, STATUS, START_ROWID, END_ROWID, START_ID, END_ID, JOB_NAME, START_TS, END_TS,
             ERROR_CODE, ERROR_MESSAGE)
as
select CHUNK_ID,
       TASK_NAME,
       decode( status, 0, 'UNASSIGNED',
                       1, 'ASSIGNED',
                       2, 'PROCESSED',
                       3, 'PROCESSED_WITH_ERROR' ),
       START_ROWID,
       END_ROWID,
       START_ID,
       END_ID,
       JOB_NAME,
       START_TS,
       END_TS,
       ERROR_CODE,
       ERROR_MESSAGE
from DBMS_PARALLEL_EXECUTE_CHUNKS$ c
where task_owner# = userenv('SCHEMAID')
/

