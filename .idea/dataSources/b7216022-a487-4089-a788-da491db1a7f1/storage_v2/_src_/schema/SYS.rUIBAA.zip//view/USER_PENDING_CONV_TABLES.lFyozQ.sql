create view USER_PENDING_CONV_TABLES (TABLE_NAME) as
select o.name
from sys.obj$ o
  where o.type# = 2 and o.status = 5
  and bitand(o.flags, 4096) = 4096  /* type evolved flg */
  and o.owner# = userenv('SCHEMAID')
/

comment on table USER_PENDING_CONV_TABLES is 'All user''s tables which are not upgraded to the latest type version'
/

comment on column USER_PENDING_CONV_TABLES.TABLE_NAME is 'Name of the table'
/

