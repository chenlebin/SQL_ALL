create view USER_QUEUE_SUBSCRIBERS
            (QUEUE_NAME, QUEUE_TABLE, CONSUMER_NAME, ADDRESS, PROTOCOL, TRANSFORMATION, RULE, DELIVERY_MODE, NONDURABLE,
             QUEUE_TO_QUEUE)
as
select q.name QUEUE_NAME, t.name QUEUE_TABLE,
       s.name CONSUMER_NAME, s.address ADDRESS, s.protocol PROTOCOL,
       s.trans_name TRANSFORMATION, r.rule_condition RULE,
       decode(bitand(s.sub_type, 192), 64, 'PERSISTENT',
                                       128, 'BUFFERED',
                                       192, 'PERSISTENT_OR_BUFFERED',
                                       'NONE') DELIVERY_MODE,
       decode(bitand(s.sub_type, 32960), 32960, 'YES       ','NO        ')
                                       NONDURABLE,
       decode(bitand(s.sub_type, 512), 512, 'TRUE', 'FALSE') QUEUE_TO_QUEUE
FROM   system.aq$_queues q, system.aq$_queue_tables t, sys.user$ cu,
        sys.user_rules r,
       TABLE(aq$_get_subscribers(cu.name, q.name, t.name,
                                 cu.name, q.eventid, t.flags)) s
where cu.user# = userenv('SCHEMAID')
and   cu.name  = t.schema
and   q.table_objno = t.objno
and   bitand(t.flags, 1) = 1 and q.usage!=1
and   s.rule_name = r.rule_name(+)
/

comment on table USER_QUEUE_SUBSCRIBERS is 'queue subscribers under a user''schema'
/

comment on column USER_QUEUE_SUBSCRIBERS.QUEUE_NAME is 'name of the queue'
/

comment on column USER_QUEUE_SUBSCRIBERS.QUEUE_TABLE is 'name of the queue table'
/

comment on column USER_QUEUE_SUBSCRIBERS.CONSUMER_NAME is 'name of the subscriber'
/

comment on column USER_QUEUE_SUBSCRIBERS.ADDRESS is 'address of the subscriber'
/

comment on column USER_QUEUE_SUBSCRIBERS.PROTOCOL is 'protocol of the subscriber'
/

comment on column USER_QUEUE_SUBSCRIBERS.TRANSFORMATION is 'transformation for the subscriber'
/

comment on column USER_QUEUE_SUBSCRIBERS.RULE is 'rule condition for the subscriber'
/

comment on column USER_QUEUE_SUBSCRIBERS.DELIVERY_MODE is 'message delivery mode for the subscriber'
/

comment on column USER_QUEUE_SUBSCRIBERS.QUEUE_TO_QUEUE is 'whether the subscriber is a queue to queue subscriber'
/

