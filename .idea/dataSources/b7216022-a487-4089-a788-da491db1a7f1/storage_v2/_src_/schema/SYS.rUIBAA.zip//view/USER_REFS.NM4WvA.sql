create view USER_REFS
            (TABLE_NAME, COLUMN_NAME, WITH_ROWID, IS_SCOPED, SCOPE_TABLE_OWNER, SCOPE_TABLE_NAME, OBJECT_ID_TYPE) as
select distinct o.name,
       decode(bitand(c.property, 1), 1, ac.name, c.name),
       decode(bitand(rc.reftyp, 2), 2, 'YES', 'NO'),
       decode(bitand(rc.reftyp, 1), 1, 'YES', 'NO'),
       su.name, so.name,
       case
         when bitand(reftyp,4) = 4 then 'USER-DEFINED'
         when bitand(reftyp, 8) = 8 then 'SYSTEM GENERATED AND USER-DEFINED'
         else 'SYSTEM GENERATED'
       end
from sys.obj$ o, sys.col$ c, sys.refcon$ rc, sys.obj$ so, sys.user$ su,
     sys.attrcol$ ac
where o.owner# = userenv('SCHEMAID')
  and o.obj# = c.obj#
  and c.obj# = rc.obj#
  and c.col# = rc.col#
  and c.intcol# = rc.intcol#
  and rc.stabid = so.oid$(+)
  and so.owner# = su.user#(+)
  and c.obj# = ac.obj#(+)
  and c.intcol# = ac.intcol#(+)
  and bitand(c.property,32768) != 32768           /* not unused column */
/

comment on table USER_REFS is 'Description of the user''s own REF columns contained in the user''s own tables'
/

comment on column USER_REFS.TABLE_NAME is 'Name of the table containing the REF column'
/

comment on column USER_REFS.COLUMN_NAME is 'Column name or attribute of object column'
/

comment on column USER_REFS.WITH_ROWID is 'Is the REF value stored with the rowid?'
/

comment on column USER_REFS.IS_SCOPED is 'Is the REF column scoped?'
/

comment on column USER_REFS.SCOPE_TABLE_OWNER is 'Owner of the scope table, if it exists'
/

comment on column USER_REFS.SCOPE_TABLE_NAME is 'Name of the scope table, if it exists'
/

comment on column USER_REFS.OBJECT_ID_TYPE is 'If ref contains user-defined OID, then USER-DEFINED, else if it contains system generated OID, then SYSTEM GENERATED'
/

