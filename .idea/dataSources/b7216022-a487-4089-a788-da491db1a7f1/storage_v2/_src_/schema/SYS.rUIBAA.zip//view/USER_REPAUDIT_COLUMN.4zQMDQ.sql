create view USER_REPAUDIT_COLUMN
            (ONAME, COLUMN_NAME, BASE_SNAME, BASE_ONAME, BASE_CONFLICT_TYPE, BASE_REFERENCE_NAME, ATTRIBUTE) as
select
    r.oname,
    r.column_name,
    r.base_sname,
    r.base_oname,
    decode(r.base_conflict_type_id,
           1, 'UPDATE',
           2, 'UNIQUENESS',
           3, 'DELETE',
           'UNDEFINED'),
    r.base_reference_name,
    r.attribute
from  system.repcat$_audit_column r, sys.user$ u
where r.sname = u.name
and   u.user# = userenv('SCHEMAID')
/

comment on table USER_REPAUDIT_COLUMN is 'Information about columns in all shadow tables for user''s replicated tables'
/

comment on column USER_REPAUDIT_COLUMN.ONAME is 'Name of the shadow table'
/

comment on column USER_REPAUDIT_COLUMN.COLUMN_NAME is 'Name of the column in the shadow table'
/

comment on column USER_REPAUDIT_COLUMN.BASE_SNAME is 'Owner of replicated table'
/

comment on column USER_REPAUDIT_COLUMN.BASE_ONAME is 'Name of the replicated table'
/

comment on column USER_REPAUDIT_COLUMN.BASE_CONFLICT_TYPE is 'Type of conflict'
/

comment on column USER_REPAUDIT_COLUMN.BASE_REFERENCE_NAME is 'Table name, unique constraint name, or column group name'
/

comment on column USER_REPAUDIT_COLUMN.ATTRIBUTE is 'Description of the attribute'
/

