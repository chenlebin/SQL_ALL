create view USER_REPOBJECT
            (SNAME, ONAME, TYPE, STATUS, GENERATION_STATUS, ID, OBJECT_COMMENT, GNAME, MIN_COMMUNICATION,
             REPLICATION_TRIGGER_EXISTS, INTERNAL_PACKAGE_EXISTS, GROUP_OWNER, NESTED_TABLE)
as
select r.sname, r.oname, r.type, r.status, r.generation_status, r.id,
       r.object_comment, r.gname, r.min_communication, r.trigflag,
       r.internal_package_exists, r.gowner, r.nested_table
from repcat_repobject r, user_users u
where r.sname = u.username
  and r.type != 'INTERNAL PACKAGE'
/

comment on table USER_REPOBJECT is 'Replication information about the current user''s objects'
/

comment on column USER_REPOBJECT.SNAME is 'Name of the user'
/

comment on column USER_REPOBJECT.ONAME is 'Name of the object'
/

comment on column USER_REPOBJECT.TYPE is 'Type of the object'
/

comment on column USER_REPOBJECT.STATUS is 'Status of the last create or alter request on the local object'
/

comment on column USER_REPOBJECT.GENERATION_STATUS is 'Status of whether the object needs to generate replication packages'
/

comment on column USER_REPOBJECT.ID is 'Identifier of the local object'
/

comment on column USER_REPOBJECT.OBJECT_COMMENT is 'User description of the replicated object'
/

comment on column USER_REPOBJECT.GNAME is 'Name of the replicated objects group'
/

comment on column USER_REPOBJECT.MIN_COMMUNICATION is 'Send only necessary OLD and NEW values for an updated row?'
/

comment on column USER_REPOBJECT.REPLICATION_TRIGGER_EXISTS is 'Inline trigger flag exists?'
/

comment on column USER_REPOBJECT.INTERNAL_PACKAGE_EXISTS is 'Internal package exists?'
/

comment on column USER_REPOBJECT.GROUP_OWNER is 'Owner of the replicated objects group'
/

comment on column USER_REPOBJECT.NESTED_TABLE is 'Storage table for a nested table column?'
/

