create view USER_REPPRIORITY_GROUP (PRIORITY_GROUP, DATA_TYPE, FIXED_DATA_LENGTH, PRIORITY_COMMENT) as
select
    r.priority_group,
    decode(r.data_type_id,
           1, 'NUMBER',
           2, 'VARCHAR2',
           3, 'DATE',
           4, 'CHAR',
           5, 'RAW',
           6, 'NVARCHAR2',
           7, 'NCHAR',
           'UNDEFINED'),
    r.fixed_data_length,
    r.priority_comment
from  system.repcat$_priority_group r, sys.user$ u
where r.sname = u.name
and   u.user# = userenv('SCHEMAID')
/

comment on table USER_REPPRIORITY_GROUP is 'Information about user''s priority groups'
/

comment on column USER_REPPRIORITY_GROUP.PRIORITY_GROUP is 'Name of the priority group'
/

comment on column USER_REPPRIORITY_GROUP.DATA_TYPE is 'Datatype of the value'
/

comment on column USER_REPPRIORITY_GROUP.FIXED_DATA_LENGTH is 'Length of the value in bytes if the datatype is CHAR'
/

comment on column USER_REPPRIORITY_GROUP.PRIORITY_COMMENT is 'Description of the priority group'
/

