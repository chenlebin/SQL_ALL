create view USER_REPRESOLUTION
            (ONAME, CONFLICT_TYPE, REFERENCE_NAME, SEQUENCE_NO, METHOD_NAME, FUNCTION_NAME, PRIORITY_GROUP,
             RESOLUTION_COMMENT) as
select
    r.oname,
    decode(r.conflict_type_id,
           1, 'UPDATE',
           2, 'UNIQUENESS',
           3, 'DELETE',
           'UNDEFINED'),
    r.reference_name,
    r.sequence_no,
    r.method_name,
    r.function_name,
    r.priority_group,
    r.resolution_comment
from  system.repcat$_resolution r, sys.user$ u
where r.sname = u.name
and   u.user# = userenv('SCHEMAID')
/

comment on table USER_REPRESOLUTION is 'Description of all conflict resolutions for user''s replicated tables'
/

comment on column USER_REPRESOLUTION.ONAME is 'Name of the replicated object'
/

comment on column USER_REPRESOLUTION.CONFLICT_TYPE is 'Type of conflict'
/

comment on column USER_REPRESOLUTION.REFERENCE_NAME is 'Table name, unique constraint name, or column group name'
/

comment on column USER_REPRESOLUTION.SEQUENCE_NO is 'Ordering on resolution'
/

comment on column USER_REPRESOLUTION.METHOD_NAME is 'Name of the conflict resolution method'
/

comment on column USER_REPRESOLUTION.FUNCTION_NAME is 'Name of the resolution function'
/

comment on column USER_REPRESOLUTION.PRIORITY_GROUP is 'Name of the priority group used in conflict resolution'
/

comment on column USER_REPRESOLUTION.RESOLUTION_COMMENT is 'Description of the conflict resolution'
/

