create view USER_REPSITES (GNAME, DBLINK, MASTERDEF, SNAPMASTER, MASTER_COMMENT, MASTER, GROUP_OWNER) as
select r.sname, r.dblink, r.masterdef, r.snapmaster, r.master_comment,
       r.master, r.gowner
from repcat_repschema r, user_users u
where (r.sname = u.username)
   or r.gowner in
      (select name from user$
        where user# = userenv('SCHEMAID') and type# = 1)
/

comment on table USER_REPSITES is 'N-way replication information about the current user'
/

comment on column USER_REPSITES.GNAME is 'Name of the replicated object group'
/

comment on column USER_REPSITES.DBLINK is 'A database site replicating the schema'
/

comment on column USER_REPSITES.MASTERDEF is 'Is the database the master definition site for the replicated object group'
/

comment on column USER_REPSITES.SNAPMASTER is 'For snapshot sites, is the database the current refresh master'
/

comment on column USER_REPSITES.MASTER_COMMENT is 'User description of the database site'
/

comment on column USER_REPSITES.MASTER is 'Redundant information from user_repcat.master'
/

comment on column USER_REPSITES.GROUP_OWNER is 'Owner of the replicated object group'
/

