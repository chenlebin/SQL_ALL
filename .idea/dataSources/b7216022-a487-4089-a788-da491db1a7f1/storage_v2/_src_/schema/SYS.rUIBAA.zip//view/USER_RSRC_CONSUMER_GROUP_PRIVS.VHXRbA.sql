create view USER_RSRC_CONSUMER_GROUP_PRIVS (GRANTED_GROUP, GRANT_OPTION, INITIAL_GROUP) as
select g.name, decode(mod(o.option$,2),1,'YES','NO'),
       decode(nvl(cgm.consumer_group, 'DEFAULT_CONSUMER_GROUP'),
              g.name, 'YES', 'NO')
from sys.user$ u left outer join sys.resource_group_mapping$ cgm on
     (cgm.attribute = 'ORACLE_USER' and cgm.status = 'ACTIVE' and
      cgm.value = u.name), sys.resource_consumer_group$ g, sys.objauth$ o
where o.obj# = g.obj# and o.grantee# = u.user#
and o.grantee# = userenv('SCHEMAID')
/

comment on table USER_RSRC_CONSUMER_GROUP_PRIVS is 'Switch privileges for consumer groups for the user'
/

comment on column USER_RSRC_CONSUMER_GROUP_PRIVS.GRANTED_GROUP is 'consumer groups to which the user can switch'
/

comment on column USER_RSRC_CONSUMER_GROUP_PRIVS.GRANT_OPTION is 'whether the user can grant the privilege to others'
/

