create view USER_RULE_SET_RULES
            (RULE_SET_NAME, RULE_OWNER, RULE_NAME, RULE_SET_RULE_ENABLED, RULE_SET_RULE_EVAL_CTX_OWNER,
             RULE_SET_RULE_EVAL_CTX_NAME, RULE_SET_RULE_COMMENT)
as
SELECT /*+ all_rows */
       o.name, ru.name, ro.name,
       decode(bitand(rm.property, 1), 1, 'DISABLED', 'ENABLED'),
       eu.name, eo.name, rm.rm_comment
FROM   rule_map$ rm, obj$ o, obj$ ro, user$ ru, obj$ eo, user$ eu
WHERE  rm.rs_obj# = o.obj# and o.owner# = USERENV('SCHEMAID') and
       rm.r_obj# = ro.obj# and ro.owner# = ru.user# and rm.ectx# = eo.obj#(+)
       and eo.owner# = eu.user#(+)
/

comment on table USER_RULE_SET_RULES is 'Rules in user rule sets'
/

comment on column USER_RULE_SET_RULES.RULE_SET_NAME is 'Name of the rule set'
/

comment on column USER_RULE_SET_RULES.RULE_OWNER is 'Owner of the rule'
/

comment on column USER_RULE_SET_RULES.RULE_NAME is 'Name of the rule'
/

comment on column USER_RULE_SET_RULES.RULE_SET_RULE_ENABLED is 'Whether the rule is enabled in this ruleset'
/

comment on column USER_RULE_SET_RULES.RULE_SET_RULE_EVAL_CTX_OWNER is 'evaluation context owner specified when the rule is added to this rule set'
/

comment on column USER_RULE_SET_RULES.RULE_SET_RULE_EVAL_CTX_NAME is 'evaluation context name specified when the rule is added to this rule set'
/

comment on column USER_RULE_SET_RULES.RULE_SET_RULE_COMMENT is 'User description of this mapping'
/

