create view USER_SCHEDULER_CREDENTIALS (CREDENTIAL_NAME, USERNAME, DATABASE_ROLE, WINDOWS_DOMAIN, COMMENTS) as
SELECT o.name, c.username,
  DECODE(bitand(c.flags,1+2), 1,'SYSDBA', 2, 'SYSOPER', NULL),
  c.domain, c.comments
  FROM obj$ o, sys.scheduler$_credential c
  WHERE o.owner# = USERENV('SCHEMAID') AND c.obj# = o.obj#
/

comment on table USER_SCHEDULER_CREDENTIALS is 'Scheduler credentials owned by the current user'
/

comment on column USER_SCHEDULER_CREDENTIALS.CREDENTIAL_NAME is 'Name of the scheduler credential'
/

comment on column USER_SCHEDULER_CREDENTIALS.USERNAME is 'User to execute the job as'
/

comment on column USER_SCHEDULER_CREDENTIALS.DATABASE_ROLE is 'Database role to use when logging in (either SYSDBA or SYSOPER or NULL)'
/

comment on column USER_SCHEDULER_CREDENTIALS.WINDOWS_DOMAIN is 'Windows domain to use when logging in'
/

comment on column USER_SCHEDULER_CREDENTIALS.COMMENTS is 'Comments on the credential'
/

