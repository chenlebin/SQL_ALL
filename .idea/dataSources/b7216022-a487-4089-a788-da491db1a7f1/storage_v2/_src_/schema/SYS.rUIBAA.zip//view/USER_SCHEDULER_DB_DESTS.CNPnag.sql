create view USER_SCHEDULER_DB_DESTS (DESTINATION_NAME, CONNECT_INFO, AGENT, ENABLED, REFS_ENABLED, COMMENTS) as
SELECT o.name, d.connect_info, ao.name,
  decode(bitand(d.flags, 1), 1, 'TRUE', 'FALSE'),
  decode(bitand(ad.flags, 1), 1, 'TRUE', 'FALSE'),  d.comments
FROM obj$ o, scheduler$_destinations d, obj$ ao,
       scheduler$_destinations ad
WHERE o.owner# = userenv('SCHEMAID') AND o.obj# = d.obj# AND
  d.agtdestoid = ao.obj#(+)  AND bitand(d.flags, 4+8) = 4
  AND d.agtdestoid = ad.obj#(+)
/

comment on table USER_SCHEDULER_DB_DESTS is 'User-owned destination objects in the database pointing to remote databases'
/

comment on column USER_SCHEDULER_DB_DESTS.DESTINATION_NAME is 'Name of this destination object'
/

comment on column USER_SCHEDULER_DB_DESTS.CONNECT_INFO is 'Connect string to connect to remote database'
/

comment on column USER_SCHEDULER_DB_DESTS.AGENT is 'Name of agent through which connection to remote database is being made'
/

comment on column USER_SCHEDULER_DB_DESTS.ENABLED is 'Whether this destination object is enabled'
/

comment on column USER_SCHEDULER_DB_DESTS.COMMENTS is 'Optional comment'
/

