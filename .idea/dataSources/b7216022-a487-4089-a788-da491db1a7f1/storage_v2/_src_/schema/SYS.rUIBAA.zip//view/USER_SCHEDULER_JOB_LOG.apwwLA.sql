create view USER_SCHEDULER_JOB_LOG
            (LOG_ID, LOG_DATE, OWNER, JOB_NAME, JOB_SUBNAME, JOB_CLASS, OPERATION, STATUS, USER_NAME, CLIENT_ID,
             GLOBAL_UID, CREDENTIAL_OWNER, CREDENTIAL_NAME, DESTINATION_OWNER, DESTINATION, ADDITIONAL_INFO)
as
(SELECT
     LOG_ID, LOG_DATE, OWNER,
     DECODE(instr(e.NAME,'"'),0, e.NAME,substr(e.NAME,1,instr(e.NAME,'"')-1)),
     DECODE(instr(e.NAME,'"'),0,NULL,substr(e.NAME,instr(e.NAME,'"')+1)),
     co.NAME, OPERATION,e.STATUS, USER_NAME, CLIENT_ID, GUID,
     decode(e.credential, NULL, NULL,
        substr(e.credential, 1, instr(e.credential, '"')-1)),
     decode(e.credential, NULL, NULL,
        substr(e.credential, instr(e.credential, '"')+1,
           length(e.credential) - instr(e.credential, '"'))),
     decode(bitand(e.flags, 1), 0, NULL,
        substr(e.destination, 1, instr(e.destination, '"')-1)),
     decode(bitand(e.flags, 1), 0, e.destination,
        substr(e.destination, instr(e.destination, '"')+1,
           length(e.destination) - instr(e.destination, '"'))),
     ADDITIONAL_INFO
  FROM scheduler$_event_log e, obj$ co
  WHERE e.type# = 66 and e.dbid is null and e.class_id = co.obj#(+)
  AND owner = SYS_CONTEXT('USERENV','CURRENT_SCHEMA'))
/

comment on table USER_SCHEDULER_JOB_LOG is 'Logged information for all scheduler jobs'
/

comment on column USER_SCHEDULER_JOB_LOG.LOG_ID is 'The unique id that identifies a row'
/

comment on column USER_SCHEDULER_JOB_LOG.LOG_DATE is 'The date of this log entry'
/

comment on column USER_SCHEDULER_JOB_LOG.OWNER is 'The owner of the scheduler job'
/

comment on column USER_SCHEDULER_JOB_LOG.JOB_NAME is 'The name of the scheduler job'
/

comment on column USER_SCHEDULER_JOB_LOG.JOB_SUBNAME is 'The subname of the scheduler job (for a chain step job)'
/

comment on column USER_SCHEDULER_JOB_LOG.JOB_CLASS is 'The class the job belonged to at the time of entry'
/

comment on column USER_SCHEDULER_JOB_LOG.OPERATION is 'The operation corresponding to this log entry'
/

comment on column USER_SCHEDULER_JOB_LOG.STATUS is 'The status of the operation, if applicable'
/

comment on column USER_SCHEDULER_JOB_LOG.USER_NAME is 'The name of the user who performed the operation, if applicable'
/

comment on column USER_SCHEDULER_JOB_LOG.CLIENT_ID is 'The client id of the user who performed the operation, if applicable'
/

comment on column USER_SCHEDULER_JOB_LOG.GLOBAL_UID is 'The global_uid of the user who performed the operation, if applicable'
/

comment on column USER_SCHEDULER_JOB_LOG.CREDENTIAL_OWNER is 'Owner of the credential used for this remote job run'
/

comment on column USER_SCHEDULER_JOB_LOG.CREDENTIAL_NAME is 'Name of the credential used for this remote job run'
/

comment on column USER_SCHEDULER_JOB_LOG.DESTINATION_OWNER is 'Owner of destination object used in remote run or NULL if no object used'
/

comment on column USER_SCHEDULER_JOB_LOG.DESTINATION is 'The destination for a remote job operation'
/

comment on column USER_SCHEDULER_JOB_LOG.ADDITIONAL_INFO is 'Additional information on this entry, if applicable'
/

