create view USER_SCHEDULER_REMOTE_JOBSTATE
            (JOB_NAME, DESTINATION, STATE, NEXT_START_DATE, RUN_COUNT, FAILURE_COUNT, RETRY_COUNT, LAST_START_DATE,
             LAST_END_DATE) as
SELECT o.name, j.destination,
        DECODE(BITAND(j.job_status,1+2+4+8+16+32+8192),0,'DISABLED',1,
        (CASE WHEN j.retry_count>0 THEN 'RETRY SCHEDULED' ELSE 'SCHEDULED' END),
        2, 'RUNNING',
        4,'COMPLETED',8,'BROKEN',16,'FAILED',
        32,'SUCCEEDED' ,8192, 'STOPPED', NULL),
	j.next_start_date, j.run_count,
        j.failure_count, j.retry_count, j.last_start_date, j.last_end_date
 FROM obj$ o, scheduler$_remote_job_state j
 WHERE j.joboid = o.obj# and o.owner# = USERENV('SCHEMAID')
/

comment on table USER_SCHEDULER_REMOTE_JOBSTATE is 'Remote state of all jobs originating from this database owned by current user'
/

comment on column USER_SCHEDULER_REMOTE_JOBSTATE.JOB_NAME is 'Name of the scheduler job'
/

comment on column USER_SCHEDULER_REMOTE_JOBSTATE.DESTINATION is 'Name of job destination'
/

comment on column USER_SCHEDULER_REMOTE_JOBSTATE.STATE is 'State of job at remote system'
/

comment on column USER_SCHEDULER_REMOTE_JOBSTATE.NEXT_START_DATE is 'Next start date of job on remote system'
/

comment on column USER_SCHEDULER_REMOTE_JOBSTATE.RUN_COUNT is 'Run count of job on remote system'
/

comment on column USER_SCHEDULER_REMOTE_JOBSTATE.FAILURE_COUNT is 'Failure count of job on remote system'
/

comment on column USER_SCHEDULER_REMOTE_JOBSTATE.LAST_START_DATE is 'Last start time of job on remote system'
/

comment on column USER_SCHEDULER_REMOTE_JOBSTATE.LAST_END_DATE is 'Last end date of job on remote system'
/

