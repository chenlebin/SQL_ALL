create view USER_SCHEDULER_SCHEDULES
            (SCHEDULE_NAME, SCHEDULE_TYPE, START_DATE, REPEAT_INTERVAL, EVENT_QUEUE_OWNER, EVENT_QUEUE_NAME,
             EVENT_QUEUE_AGENT, EVENT_CONDITION, FILE_WATCHER_OWNER, FILE_WATCHER_NAME, END_DATE, COMMENTS)
as
SELECT so.name,
    (CASE WHEN s.recurrence_expr is null THEN 'ONCE'
       ELSE DECODE(BITAND(s.flags,4),0,'CALENDAR',4,'EVENT',NULL) END),
    s.reference_date,
    decode(bitand(s.flags,4+8), 0, recurrence_expr,null),
    s.queue_owner, s.queue_name, s.queue_agent,
    DECODE(BITAND(s.flags, 4+8), 4, s.recurrence_expr,null),
    DECODE(BITAND(s.flags, 16), 0, NULL,
      substr(s.fw_name,1,instr(s.fw_name,'"')-1)),
    DECODE(BITAND(s.flags, 16), 0, NULL,
      substr(s.fw_name,instr(s.fw_name,'"') + 1,
        length(s.fw_name)-instr(s.fw_name,'"'))),
    s.end_date, s.comments
  FROM sys.scheduler$_schedule s, obj$ so
  WHERE s.obj# = so.obj#  AND so.owner# = USERENV('SCHEMAID')
/

comment on table USER_SCHEDULER_SCHEDULES is 'Schedules belonging to the current user'
/

comment on column USER_SCHEDULER_SCHEDULES.SCHEDULE_NAME is 'Name of the schedule'
/

comment on column USER_SCHEDULER_SCHEDULES.SCHEDULE_TYPE is 'Type of the schedule'
/

comment on column USER_SCHEDULER_SCHEDULES.START_DATE is 'Start date for the repeat interval'
/

comment on column USER_SCHEDULER_SCHEDULES.REPEAT_INTERVAL is 'Calendar syntax expression for this schedule'
/

comment on column USER_SCHEDULER_SCHEDULES.EVENT_QUEUE_OWNER is 'Owner of source queue into which event will be raised'
/

comment on column USER_SCHEDULER_SCHEDULES.EVENT_QUEUE_NAME is 'Name of source queue into which event will be raised'
/

comment on column USER_SCHEDULER_SCHEDULES.EVENT_QUEUE_AGENT is 'Name of AQ agent used by user on the event source queue (if it is a secure queue)'
/

comment on column USER_SCHEDULER_SCHEDULES.EVENT_CONDITION is 'Boolean expression used as subscription rule for event on the source queue'
/

comment on column USER_SCHEDULER_SCHEDULES.FILE_WATCHER_OWNER is 'Owner of file watcher on which this schedule is based'
/

comment on column USER_SCHEDULER_SCHEDULES.FILE_WATCHER_NAME is 'Name of file watcher on which this schedule is based'
/

comment on column USER_SCHEDULER_SCHEDULES.END_DATE is 'Cutoff date after which the schedule will not specify any dates'
/

comment on column USER_SCHEDULER_SCHEDULES.COMMENTS is 'Comments on this schedule'
/

