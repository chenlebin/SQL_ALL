create view USER_SEC_RELEVANT_COLS (OBJECT_NAME, POLICY_GROUP, POLICY_NAME, SEC_REL_COLUMN, COLUMN_OPTION) as
SELECT OBJECT_NAME, POLICY_GROUP, POLICY_NAME, SEC_REL_COLUMN, COLUMN_OPTION
FROM ALL_SEC_RELEVANT_COLS
WHERE
OBJECT_OWNER = SYS_CONTEXT('USERENV','CURRENT_USER')
/

comment on table USER_SEC_RELEVANT_COLS is 'Security Relevant columns of VPD policies for tables or views owned by the user'
/

comment on column USER_SEC_RELEVANT_COLS.OBJECT_NAME is 'Name of the table or view'
/

comment on column USER_SEC_RELEVANT_COLS.POLICY_GROUP is 'Name of the policy group'
/

comment on column USER_SEC_RELEVANT_COLS.POLICY_NAME is 'Name of the policy'
/

comment on column USER_SEC_RELEVANT_COLS.SEC_REL_COLUMN is 'Name of security relevant column'
/

comment on column USER_SEC_RELEVANT_COLS.COLUMN_OPTION is 'Option of the security relevant column'
/

