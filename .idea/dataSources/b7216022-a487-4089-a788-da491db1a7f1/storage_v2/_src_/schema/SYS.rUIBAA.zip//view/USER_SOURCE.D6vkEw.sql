create view USER_SOURCE (NAME, TYPE, LINE, TEXT) as
select o.name,
decode(o.type#, 7, 'PROCEDURE', 8, 'FUNCTION', 9, 'PACKAGE',
               11, 'PACKAGE BODY', 12, 'TRIGGER', 13, 'TYPE', 14, 'TYPE BODY',
               22, 'LIBRARY', 'UNDEFINED'),
s.line, s.source
from sys."_CURRENT_EDITION_OBJ" o, sys.source$ s
where o.obj# = s.obj#
  and ( o.type# in (7, 8, 9, 11, 12, 14, 22) OR
       ( o.type# = 13 AND o.subname is null))
  and o.owner# = userenv('SCHEMAID')
union all
select o.name, 'JAVA SOURCE', s.joxftlno, s.joxftsrc
from sys."_CURRENT_EDITION_OBJ" o, x$joxscd s
where o.obj# = s.joxftobn
  and o.type# = 28
  and o.owner# = userenv('SCHEMAID')
/

comment on table USER_SOURCE is 'Source of stored objects accessible to the user'
/

comment on column USER_SOURCE.NAME is 'Name of the object'
/

comment on column USER_SOURCE.TYPE is 'Type of the object: "TYPE", "TYPE BODY", "PROCEDURE", "FUNCTION",
"PACKAGE", "PACKAGE BODY", "LIBRARY" or "JAVA SOURCE"'
/

comment on column USER_SOURCE.LINE is 'Line number of this line of source'
/

comment on column USER_SOURCE.TEXT is 'Source text'
/

