create view USER_SQLTUNE_BINDS (TASK_ID, OBJECT_ID, POSITION, VALUE) as
SELECT b.task_id, b.object_id, b.position, b.value
  FROM   wri$_adv_sqlt_binds b, wri$_adv_objects o, wri$_adv_tasks t
  WHERE  b.object_id = o.id and b.task_id = o.task_id and o.task_id = t.id and
         t.owner# = SYS_CONTEXT('USERENV', 'CURRENT_USERID')
/

