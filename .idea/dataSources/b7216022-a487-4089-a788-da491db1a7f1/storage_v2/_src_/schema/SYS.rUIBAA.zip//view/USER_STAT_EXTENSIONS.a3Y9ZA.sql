create view USER_STAT_EXTENSIONS (TABLE_NAME, EXTENSION_NAME, EXTENSION, CREATOR, DROPPABLE) as
SELECT
    o.name, c.name,
    sys.get_stats_extension(c.rowid),
    -- TODO use flags once it is available
    decode(substr(c.name, 1, 7), 'SYS_STU', 'USER', 'SYSTEM'),
    decode(substr(c.name, 1, 6), 'SYS_ST', 'YES', 'NO')
  FROM
    sys.col$ c, sys."_CURRENT_EDITION_OBJ" o, sys.user$ u
  WHERE
      o.obj# = c.obj#
  and c.default$ is not null -- avoid join index columns
  and bitand(c.property, 8) = 8 -- virtual column
  and o.owner# = u.user#
  --  tables, excluding iot - overflow and nested tables
  and o.type# = 2
  and not exists (select null
                  from sys.tab$ t
                  where t.obj# = o.obj#
                  and (bitand(t.property, 512) = 512 or
                       bitand(t.property, 8192) = 8192))
  and o.owner# = userenv('SCHEMAID')
/

comment on table USER_STAT_EXTENSIONS is 'Optimizer statistics extensions'
/

comment on column USER_STAT_EXTENSIONS.TABLE_NAME is 'Name of the table to which the extension belongs'
/

comment on column USER_STAT_EXTENSIONS.EXTENSION_NAME is 'The extension (the expression or column group)'
/

comment on column USER_STAT_EXTENSIONS.DROPPABLE is 'Is this extension drppable using dbms_stats.drop_extended_stats ?'
/

