create view USER_SUBSCRIPTIONS
            (HANDLE, SET_NAME, USERNAME, CREATED, STATUS, EARLIEST_SCN, LATEST_SCN, DESCRIPTION, LAST_PURGED,
             LAST_EXTENDED, SUBSCRIPTION_NAME)
as
SELECT
   s.handle, s.set_name, s.username, s.created, s.status, s.earliest_scn,
   s.latest_scn, s.description, s.last_purged, s.last_extended,
   s.subscription_name
  FROM sys.cdc_subscribers$ s, sys.user$ u
  WHERE s.username= u.name AND
        u.user#   = USERENV('SCHEMAID')
/

comment on table USER_SUBSCRIPTIONS is 'Change Data Capture subscriptions'
/

comment on column USER_SUBSCRIPTIONS.HANDLE is 'Unique identifier of the subscription'
/

comment on column USER_SUBSCRIPTIONS.SET_NAME is 'Change set for the subscription'
/

comment on column USER_SUBSCRIPTIONS.USERNAME is 'User name of the subscriber'
/

comment on column USER_SUBSCRIPTIONS.CREATED is 'Creation date of the subscription'
/

comment on column USER_SUBSCRIPTIONS.STATUS is 'Status of the subscriptions (N not activated, A activated)'
/

comment on column USER_SUBSCRIPTIONS.EARLIEST_SCN is 'Subscription window low boundary'
/

comment on column USER_SUBSCRIPTIONS.LATEST_SCN is 'Subscription window high boundary'
/

comment on column USER_SUBSCRIPTIONS.DESCRIPTION is 'Description of the subscription'
/

comment on column USER_SUBSCRIPTIONS.LAST_PURGED is 'Last time subscriber called purge_window'
/

comment on column USER_SUBSCRIPTIONS.LAST_EXTENDED is 'Last time subscriber called extend_window'
/

comment on column USER_SUBSCRIPTIONS.SUBSCRIPTION_NAME is 'Name of the subscription'
/

