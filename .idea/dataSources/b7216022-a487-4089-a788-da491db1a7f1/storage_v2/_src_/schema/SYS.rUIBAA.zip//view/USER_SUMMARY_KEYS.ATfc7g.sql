create view USER_SUMMARY_KEYS
            (OWNER, SUMMARY_NAME, POSITION_IN_SELECT, CONTAINER_COLUMN, DETAILOBJ_OWNER, DETAILOBJ_NAME,
             DETAILOBJ_ALIAS, DETAILOBJ_TYPE, DETAILOBJ_COLUMN)
as
select u1.name, o1.name, sk.sumcolpos#, c1.name,
       u2.name, o2.name, sd.detailalias,
       decode(sk.detailobjtype, 1, 'TABLE', 2, 'VIEW'), c2.name
from sys.sumkey$ sk, sys.obj$ o1, sys.user$ u1, sys.col$ c1, sys.sum$ s,
     sys.sumdetail$ sd, sys.obj$ o2, sys.user$ u2, sys.col$ c2
where sk.sumobj# = o1.obj#
  AND o1.owner# = u1.user#
  AND sk.sumobj# = s.obj#
  AND s.containerobj# = c1.obj#
  AND c1.col# = sk.containercol#
  AND sk.detailobj# = o2.obj#
  AND o2.owner# = u2.user#
  AND sk.sumobj# = sd.sumobj#
  AND sk.detailobj# = sd.detailobj#
  AND sk.detailobj# = c2.obj#
  AND sk.detailcol# = c2.intcol#
  AND sk.instance# = sd.instance#
  AND o1.owner# = userenv('SCHEMAID')
  AND bitand(s.xpflags, 8388608) = 0 /* NOT REWRITE EQUIVALENCE SUMMARY */
  AND bitand(sk.detailcolfunction, 2147483648) = 0  /* NOT 2nd cube mv pct metadata */
/

comment on column USER_SUMMARY_KEYS.OWNER is 'Owner of the summary'
/

comment on column USER_SUMMARY_KEYS.SUMMARY_NAME is 'Name of the summary'
/

comment on column USER_SUMMARY_KEYS.POSITION_IN_SELECT is 'Position of this key within the SELECT list'
/

comment on column USER_SUMMARY_KEYS.CONTAINER_COLUMN is 'Name of the column in the container table'
/

comment on column USER_SUMMARY_KEYS.DETAILOBJ_OWNER is 'Owner of the detail object'
/

comment on column USER_SUMMARY_KEYS.DETAILOBJ_NAME is 'Name of the detail object'
/

comment on column USER_SUMMARY_KEYS.DETAILOBJ_ALIAS is 'Alias of the detail object'
/

comment on column USER_SUMMARY_KEYS.DETAILOBJ_TYPE is 'Type of the detail object: VIEW or TABLE'
/

comment on column USER_SUMMARY_KEYS.DETAILOBJ_COLUMN is 'Name of the detail object column'
/

