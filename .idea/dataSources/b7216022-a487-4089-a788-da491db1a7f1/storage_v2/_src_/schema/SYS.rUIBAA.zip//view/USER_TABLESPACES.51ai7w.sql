create view USER_TABLESPACES
            (TABLESPACE_NAME, BLOCK_SIZE, INITIAL_EXTENT, NEXT_EXTENT, MIN_EXTENTS, MAX_EXTENTS, MAX_SIZE, PCT_INCREASE,
             MIN_EXTLEN, STATUS, CONTENTS, LOGGING, FORCE_LOGGING, EXTENT_MANAGEMENT, ALLOCATION_TYPE,
             SEGMENT_SPACE_MANAGEMENT, DEF_TAB_COMPRESSION, RETENTION, BIGFILE, PREDICATE_EVALUATION, ENCRYPTED,
             COMPRESS_FOR)
as
select ts.name, ts.blocksize, ts.blocksize * ts.dflinit,
          decode(bitand(ts.flags, 3), 1, to_number(NULL),
                        ts.blocksize * ts.dflincr),
          ts.dflminext,
          decode(ts.contents$, 1, to_number(NULL), ts.dflmaxext),
          decode(bitand(ts.flags, 4096), 4096, ts.affstrength, NULL),
          decode(bitand(ts.flags, 3), 1, to_number(NULL), ts.dflextpct),
          ts.blocksize * ts.dflminlen,
          decode(ts.online$, 1, 'ONLINE', 2, 'OFFLINE',
                 4, 'READ ONLY', 'UNDEFINED'),
          decode(ts.contents$, 0, (decode(bitand(ts.flags, 16), 16, 'UNDO',
                 'PERMANENT')), 1, 'TEMPORARY'),
          decode(bitand(ts.dflogging, 1), 0, 'NOLOGGING', 1, 'LOGGING'),
          decode(bitand(ts.dflogging, 2), 0, 'NO', 2, 'YES'),
          decode(ts.bitmapped, 0, 'DICTIONARY', 'LOCAL'),
          decode(bitand(ts.flags, 3), 0, 'USER', 1, 'SYSTEM', 2, 'UNIFORM',
                 'UNDEFINED'),
          decode(bitand(ts.flags,32), 32,'AUTO', 'MANUAL'),
          decode(bitand(ts.flags,64), 64,'ENABLED', 'DISABLED'),
          decode(bitand(ts.flags,16), 16, (decode(bitand(ts.flags, 512), 512,
                 'GUARANTEE', 'NOGUARANTEE')), 'NOT APPLY'),
          decode(bitand(ts.flags,256), 256, 'YES', 'NO'),
          decode(tsattr.storattr, 1, 'STORAGE', 'HOST'),
          decode(bitand(ts.flags,16384), 16384, 'YES', 'NO'),
          decode(bitand(ts.flags,64), 0, null,
            (case when bitand(ts.flags,  65536) = 65536
                    then 'OLTP'
                  when bitand(ts.flags, (131072+262144)) = 131072
                    then 'QUERY LOW'
                  when bitand(ts.flags, (131072+262144)) = 262144
                    then 'QUERY HIGH'
                  when bitand(ts.flags, (131072+262144)) = (131072+262144)
                    then 'ARCHIVE LOW'
                  when bitand(ts.flags, 524288) = 524288
                    then 'ARCHIVE HIGH'
                  else 'BASIC' end))
from sys.ts$ ts, x$kcfistsa tsattr
where ts.online$ != 3
and bitand(flags,2048) != 2048
      and (   exists (select null from sys.tsq$ tsq
                 where tsq.ts# = ts.ts#
                   and tsq.user# = userenv('SCHEMAID') and
                   (tsq.blocks > 0 or tsq.maxblocks != 0))
           or exists
              (select null
              from sys.v$enabledprivs
              where priv_number = -15 /* UNLIMITED TABLESPACE */))
      and ts.ts# = tsattr.tsid
/

comment on table USER_TABLESPACES is 'Description of accessible tablespaces'
/

comment on column USER_TABLESPACES.TABLESPACE_NAME is 'Tablespace name'
/

comment on column USER_TABLESPACES.BLOCK_SIZE is 'Tablespace block size'
/

comment on column USER_TABLESPACES.INITIAL_EXTENT is 'Default initial extent size'
/

comment on column USER_TABLESPACES.NEXT_EXTENT is 'Default incremental extent size'
/

comment on column USER_TABLESPACES.MIN_EXTENTS is 'Default minimum number of extents'
/

comment on column USER_TABLESPACES.MAX_EXTENTS is 'Default maximum number of extents'
/

comment on column USER_TABLESPACES.MAX_SIZE is 'Default maximum size of segments'
/

comment on column USER_TABLESPACES.PCT_INCREASE is 'Default percent increase for extent size'
/

comment on column USER_TABLESPACES.MIN_EXTLEN is 'Minimum extent size for the tablespace'
/

comment on column USER_TABLESPACES.STATUS is 'Tablespace status: "ONLINE", "OFFLINE", or "READ ONLY"'
/

comment on column USER_TABLESPACES.CONTENTS is 'Tablespace contents: "PERMANENT", or "TEMPORARY"'
/

comment on column USER_TABLESPACES.LOGGING is 'Default logging attribute'
/

comment on column USER_TABLESPACES.FORCE_LOGGING is 'Tablespace force logging mode'
/

comment on column USER_TABLESPACES.EXTENT_MANAGEMENT is 'Extent management tracking: "DICTIONARY" or "LOCAL"'
/

comment on column USER_TABLESPACES.ALLOCATION_TYPE is 'Type of extent allocation in effect for this tablespace'
/

comment on column USER_TABLESPACES.SEGMENT_SPACE_MANAGEMENT is 'Segment space management tracking: "AUTO" or "MANUAL"'
/

comment on column USER_TABLESPACES.DEF_TAB_COMPRESSION is 'Default table compression enabled or not: "ENABLED" or "DISABLED"'
/

comment on column USER_TABLESPACES.RETENTION is 'Undo tablespace retention: "GUARANTEE", "NOGUARANTEE" or "NOT APPLY"'
/

comment on column USER_TABLESPACES.BIGFILE is 'Bigfile tablespace indicator: "YES" or "NO"'
/

comment on column USER_TABLESPACES.PREDICATE_EVALUATION is 'Predicates evaluated by: "HOST" or "STORAGE"'
/

comment on column USER_TABLESPACES.ENCRYPTED is 'Encrypted tablespace indicator: "YES" or "NO"'
/

comment on column USER_TABLESPACES.COMPRESS_FOR is 'Default compression for what kind of operations'
/

