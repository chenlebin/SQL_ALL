create view V_$DIAG_CRITICAL_ERROR (FACILITY, ERROR) as
select "FACILITY","ERROR" from v$diag_critical_error
/

