create view V_$RSRC_PLAN (ID, NAME, IS_TOP_PLAN, CPU_MANAGED) as
select "ID","NAME","IS_TOP_PLAN","CPU_MANAGED" from v$rsrc_plan
/

