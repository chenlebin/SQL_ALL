create view V_$SQLPA_METRIC (METRIC_NAME) as
select "METRIC_NAME" from v$sqlpa_metric
/

