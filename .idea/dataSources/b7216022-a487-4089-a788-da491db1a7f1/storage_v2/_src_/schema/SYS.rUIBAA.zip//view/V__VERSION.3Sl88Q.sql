create view V_$VERSION (BANNER) as
select "BANNER" from v$version
/

