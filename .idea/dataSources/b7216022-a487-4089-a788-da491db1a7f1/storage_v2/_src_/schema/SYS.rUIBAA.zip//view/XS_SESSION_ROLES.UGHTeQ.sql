create view XS_SESSION_ROLES (ROLE, UUID, DBID, FLAGS) as
select u.role_name, u.uuid, u.dbid, u.flags
from x$xs_session_roles u
/

comment on table XS_SESSION_ROLES is 'Roles enabled in the current lightweight session'
/

comment on column XS_SESSION_ROLES.ROLE is 'Role name'
/

comment on column XS_SESSION_ROLES.UUID is 'UUID of role'
/

comment on column XS_SESSION_ROLES.DBID is 'Database internal ID of role'
/

comment on column XS_SESSION_ROLES.FLAGS is 'Status flags'
/

