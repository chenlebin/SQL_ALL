create view "_ALL_FILE_GROUPS"
            (FILE_GROUP_ID, FILE_GROUP_OWNER, FILE_GROUP_NAME, KEEP_FILES, MIN_VERSIONS, MAX_VERSIONS, RETENTION_DAYS,
             CREATED, COMMENTS, DEFAULT_DIRECTORY, CREATOR)
as
select g.file_group_id, u.name, o.name, g.keep_files, g.min_versions,
       g.max_versions, g.retention_days, g.creation_time, g.user_comment,
       g.default_dir_obj, g.creator
from sys.obj$ o, sys.user$ u, sys.fgr$_file_groups g
where o.owner# = u.user# and o.obj# = g.file_group_id and
      (o.owner# in (USERENV('SCHEMAID'), 1 /* PUBLIC */) or
       o.obj# in (select oa.obj# from sys.objauth$ oa
                  where grantee# in (select kzsrorol from x$kzsro)) or
       exists (select null from v$enabledprivs where priv_number in (
                                                         -277, -278)))
/

