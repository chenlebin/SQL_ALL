create view "_ALL_FILE_GROUP_FILES"
            (FILE_GROUP_OWNER, FILE_GROUP_NAME, VERSION_NAME, VERSION_ID, VERSION_GUID, FILE_NAME, FILE_DIRECTORY,
             FILE_TYPE, FILE_SIZE, FILE_BLOCKSIZE, COMMENTS, CREATOR, CREATED)
as
select g.file_group_owner, g.file_group_name, v.version_name,
     v.version_id, v.version_guid, f.file_name, f.file_dir_obj, f.file_type,
     f.file_size, f.file_blocksize, f.user_comment, f.creator, f.creation_time
from "_ALL_FILE_GROUPS" g, sys.fgr$_file_group_files f,
     sys.fgr$_file_group_versions v
where f.version_guid = v.version_guid and v.file_group_id = g.file_group_id
/

