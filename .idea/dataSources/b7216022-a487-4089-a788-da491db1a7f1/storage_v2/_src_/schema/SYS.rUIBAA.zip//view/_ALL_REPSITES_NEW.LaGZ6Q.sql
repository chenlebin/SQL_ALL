create view "_ALL_REPSITES_NEW" (EXTENSION_ID, GOWNER, GNAME, DBLINK, FULL_INSTANTIATION, MASTER_STATUS) as
select
  r.extension_id,
  r.gowner,
  r.gname,
  r.dblink,
  r.full_instantiation,
  r.master_status
from dba_repsites_new r
/

comment on table "_ALL_REPSITES_NEW" is 'Information about new masters for replication extension'
/

comment on column "_ALL_REPSITES_NEW".EXTENSION_ID is 'Globally unique identifier for replication extension'
/

comment on column "_ALL_REPSITES_NEW".GOWNER is 'Owner of the object group'
/

comment on column "_ALL_REPSITES_NEW".GNAME is 'Name of the replicated object group'
/

comment on column "_ALL_REPSITES_NEW".DBLINK is 'A database site that will replicate the object group'
/

comment on column "_ALL_REPSITES_NEW".FULL_INSTANTIATION is 'Y if the database uses full-database export or change-based recovery'
/

comment on column "_ALL_REPSITES_NEW".MASTER_STATUS is 'Instantiation status of the new master'
/

