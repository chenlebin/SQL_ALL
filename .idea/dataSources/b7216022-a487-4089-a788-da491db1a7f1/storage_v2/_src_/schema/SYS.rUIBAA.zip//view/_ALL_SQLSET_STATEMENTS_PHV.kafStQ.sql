create view "_ALL_SQLSET_STATEMENTS_PHV"
            (SQLSET_NAME, SQLSET_OWNER, SQLSET_ID, SQL_ID, FORCE_MATCHING_SIGNATURE, PLAN_HASH_VALUE, COMMAND_TYPE,
             PARSING_SCHEMA_NAME, MODULE, ACTION, PLAN_TIMESTAMP, BINDS_CAPTURED, SQL_SEQ)
as
select d.name as sqlset_name, d.owner as sqlset_owner, s.sqlset_id,
       s.sql_id, s.force_matching_signature, p.plan_hash_value,
       s.command_type, p.parsing_schema_name, s.module, s.action,
       p.plan_timestamp, p.binds_captured, s.id as sql_seq
from   WRI$_SQLSET_DEFINITIONS d, WRI$_SQLSET_STATEMENTS s,
       WRI$_SQLSET_PLANS p
where  d.id = s.sqlset_id AND s.id = p.stmt_id AND
       (d.owner = SYS_CONTEXT('USERENV', 'CURRENT_USER') OR
        EXISTS (select 1
                from   V$ENABLEDPRIVS
                where  priv_number in (-273 /*ADMINISTER ANY SQL TUNING SET*/)))
/

