create view "_USER_COMPARISON_ROW_DIF"
            (COMPARISON_ID, SCAN_ID, LOC_ROWID, RMT_ROWID, IDX_VAL, STATUS, LAST_UPDATE_TIME, SPARE1, SPARE2, SPARE3,
             SPARE4) as
SELECT d."COMPARISON_ID",d."SCAN_ID",d."LOC_ROWID",d."RMT_ROWID",d."IDX_VAL",d."STATUS",d."LAST_UPDATE_TIME",d."SPARE1",d."SPARE2",d."SPARE3",d."SPARE4" FROM comparison_row_dif$ d, comparison$ c
WHERE d.comparison_id = c.comparison_id
AND user# = uid
/

